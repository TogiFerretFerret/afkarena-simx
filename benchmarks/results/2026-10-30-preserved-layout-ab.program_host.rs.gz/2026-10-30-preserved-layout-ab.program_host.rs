//! Native equivalents of the pinned Node oracle loader's two host bindings.
//! Game logic still executes through generated Rust; these bindings only read
//! source-requested file bytes and hash diagnostic UTF-8 text.
use js_runtime::{Runtime,Value,EnvId,JsResult,JsError};

pub fn install(rt:&mut Runtime)->JsResult<()> {
 let global=Value::Object(rt.global_object);
 let host=rt.object();let load=rt.native_function("loadFile",1,load_file)?;
 let key=rt.string("loadFile");rt.define_data(host,key,load,true,true,true)?;
 let key=rt.string("hermescli");rt.define_data(global,key,host,true,true,true)?;
 let digest=rt.native_function("__nativeDiagnosticDigest",1,diagnostic_digest)?;
 let key=rt.string("__nativeDiagnosticDigest");rt.define_data(global,key,digest,true,true,true)?;
 Ok(())
}
fn load_file(rt:&mut Runtime,_:Value,args:&[Value],_:EnvId)->JsResult<Value>{
 let Some(Value::String(path))=args.first().copied()else{return Err(JsError::Unsupported("oracle file loader requires a source-proven string path".into()))};
 let path=String::from_utf16_lossy(rt.string_units(path));
 // Do not manufacture an empty file or swallow an IO failure: it invalidates
 // execution of this source fixture and must fail the entire native run.
 let bytes=std::fs::read(&path).map_err(|error|JsError::Unsupported(format!("oracle file IO {path:?}: {error}")))?;
 let global=Value::Object(rt.global_object);let key=rt.string("Uint8Array");let constructor=rt.get(global,key)?;
 rt.uint8_array_from_bytes(constructor,bytes)
}
fn diagnostic_digest(rt:&mut Runtime,_:Value,args:&[Value],_:EnvId)->JsResult<Value>{
 let Some(Value::String(text))=args.first().copied()else{return Err(JsError::Unsupported("oracle diagnostic digest requires source-proven string text".into()))};
 // Node crypto.update(string) uses UTF-8 with U+FFFD for isolated surrogates.
 let utf8=String::from_utf16_lossy(rt.string_units(text));Ok(rt.string(&sha256_hex(utf8.as_bytes())))
}
pub fn sha256_hex(input:&[u8])->String{
 const K:[u32;64]=[
 0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
 0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
 0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
 0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
 0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
 0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
 0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
 0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
 let mut state=[0x6a09e667u32,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
 let mut padded=input.to_vec();padded.push(0x80);while padded.len()%64!=56{padded.push(0)}padded.extend_from_slice(&(input.len()as u64).wrapping_mul(8).to_be_bytes());
 for block in padded.chunks_exact(64){let mut w=[0u32;64];for(i,word)in block.chunks_exact(4).enumerate(){w[i]=u32::from_be_bytes(word.try_into().unwrap());}
  for i in 16..64{let s0=w[i-15].rotate_right(7)^w[i-15].rotate_right(18)^(w[i-15]>>3);let s1=w[i-2].rotate_right(17)^w[i-2].rotate_right(19)^(w[i-2]>>10);w[i]=w[i-16].wrapping_add(s0).wrapping_add(w[i-7]).wrapping_add(s1);}
  let[mut a,mut b,mut c,mut d,mut e,mut f,mut g,mut h]=state;
  for i in 0..64{let s1=e.rotate_right(6)^e.rotate_right(11)^e.rotate_right(25);let ch=(e&f)^(!e&g);let t1=h.wrapping_add(s1).wrapping_add(ch).wrapping_add(K[i]).wrapping_add(w[i]);let s0=a.rotate_right(2)^a.rotate_right(13)^a.rotate_right(22);let maj=(a&b)^(a&c)^(b&c);let t2=s0.wrapping_add(maj);h=g;g=f;f=e;e=d.wrapping_add(t1);d=c;c=b;b=a;a=t1.wrapping_add(t2);}
  for(dest,value)in state.iter_mut().zip([a,b,c,d,e,f,g,h]){*dest=dest.wrapping_add(value);}
 }
 state.iter().map(|word|format!("{word:08x}")).collect()
}
#[cfg(test)]mod tests{
 use super::*;
 #[test]fn sha256_known_vectors(){for(input,expected)in[("","e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"),("abc","ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"),("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq","248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1")]{assert_eq!(sha256_hex(input.as_bytes()),expected)}assert_eq!(sha256_hex(&vec![b'a';1_000_000]),"cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");}
 #[test]fn loader_returns_real_unsigned_bytes(){let mut rt=Runtime::new();install(&mut rt).unwrap();let path=std::env::temp_dir().join(format!("simx-native-host-{}",std::process::id()));std::fs::write(&path,[0,127,128,255]).unwrap();let arg=rt.string(path.to_str().unwrap());let env=rt.global_env;let data=load_file(&mut rt,Value::Undefined,&[arg],env).unwrap();std::fs::remove_file(path).unwrap();for(i,expected)in[0,127,128,255].into_iter().enumerate(){let key=rt.string(&i.to_string());assert_eq!(rt.get(data,key).unwrap(),Value::Number(expected as f64));}let key=rt.string("length");assert_eq!(rt.get(data,key).unwrap(),Value::Number(4.0));}
 #[test]fn diagnostic_uses_node_utf8_replacement(){let mut rt=Runtime::new();let text=rt.string_utf16(&[0x61,0xd800,0x62,0xdc00]);let env=rt.global_env;let out=diagnostic_digest(&mut rt,Value::Undefined,&[text],env).unwrap();let Value::String(id)=out else{panic!()};assert_eq!(String::from_utf16_lossy(rt.string_units(id)),sha256_hex("a\u{fffd}b\u{fffd}".as_bytes()));}
 #[test]fn bulk_bytes_support_source_table_size_without_index_interning(){let mut rt=Runtime::new();let global=Value::Object(rt.global_object);let key=rt.string("Uint8Array");let constructor=rt.get(global,key).unwrap();let length=97*1024*1024;let mut bytes=vec![0;length];bytes[length-1]=255;let output=rt.uint8_array_from_bytes(constructor,bytes).unwrap();let key=rt.string("length");assert_eq!(rt.get(output,key).unwrap(),Value::Number(length as f64));let key=rt.string(&(length-1).to_string());assert_eq!(rt.get(output,key).unwrap(),Value::Number(255.0));}

}
