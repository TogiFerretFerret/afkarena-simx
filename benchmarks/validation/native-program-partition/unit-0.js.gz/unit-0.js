
;
var __nativeGlobal;
var __nativeWallNow;
var ed;
var cc;
var window;
var __nativeHostInputs;
var __nativeEntropyIndex;
var __nativeClockObserver;
var __nativeClock;
function rotl32(e,t){return(e|=0)>>>(32-(t|=0)|0)|e<<t|0}
function rotmul32(e,t,r){return e|=0,t|=0,r|=0,0|util.imul(e>>>(32-t|0)|e<<t,r)}
function shiftxor32(e,t){return(e|=0)>>>(t|=0)^e|0}
function xxhapply(e,t,r,i,a){return rotmul32(util.imul(t,r)+e,i,a)}
function xxh1(e,t,r){return rotmul32(e+util.imul(t[r],prime5),11,prime1)}
function xxh4(e,t,r){return xxhapply(e,util.readU32(t,r),prime3,17,prime4)}
function xxh16(e,t,r){return[xxhapply(e[0],util.readU32(t,r+0),prime2,13,prime1),xxhapply(e[1],util.readU32(t,r+4),prime2,13,prime1),xxhapply(e[2],util.readU32(t,r+8),prime2,13,prime1),xxhapply(e[3],util.readU32(t,r+12),prime2,13,prime1)]}
function xxh32(e,t,r,i){var a,n;if(n=i,i>=16){for(a=[e+prime1+prime2,e+prime2,e,e-prime1];i>=16;)a=xxh16(a,t,r),r+=16,i-=16;a=rotl32(a[0],1)+rotl32(a[1],7)+rotl32(a[2],12)+rotl32(a[3],18)+n}else a=e+prime5+i>>>0;for(;i>=4;)a=xxh4(a,t,r),r+=4,i-=4;for(;i>0;)a=xxh1(a,t,r),r++,i--;return(a=shiftxor32(util.imul(shiftxor32(util.imul(shiftxor32(a,15),prime2),13),prime3),16))>>>0}
function makeHashTable(){try{return new Uint32Array(hashSize)}catch(r){for(var e=new Array(hashSize),t=0;t<hashSize;t++)e[t]=0;return e}}
function clearHashTable(e){for(var t=0;t<hashSize;t++)hashTable[t]=0}
function makeBuffer(e){try{return new Uint8Array(e)}catch(i){for(var t=new Array(e),r=0;r<e;r++)t[r]=0;return t}}
function sliceArray(e,t,r){if(void 0!==typeof e.buffer){if(Uint8Array.prototype.slice)return e.slice(t,r);var i=e.length;t=(t|=0)<0?Math.max(i+t,0):Math.min(t,i),r=(r=void 0===r?i:0|r)<0?Math.max(i+r,0):Math.min(r,i);for(var a=new Uint8Array(r-t),n=t,o=0;n<r;)a[o++]=e[n++];return a}return e.slice(t,r)}
function _isBugReportGmEnabled(){return!(!ed.bugReportLog||!ed.bugReportLog.isEnabled)&&ed.bugReportLog.isEnabled()}
function _installBugReportLogHookIfGmEnabled(){_isBugReportGmEnabled()&&ed.bugReportLog&&(ed.bugReportLog.installHookIfEnabled?ed.bugReportLog.installHookIfEnabled():ed.bugReportLog.installHook&&ed.bugReportLog.installHook())}
function _finishLoadJsbDevTools(e){var t,i=_jsbDevToolsLoadCallbacks;for(_jsbDevToolsLoadCallbacks=[],_jsbDevToolsLoading=!1,t=0;t<i.length;t++)i[t](e||null)}
function _loadJsbDevToolsFile(e,t){var i;if(t>=e.length)_finishLoadJsbDevTools(null);else{if(i=e[t],cc.loader&&cc.loader.loadJs)try{return void cc.loader.loadJs([i],(function(i){i?_finishLoadJsbDevTools(i):_loadJsbDevToolsFile(e,t+1)}))}catch(e){return void _finishLoadJsbDevTools(e)}_finishLoadJsbDevTools("cc.loader.loadJs unavailable")}}
function _withJsbDevTools(e){ed.hotReloadClient?e(null,ed.hotReloadClient):(_jsbDevToolsLoadCallbacks.push((function(t){!t&&ed.hotReloadClient?e(null,ed.hotReloadClient):ed.showToast(T("jsb_devtools_load_failed","JSB 开发工具加载失败：")+(t&&(t.stack||t.message)||t||"unknown"),{bindSystemFont:!0})})),_jsbDevToolsLoading||(_jsbDevToolsLoading=!0,_loadJsbDevToolsFile(["src/debug/hotReload/hotReloadRuntime.js","src/debug/hotReload/hotReloadClient.js"],0)))}
function _resetTutorialClientCacheByName(e){for(var t in ed.guideMgr.ttHash)if(-1!==t.indexOf(e)){for(var i=ed.guideMgr.ttHash[t].Steps,n=0;n<i.length;n++)i[n].Completed=!1;ed.guideMgr.completed[t]=!1}}
function _quickPlay(){for(var e in singleGuider.ttHash)singleGuider.complete(e);ed.fireEvent("REMOVE_FORCED_GUIDE_FINGER"),ed.rpc.send("req_gm",{req_set_level:100},(function(e){ed.player.initData(e.reply_gm.user)})),ed.rpc.send("req_gm",{req_gold:999999,req_diamond:999999},(function(e){ed.player.initData(e.reply_gm.user)})),ed.rpc.send("req_gm",{req_unlock_stages:2e3},(function(e){ed.showToast("已开启所有关卡到：2000",{bindSystemFont:!0}),ed.player.initData(e.reply_gm.user),ed.chapResMgr.loadCurChapResBackDLDNext()}))}
var multiplier,moder;
var cc;
var ClassManager;
var classManager;
var __nativeClassManagerObserver;
function __nativeFactory0(){return (function(e){if(-1===e.indexOf("."))return e;var t=cc.sys;return t.os===t.OS_IOS?e=4===ed.sound_manager.engineType?e.substr(0,e.length-4)+".fsb":3===ed.sound_manager.engineType?e.substr(0,e.length-4)+".ogg":cc.sys.jsb?e.substr(0,e.length-4)+".m4a":e.substr(0,e.length-4)+".ogg":t.os===t.OS_ANDROID?e=4===ed.sound_manager.engineType?e.substr(0,e.length-4)+".fsb":e.substr(0,e.length-4)+".ogg":t.os===t.OS_WINDOWS&&(e=cc.sys.jsb?e.substr(0,e.length-4)+".fsb":e.substr(0,e.length-4)+".ogg"),e});}
function __nativeFactory1(){return (cc.Class.extend({ctor:function(){if(this.setMusicVolumeZeroBGM=null,this.active_music=null,this.music_stack=[],this.delay_music_list=[],this.sfx_stack=[],this.delay_sfx_list=[],this.fadeList=[],this.music_next=null,this.polyList={},this.loopingEffectList=new Array,this.data=ed.getDataTable("Sound"),this.interval=0,this.play_rand_interval=0,this.sfx_interval=0,this.SoundCDSequences=new Array,this.manorBGMDuration=11,this.fieldBGMDuration=11,this.isGramophonePlaying=!1,ed.sound_manager=this,ed.SoundCDSequences=this.SoundCDSequences,this.replaceHomelandBGM=!1,this.engineType=null,cc.audioEngine.getEngineType){var e=cc.audioEngine.getEngineType();this.engineType=e,this.engineType=4}cc.log("ed.sound_manager.engineType:"+this.engineType),this.addEvent(),this.miniDaw=new ed.miniDawED},bgmCountDownForManorAndField:function(e){var t=this;t.removeBGMCountDownForManorAndField(),t.remove30sCountDown(),t.bgmCounter=ed.setTimeout((function(){t.removeBGMCountDownForManorAndField(),t.countDownFor30s()}),1e3*e)},removeBGMCountDownForManorAndField:function(){var e=this;e.bgmCounter&&(ed.clearTimeout(e.bgmCounter),e.bgmCounter=null)},countDownFor30s:function(){var e=this;e.remove30sCountDown(),e.countDown30s=ed.setTimeout((function(){e.remove30sCountDown(),e.playRandomMusic()}),3e4)},remove30sCountDown:function(){var e=this;e.countDown30s&&(ed.clearTimeout(e.countDown30s),e.countDown30s=null)},playRandomMusic:function(){if(this.bgmCountDownForManorAndField(12),ed.viewManager.getTopView()&&ed.viewManager.isTopMainView()){var e=["res/sound/stage/BGM_playlist_1.ogg","res/sound/stage/BGM_playlist_2.ogg"],t=["BGM_playlist_1","BGM_playlist_2",12e3,12923],r=ed.getRandom(e.length),i=e[r],a={},n=ed.soundAutoFormat(i);a.Name=t[r],a.Length=t[r+e.length],ed.playAudioMusic(n,!1,a)}},addEvent:function(){var e=this;cc.eventManager.addCustomListener("START_MANOR_FIELD_BGM_COUNT_DOWN",(function(t){var r=t.getUserData();e.bgmCountDownForManorAndField(r)}),this),cc.eventManager.addCustomListener("REMOVE_MANOR_FIELD_BGM_COUNT_DOWN",(function(t){e.removeCountDown()}),this),cc.eventManager.addCustomListener("game_login_success",(function(){ed.gramophoneInit()}),this)},removeCountDown:function(){this.remove30sCountDown(),this.removeBGMCountDownForManorAndField()},_playEffect:function(e){e.Time;var t=e.Res,r=e.IsLoop,i=(e.IsRestart,e.Level),a=ed.soundAutoFormat(t),n=ed.playAudioEffect(a,r,e.Name);return r&&this.loopingEffectList.push(n),1===i&&(this.sfx_stack=[]),this.sfx_stack.push(e),this.sfx_interval=e.Time,n},popEffect:function(){this.sfx_stack.pop()},playEffect:function(e){this.delay_sfx_list.length>0&&this.delay_sfx_list.splice(0,1);var t=this.data[e];if(t){var r=!0,i=!1,a=t.IsRestart;if(this.sfx_stack.length>0){var n=this.sfx_stack[this.sfx_stack.length-1];e===n.Name&&(r=a);var o=n.IgnorList,s=n.DelayList;if(o&&o.length>0)for(var l=0;l<o.length;){if(o[l++]===e){r=!1;break}}if(s&&s.length>0)for(l=0;l<s.length;){s[l++]===e&&(i=!0)}}if(r){if(!i)return this._playEffect(t);this.delay_sfx_list.push(t)}}},_playMusic:function(e,t){e.Time;var r=e.Res,i=e.IsLoop,a=(e.IsRestart,e.Level);window.wx&&cc.audioEngine.stopMusic();var n=ed.soundAutoFormat(r);cc.log("soundManager _playMusic: "+e.Name),ed.audio_music_switch||(ed.setMusicVolumeZeroBGM={},ed.setMusicVolumeZeroBGM.config=e,ed.setMusicVolumeZeroBGM.addition=t),ed.playAudioMusic(n,i,e),1===a&&(this.music_stack=[]),t||this.music_stack.push(e),this.interval=e.Time,t||(this._currMusic=e)},_stopMusic:function(e){cc.supportAudioVolume()?ed.fadeOutSound(ed.bgm.currentBGM.id,-1):cc.audioEngine.stopMusic(),this._currMusic=null},findMusic:function(e){for(var t=this.music_stack.length-1;t>=0;--t){if(e===this.music_stack[t].Name)return!0}return!1},popMusic:function(e){this.music_stack.length>=1&&(e===(i=this.music_stack[this.music_stack.length-1]).Name&&1!==i.Level&&(this.music_next=null,this.music_stack.pop(),this._stopMusic()));var t=ed.viewManager.getTopView();if(t){if(!ed.viewManager.isTopMainView()){var r=t.getMusic();if(this.music_stack.length>=1)if(r!==(i=this.music_stack[this.music_stack.length-1]).Name)return}if(this.music_stack.length>=1){var i=this.music_stack[this.music_stack.length-1];if(this._currMusic&&i.Name===this._currMusic.Name)return;var a=this.music_stack.pop();this._stopMusic(),this.playMusic(a.Name)}}},getMusicLength:function(e){if(!e)return-1;var t=ed.soundAutoFormat(e.Res),r=e.TimeToWait||e.Length/1e3;if(cc.sys.jsb&&cc.audioEngine.getDuration){if(ed.isFileExistCheckMD5(t)){var i=cc.audioEngine.getDuration(t);return i>0?i:r}return hg.ResourceManager.getInstance().loadResourceFile(t,(function(e,t,r){})),r}return r},playMusic:function(e){this.delay_music_list.length>0&&this.delay_music_list.splice(0,1);var t=this.data[e];if(t){var r=!0,i=!1,a=t.IsRestart;if(this.music_stack.length>0){var n=this.music_stack[this.music_stack.length-1];e===n.Name&&(r=a);var o=n.IgnorList,s=n.DelayList;if(o&&o.length>0)for(var l=0;l<o.length;){if(o[l++]===e){r=!1;break}}if(s&&s.length>0)for(l=0;l<s.length;){if(s[l++]===e){i=!0;break}}}this._processNext(t),r&&(i?this.delay_music_list.push(t):this._playMusic(t))}},playOneShot:function(e,t){this.play_rand_interval||(null==t&&(t=.1),this.playEffect(e),this.play_rand_interval=t)},_processNext:function(e){if(e.Next){var t=this.data[e.Next];t&&(this.music_next={musicconfig:t,timetoplay:this.getMusicLength(e)})}else this.music_next=null},setNextMusicCallback:function(e){this.nextMusicCallbackFunc=e},releaseMusic:function(e){var t=this.data[e];if(t){cc.log("release music "+e);var r=t.Res;cc.loader.release(ed.soundAutoFormat(r))}},_updateSound:function(e){if(this.interval-=e,this.play_rand_interval&&(this.play_rand_interval-=e),this.play_rand_interval<0&&(this.play_rand_interval=0),!(this.interval>0))if(this.delay_music_list.length>0){var t=this.delay_music_list[0];this.delay_music_list.splice(0,1),this._playMusic(t)}else this.music_stack.length>0?this.interval=this.music_stack[this.music_stack.length-1].Time:this.interval=2},_updateSFX:function(e){if(this.sfx_interval-=e,!(this.sfx_interval>0))if(this.delay_sfx_list.length>0){var t=this.delay_sfx_list[0];this.delay_sfx_list.splice(0,1),this._playEffect(t)}else this.sfx_stack.length>0?this.sfx_interval=this.sfx_stack[this.sfx_stack.length-1].Time:this.sfx_interval=2},_updateFadeSFX:function(e){if(cc.supportAudioVolume())for(var t=0;t<this.fadeList.length;){var r=this.fadeList[t];if(0==r.fadeTime){this.fadeList.splice(t,1);break}var i=e/r.fadeTime;i<0?(r.current+=i,Math.abs(r.current)<=Math.abs(i)?(this.fadeList.splice(t,1),this.removeSoundByID(r.id),cc.audioEngine.stopEffect(r.id)):(ed.setEffectVolumeByID(r.id,Math.abs(r.current)*ed.musicGlobalVolume),t++)):(r.current+=i,Math.abs(r.current)>=1?(this.fadeList.splice(t,1),ed.setEffectVolumeByID(r.id,ed.musicGlobalVolume)):(ed.setEffectVolumeByID(r.id,Math.abs(r.current)*ed.musicGlobalVolume),t++))}},_updateNext:function(e){if(this.music_next&&this.music_next.timetoplay>0){var t=this.music_next;this.music_next.timetoplay-=e,t.timetoplay<=0&&(this.music_next=null,this._playMusic(t.musicconfig,!0),this._processNext(t.musicconfig),this._skinID&&this._unisonID&&this.playSkinMusicWithUnison(this._skinID))}},_updateSeq:function(e){if(ed.SoundCDSequences.length>0)for(var t=0;t<ed.SoundCDSequences.length;t++){var r=ed.SoundCDSequences[t];if(r.length>2){var i=Number(r[1]);if((i-=1e3*e)<0){var a=Number(r[0])*(1-Math.random()/10);r[1]=a.toString(),ed.playEffect(r[2]),r.splice(2,1)}else r[1]=i.toString()}}},_updateSoundList:function(e){for(var t in this.polyList)for(var r=this.polyList[t],i=0;i<r.length;)-1==r[i].timer?i++:r[i].timer<e?(this.data[r[i].name]&&ed.stopEffect(r[i].sound),r.splice(i,1)):(r[i].timer-=e,i++)},removeSoundByID:function(e){for(var t in this.polyList){for(var r=this.polyList[t],i=!1,a=0;a<r.length;a++)if(r[a].sound===e){this.polyList[t].splice(a,1),i=!0;break}if(i)break}},getSoundbyID:function(e){for(var t in this.polyList){for(var r=this.polyList[t],i=0;i<r.length;i++)if(r[i].sound===e)return r[i];!1}return null},getCurrentTime:function(e){return cc.audioEngine.getCurrentTime&&e?cc.audioEngine.getCurrentTime(e):0},setCurrentTime:function(e,t){cc.audioEngine.setCurrentTime&&e&&void 0!==t&&cc.audioEngine.setCurrentTime(e,t)},playSkinMusicWithUnison:function(e){var t=ed.getDataTable("SoundUnison")[e],r=ed.bgm.currentBGM,i=null,a=null;if(t){for(var n=Object.keys(t),o=0;o<n.length;o++){var s=n[o];if(i=t[s].BGM,r&&i===r.key)return a=t[s].Unison,this._skinID=e,void this._playUnison(r.id,a)}if(n.length>0){var l=n[0];i=t[l].BGM,a=t[l].Unison,this._skinID=e,this.playMusic(i);var c=ed.bgm.currentBGM?ed.bgm.currentBGM.id:0;this._playUnison(c,a)}}else this._unisonID&&this.resetUnison(),(!r||"HeroBagIntro"!==r.key&&"HeroBagLoop"!==r.key)&&this.playMusic("HeroBagIntro")},_playUnison:function(e,t){if(e&&t&&(!this._unisonName||this._unisonName!==t)){this._unisonName=t,this._unisonID=ed.playEffect(t);var r=this.getCurrentTime(e);this._unisonID&&r&&(this.setCurrentTime(this._unisonID,r),ed.fadeInSound(this._unisonID,1))}},resetUnison:function(){this._unisonID&&ed.fadeOutSound(this._unisonID,-.5),this._unisonName=null,this._unisonID=null,this._skinID=null},_polyphonyCanPlay:function(e){var t=4,r=this.polyList[e];if(r&&r.length&&this.data[e]){var i=this.data[e].Poly;return i&&(t=i),r.length<t||-1==t||(new Date).getTime()-r.LastPlayTime>450&&(ed.stopEffect(r[0].sound),r.splice(0,1),!0)}return!0},polyphonyInsert:function(e,t,r){if(null!==t){var i={};void 0===this.polyList[e]&&(this.polyList[e]=new Array),r?i.timer=r:this.data[e]?i.timer=this.data[e].Length/1e3:i.timer=-1,i.sound=t,i.name=e,this.polyList[e].LastPlayTime=(new Date).getTime(),this.polyList[e].push(i)}},update:function(e){this._updateSeq(e),this._updateSound(e),this._updateSFX(e),this._updateNext(e),this._updateFadeSFX(e),this._updateSoundList(e),this.miniDaw.update(e)}}));}
function __nativeFactory2(){return (function(e,t,r,i){if(r||(r=e),-1!=i&&!ed.sound_manager._polyphonyCanPlay(r))return-1;var a=null;if(ed.audio_effect_switch){var n=ed.soundAutoFormat(e);if(cc.sys.jsb)ed.isFileExistCheckMD5(n)?a=cc.audioEngine.playEffect(n,t):hg.ResourceManager.getInstance().loadResourceFile(n,(function(e,t,r){}));else a=cc.audioEngine.playEffect(n,t)}return t||ed.sound_manager.polyphonyInsert(r,a,i),a});}
function __nativeFactory3(){return (function(e){if(ed.battleEngine.playSound&&e){var t=ed.getDataTable("SoundBattle")[e];if(t){var r=t.Res;ed.battleEngine.running?ed.playAudioEffect(ed.soundAutoFormat(r),!1,e,5.5):cc.log("battle end, do not play effect.")}}});}
function __nativeFactory4(){return (cc.Class.extend({ctor:function(){ed.miniDaw=this,this.miniDawTick=0,this.miniDawTracks=[],this.miniDawScore=null,this.miniDawPlay=!1,this.isMiniDawInited=!1,this.timelineInfo={notePos:0,note16thInterval:120},this.timelineCallbackFunction=null,this.callbackType={notePosChange:1,Snote:2}},update:function(e){this._updateMiniDaw(e)},_updateMiniDaw:function(e){if(this.miniDawPlay&&(this.miniDawTick-=1e3*e,!(this.miniDawTick>0))){if(this.isMiniDawInited){if(this.timelineInfo.notePos>Object.getOwnPropertyNames(this.miniDawScore).length-2)return this.timelineInfo.notePos=1,void ed.setMusicVolume(1);this._playNote(this.miniDawScore[this.timelineInfo.notePos]),this._timelineCallback(this.callbackType.notePosChange,this.timelineInfo.notePos),1==this.timelineInfo.notePos&&ed.setMusicVolume(.1),this.timelineInfo.notePos++}else this.initDaw(this.miniDawScore);this.miniDawTick=this.timelineInfo.note16thInterval}},_playNote:function(e){if(e)for(var t,r=1;r<Object.getOwnPropertyNames(e).length;r++)"S"!=(t=e[r])&&(t&&"0"!=t?this.miniDawTracks[r-1].sound=ed.playEffect(this.miniDawTracks[r-1].instrument+"-"+t):"0"==t&&ed.stopEffect(this.miniDawTracks[r-1].sound))},_timelineCallback:function(e,t){"function"==typeof this.timelineCallbackFunction&&this.timelineCallbackFunction(e,t)},setCallback:function(e){this.timelineCallbackFunction=e},initDaw:function(){if(this.miniDawScore){this.miniDawTracks=[],this.timelineInfo.notePos=1;for(var e=0;e<Object.getOwnPropertyNames(this.miniDawScore[0]).length-1;e++){var t={};t.instrument=this.miniDawScore[0][e+1],t.sound=null,this.miniDawTracks.push(t)}this.isMiniDawInited=!0}else this.isMiniDawInited=!1},recordCompose:function(e){var t=e.split(",");this.miniDawScore={};var r=[],i=[];r.push("NoteOrder");for(var a=0;a<t.length;a++){var n=t[a].split("_");(s={}).instrument=n[0],s.notes=n,i.push(s)}var o=1;for(var s in i)r.push("Track"+o),o++;for(var l=!1,c=0;!l;){var d={};d[r[0]]=c,l=!0;for(var u=1;u<r.length;u++)i[u-1].notes[c]&&(d[r[u]]=i[u-1].notes[c],l=!1);this.miniDawScore[c]=d,c++}},play:function(){this.miniDawPlay=!0},stop:function(){this.miniDawPlay=!1,ed.setMusicVolume(1)}}));}
function __nativeFactory5(){return (1);}
function __nativeFactory6(){return (1);}
function __nativeFactory7(){return (Number.MAX_VALUE);}
function __nativeFactory8(){return (.375);}
function __nativeFactory9(){return ({player:1,enemy:-1,both:0});}
function __nativeFactory10(){return (-1800);}
function __nativeFactory11(){return (-1);}
function __nativeFactory12(){return (0);}
function __nativeFactory13(){return (1);}
function __nativeFactory14(){return (2);}
function __nativeFactory15(){return (3);}
function __nativeFactory16(){return (4);}
function __nativeFactory17(){return (5);}
function __nativeFactory18(){return (6);}
function __nativeFactory19(){return (7);}
function __nativeFactory20(){return ({});}
function __nativeFactory21(){return (function(e){for(var t=e.constructor?new e.constructor:{},r=Object.keys(e),i=0;i<r.length;i++){var a=r[i],n=e[a];t[a]="object"==typeof n&&n?ed.copyObj(n):n}return t});}
function __nativeFactory22(){return (function(e){return ed.copyObj(e)});}
function __nativeFactory23(){return (function(e){return ed.copyObj(e)});}
function __nativeFactory24(){return (function(e,t){t||(t=function(e,t){return e-t});for(var r=e.length,i=0;i<r;i++){for(var a=e[i],n=i-1;n>=0;n--){var o=e[n];if(!(t(o,a)>0))break;e[n+1]=o}e[n+1]=a}});}
function __nativeFactory25(){return (function(){var e=random_seed*multiplier%moder,t=e/moder;return random_seed=e,ed.btLog.append("rand --\x3e "+t),t});}
function __nativeFactory26(){return (function(e){ed.init_battle_seed=e,e&&0!==e||(cc.error("Error:srand(0)"),e=1),e=Math.floor((moder-e)/e),ed.btLog.append("srand --\x3e "+e),random_seed=e});}
function __nativeFactory27(){return (function(e){try{return Array.prototype.slice.call(e)}catch(a){for(var t=[],r=0,i=e.length;r<i;r++)t[r]=e[r];return t}});}
function __nativeFactory28(){return (function(e,t){return function(r,i,a,n,o){var s=this;switch(arguments.length){case 0:return t(e,s);case 1:return t(e,s,r);case 2:return t(e,s,r,i);case 3:return t(e,s,r,i,a);case 4:return t(e,s,r,i,a,n);case 5:return t(e,s,r,i,a,n,o);default:var l=ed.arg2arry(arguments);return l.unshift(s),l.unshift(e),t.apply(null,l)}}});}
function __nativeFactory29(){return (function(e){var t=ed.getBtScene();if(t&&"string"==typeof e&&"function"==typeof t[e])switch(arguments.length){case 1:return t[e]();case 2:return t[e](arguments[1]);case 3:return t[e](arguments[1],arguments[2]);case 4:return t[e](arguments[1],arguments[2],arguments[3]);case 5:return t[e](arguments[1],arguments[2],arguments[3],arguments[4]);case 6:return t[e](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);case 7:return t[e](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6]);case 8:return t[e](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6],arguments[7]);case 9:return t[e](arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6],arguments[7],arguments[8]);default:var r=ed.arg2arry(arguments);return r.shift(),t[e].apply(t,r)}});}
function __nativeFactory30(){return (function(e,t,r,i,a){switch(t){case"rectangle":return e[0]>=0&&e[0]<=r&&e[1]>=.5*-i&&e[1]<=.5*i;case"circle":return e[0]*e[0]+e[1]*e[1]<=r*r;case"halfcircle":return e[0]>=0&&e[0]*e[0]+e[1]*e[1]<=r*r;case"reversehalfcircle":return e[0]<0&&e[0]*e[0]+e[1]*e[1]<=r*r;case"quartercircle":return e[0]>=0&&e[1]<=e[0]&&e[1]>=-e[0]&&e[0]*e[0]+e[1]*e[1]<=r*r;case"sector":return e[0]>=0&&Math.abs(e[1])<=Math.tan(i/360*Math.PI)*e[0]&&e[0]*e[0]+e[1]*e[1]<=r*r;case"asymsector":return e[0]*e[0]+e[1]*e[1]<=r*r&&(e[1]>=0&&180*Math.atan2(e[1],e[0])/Math.PI<=i||e[1]<0&&180*Math.atan2(e[1],e[0])/Math.PI>=a);default:cc.error("Unknown AOE Type: "+t+" spelling mistake?")}});}
function __nativeFactory31(){return (function(e){return e?parseInt(e):e});}
function __nativeFactory32(){return (function(e,t,r,i,a){if(e>=t&&e>=i){if(t>=i)return r;if(i>=t)return a}if(e<=t&&e<=i){if(t<=i)return r;if(i<=t)return a}return t===i?r:r+(a-r)/(i-t)*(e-t)});}
function __nativeFactory33(){return (function(e,t){var r=Math.floor(Math.max(e,t)),i=Math.ceil(Math.min(e,t));return i+Math.floor(ed.rand()*(r-i+1))});}
function __nativeFactory34(){return (function(e,t){if(e instanceof Array){for(var r=0;r<e.length;r++){if(e[r]===t)return!0}return!1}});}
function __nativeFactory35(){return (function(e){if(ed.battleEngine){var t=ed.battleEngine.getStageRect();if(t&&!(!e instanceof Array)&&2===e.length)return e[0]=Math.min(t.maxX,Math.max(t.minX,e[0])),e[1]=Math.min(t.maxY,Math.max(t.minY,e[1])),e}});}
function __nativeFactory36(){return (function(e,t){var r=2;r+=1*(e.attribs.CRITP-t.attribs.CRITD)/100;var i=2.9;return i+=e.attribs.CRITPLU/100||0,i=Math.max(i,1.1),r=Math.min(i,Math.max(1.1,r))});}
function __nativeFactory37(){return (function(e,t,r){var i=1;if(!e||!t)return i;var a=t.attribs.ICTRL-e.attribs.DCTRL;r&&r.shortenByDK&&"number"==typeof r.shortenDebuffIdx&&(a-=r.shortenDebuffIdx);var n=1*a;return n<-50&&(n=-50),n>100&&(n=100),i=1/(1+n/100)});}
function __nativeFactory38(){return (function(e,t,r){var i=1;if(!e||!t)return i;var a=1*(e.attribs.IPOS||0);return a<-50&&(a=-50),a>100&&(a=100),i=1/(1+a/100)});}
function __nativeFactory39(){return (function(){return ed.battleEngine.config&&ed.battleEngine.config.infl_weight||0});}
function __nativeFactory40(){return (function(e,t){var r=ed.getStageFixLv();if(!(r=r||0))return e;var i=ed.getDataTable("StrategyRed")[r]||{},a=t===ed.battle_camp.player?1:-1;if(a*r>0){var n=i[1]?i[1].Value:0,o=i[2]?i[2].Value:0;e+=Math.min((1-e)*o,n*o*e)}else if(a*r<0){n=i[3]?i[3].Value:0,o=i[4]?i[4].Value:0;e-=Math.min((1-e)*n,o*e)}return e});}
function __nativeFactory41(){return ({CRIT:{atk:"onCheckCrit",def:"onCheckBeCrit"}});}
function __nativeFactory42(){return (function(e,t,r,i,a){var n,o,s;if(s=r&&r.buff_list)for(n=0;n<s.length;n++)(o=s[n])&&o[t.atk]&&(e=o[t.atk](e,a));if(s=i&&i.buff_list)for(n=0;n<s.length;n++)(o=s[n])&&o[t.def]&&(e=o[t.def](e,a));return e});}
function __nativeFactory43(){return (function(e,t,r){var i=ed.getStageFixLv();if(!(i=i||0))return e;var a=ed.getDataTable("StrategyRed")[i]||{},n=a[10]?a[10].Value:0;if(ed.battleEngine.ticks<8*n)return e;var o=0;return r===ed.battle_camp.player?"caster"===t?o=a[11]?a[11].Value:0:"victim"===t&&(o=a[12]?a[12].Value:0):"caster"===t?o=a[13]?a[13].Value:0:"victim"===t&&(o=a[14]?a[14].Value:0),e*=1+o});}
function __nativeFactory44(){return (function(e,t){var r=ed.getStageFixLv();if(!(r=r||0))return e;var i=ed.getDataTable("StrategyRed")[r]||{},a=i[20]?i[20].Value:0;if(ed.battleEngine.ticks<8*a)return e;return e*=1+(t===ed.battle_camp.player?i[21]?i[21].Value:0:i[22]?i[22].Value:0)});}
function __nativeFactory45(){return (function(e,t){var r=ed.getStageFixLv();if(!(r=r||0))return e;var i=t.caster;if(i.camp===ed.battle_camp.player)return e;if(t===i.basic_skill)return e;var a=ed.getDataTable("StrategyRed")[r]||{},n=a[30]?a[30].Value:0;return ed.battleEngine.ticks<8*n?e:e*=1+(a[31]?a[31].Value:0)});}
function __nativeFactory46(){return (function(e,t){return[e[0]+t[0],e[1]+t[1]]});}
function __nativeFactory47(){return (function(e,t){return[e[0]-t[0],e[1]-t[1]]});}
function __nativeFactory48(){return (function(e,t){return[e[0]-t[0],e[1]-t[1]]});}
function __nativeFactory49(){return (function(e,t){return[e[0]*t,e[1]*t]});}
function __nativeFactory50(){return (function(e){var t=e[0],r=e[1];return t*t+r*r});}
function __nativeFactory51(){return (function(e,t){var r=e[0]-t[0],i=e[1]-t[1];return r*r+i*i});}
function __nativeFactory52(){return (function(e){var t=e[0],r=e[1],i=1/Math.pow(t*t+r*r,.5);return 0===t&&0===r?[1,0]:[t*i,r*i]});}
function __nativeFactory53(){return (function(e,t){return[e[0]*t[0],e[1]*t[1]]});}
function __nativeFactory54(){return ([0,0]);}
function __nativeFactory55(){return (function(){var e=arguments;if(0==e.length)return null;var t=null;try{t=ed.getDataTable(e[0])}catch(t){for(var r="getDataTableCatchError:",i=0;i<e.length;i++)r+=" Param"+i+": "+e[i];return ed.logbugly(r),null}for(var a=e[1],n=[],o=2;o<e.length;o++){var s=e[o];if((s||0===s)&&(n.push(s),!(t=t[s])))return void window.wx}return a?t[a]:t});}
function __nativeFactory56(){return (function(e){var t=ed.swallowCopyObject(e);return t.wrap_stack=[],t.wrapTable=function(e,t){for(var r=Object.keys(e),i=-1,a={};++i<r.length;){var n=r[i];a[n]=this[n],this[n]=e[n]}return this.wrap_stack.push({o:e,p:a,l:t}),this.wrap_stack.length-1},t.recover=function(e){if(!((e=e||this.wrap_stack.length-1)<0)){var t=this.wrap_stack.length;if(!(e>=t))for(var r=t-1;r>=e;r--){var i=this.wrap_stack[r];if(i.l)return;for(var a in i.p)this[a]=i.p[a];this.wrap_stack.pop()}}},t});}
function __nativeFactory57(){return (function(e){var t=ed.swallowCopyObject(e);for(var r in t)t[r]instanceof Array&&(t[r].__proto__=readonlyArrayProto);return t.wrap_stack=[],t.wrapTable=function(e,t){for(var r=Object.keys(e),i=-1,a={};++i<r.length;){var n=r[i];a[n]=this[n],this[n]=e[n]}return this.wrap_stack.push({o:e,p:a,l:t}),this.wrap_stack.length-1},t.recover=function(e){if(!((e=e||this.wrap_stack.length-1)<0)){var t=this.wrap_stack.length;if(!(e>=t))for(var r=t-1;r>=e;r--){var i=this.wrap_stack[r];if(i.l)return;for(var a in i.p)this[a]=i.p[a];this.wrap_stack.pop()}}},t});}
function __nativeFactory58(){return (cc.Class.extend({_data:null,_originalData:null,_isSendEvent:!1,ctor:function(e){e&&(this._originalData=e,this._data=ed.copyObj(e)),this.resonate()},modify:function(e,t){if(this._isSendEvent)this._data.id},setIsSendEvent:function(e){this._isSendEvent=e},isEnhancementMaterial:function(e){var t=ed.getDataTable("EquipQuality"),r=this.quality;return!!t[r].EnhancementValue&&!(r>9&&0!==this.getHeroTag())},isNoTagSuperEquip:function(){return this.quality>9&&0===this.getHeroTag()},hasTagSuperEquip:function(){return this.quality>=9&&0===this.getHeroTag()},getEnhancementValue:function(){var e=ed.getDataTable("EquipQuality"),t=ed.getDataTable("EquipEnhancement"),r=this.quality,i=this.enhance_lv-1,a=0;a+=e[r].EnhancementValue,a+=this.enhance_exp||0;for(var n=i;n>=0;n--){var o=t[r];o&&(o=o[n])&&(a+=o.EnhancementExp)}return a},getMaxEnhanceLevel:function(){return ed.getDataTable("EquipQuality")[this.quality].MaxEnhanceLevel},IsCanNextEnhanceLevel:function(){if(this.enhance_lv<this.getMaxEnhanceLevel()){var e=ed.getDataTable("EquipEnhancement"),t=ed.player.getEnchantingValueCanUsed(),r=e[this.quality][this.enhance_lv].EnhancementExp,i=e[this.quality][this.enhance_lv].CostPerExp[2]*r;if(t>=(r-=this.enhance_exp)&&ed.player.getGold()>=i)return!0}return!1},getIsMaxEnhanceLevel:function(){var e=this.enhance_lv;return this.getMaxEnhanceLevel()==e},getName:function(){return ed.getDataTable("Equip")[this.cfg_id].Name},getPosition:function(){return ed.getDataTable("Equip")[this.cfg_id].Position},getTagBonusRate:function(){return ed.getDataTable("Equip")[this.cfg_id].TagBonusRate-1},getBaseAttribute:function(){for(var e={},t=ed.attrib_names,r=ed.getDataTable("Equip")[this.cfg_id],i=0;i<t.length;i++){var a=t[i];r[a]&&r[a]>0&&(e[a]=Math.floor(10*r[a])/10)}return e},getEnhanceAttribute:function(){for(var e={},t=ed.attrib_names,r=ed.getDataTable("Equip")[this.cfg_id],i=0;i<t.length;i++){var a=t[i],n="Add"+t[i];r[n]&&r[n]>0&&(e[a]=Math.floor(10*r[n])/10*this.enhance_lv)}return e},getTag:function(){return this.getHeroTag()},getAttribute:function(){var e={},t=this.getBaseAttribute(),r=this.getEnhanceAttribute();for(var i in t)e[i]=t[i]+(r[i]||0);return e},getHeroTag:function(){var e=(this._data.attrs||{}).hero_tag;return e||0},setHeroTag:function(e){this._data.attrs||(this._data.attrs={}),this._data.attrs.hero_tag=e},getOriginalHeroTag:function(){return this._originalData&&this._originalData.attrs?this._originalData.attrs.hero_tag:null},getHeroTidTag:function(){var e=(this._data.attrs||{}).hero_tid;return e||0},setHeroTidTag:function(e){this._data.attrs&&(this._data.attrs.hero_tid=e)},getResonateTid:function(){return this._data.resonate_tid},resonate:function(){if(this._data&&this._data.resonate_tid&&!this._data.resonate_exchanged){var e=this._data.resonate_tid;ed.equipResonateMgr.getResonateEnhanceLevel(e,"heroTag")||this._data.attrs&&this._data.attrs.hero_tid&&delete this._data.attrs.hero_tid;var t=ed.equipResonateMgr.getResonateEnhanceLevel(e,"enhance");this._data.enhance_lv=t;var r=this._data.tid;this._data.tid=this._data.resonate_tid,this._data.resonate_tid=r,this._data.resonate_exchanged=!0}},clone:function(){var e=this._data?this._data:{},t=JSON.parse(JSON.stringify(e)),r=new ed.equipData(t);return ed.equipData.setAndGet(r),r}}));}
function __nativeFactory59(){return (function(e){Object.defineProperty(e,"id",{get:function(){return this._data.id},set:function(e){this._data.id=e}}),Object.defineProperty(e,"uniq",{get:function(){return this._data.id},set:function(e){this._data.id=e}}),Object.defineProperty(e,"tid",{get:function(){return this._data.tid},set:function(e){this._data.tid=e}}),Object.defineProperty(e,"cfg_id",{get:function(){return this._data.tid},set:function(e){this._data.tid=e}}),Object.defineProperty(e,"enhance_lv",{get:function(){return this._data.enhance_lv||0},set:function(e){this._data.enhance_lv=e,this.modify("enhance_lv",e)}}),Object.defineProperty(e,"quality",{get:function(){var e=this._data.tid;return ed.getDataTable("Equip")[e].Quality}}),Object.defineProperty(e,"gs",{get:function(){this._data.tid;var e=ed.getDataTable("Equip"),t=Number(e[this.cfg_id].GS)*(1+.1*this.enhance_lv);return t=Math.floor(10*t)/10}}),Object.defineProperty(e,"enhance_exp",{get:function(){return this._data.enhance_exp||0},set:function(e){this._data.enhance_exp=e,this.modify("enhance_exp",e)}}),Object.defineProperty(e,"amount",{get:function(){return this._data.amount||0},set:function(e){this._data.amount=e,this.modify("amount",e)}}),Object.defineProperty(e,"attrs",{get:function(){var e=[];if(this._data.attrs){var t=0;for(var r in this._data.attrs)"hero_tid"!=r?e.push({type:r,value:this._data.attrs[r]}):t=this._data.attrs[r];t&&e.push({type:"hero_tid",value:t})}return e},set:function(e){this._data.attrs=e,this.modify("attrs",e)}}),Object.defineProperty(e,"refine_tag",{get:function(){return this._data.refine_tag||0},set:function(e){this._data.refine_tag=e,this.modify("refine_tag",e)}}),Object.defineProperty(e,"resonate_tid",{get:function(){return this._data.resonate_tid||null},set:function(e){this._data.resonate_tid=e,this.modify("resonate_tid",e)}}),Object.defineProperty(e,"source_tid",{get:function(){return this._data.source_tid||null},set:function(e){this._data.source_tid=e,this.modify("source_tid",e)}})});}
function __nativeFactory60(){return (function(e){var t=new ed.equipData(e);return ed.equipData.setAndGet(t),t});}
function __nativeFactory61(){return (cc.Class.extend({_data:null,_isSendEvent:!1,ctor:function(e){this._data=e},modify:function(e,t){if(this._isSendEvent)this._data.id},setIsSendEvent:function(e){this._isSendEvent=e},clone:function(){var e=this._data?this._data:{},t=JSON.parse(JSON.stringify(e)),r=new ed.signatureData(t);return ed.signatureData.setAndGet(r),r}}));}
function __nativeFactory62(){return (function(e){Object.defineProperty(e,"tid",{get:function(){return this._data.tid},set:function(e){this._data.tid=e}}),Object.defineProperty(e,"lv",{get:function(){return this._data.lv},set:function(e){this._data.lv=e}}),Object.defineProperty(e,"isValid",{get:function(){if(this._data.isNpc)return!0;var e=ed.lookupDataTable("SignaturePower","QualityLimit",0);return this._data.quality>=e}})});}
function __nativeFactory63(){return (function(e){var t=new ed.signatureData(e);return ed.signatureData.setAndGet(t),t});}
function __nativeFactory64(){return (cc.Class.extend({ctor:function(e){this._ui_res=e,this.initCtor(e),this.onBind()},_initAutoEvent:function(){for(var e=Object.getPrototypeOf(this),t=Object.getOwnPropertyNames(e),i=0;i<t.length;i++){var n=t[i];"function"==typeof this[n]&&-1!==n.indexOf("_",2)&&this.addEvent(n,function(e){return function(t){this[e](t)}}(n).bind(this))}},initRoot:function(e){this.root=new ccui.Widget,this.root.setAnchorPoint(cc.p(0,0)),this.setIndependentNode(!0)},initUiEdtor:function(e){e&&(this.ui_editor=ed.uieditor.create(e),this.root.addChild(this.ui_editor.node),this.root.setContentSize(this.ui_editor.node.getContentSize()))},getUiRes:function(){return this.ui_editor&&this.ui_editor.uiName},initCtor:function(e){if(!cc.sys.jsb){var t=this.constructor;if(!t.__classNameResolved){for(var i in ed)if(ed[i]===t){t.prototype._className=i;break}t.__classNameResolved=!0}}this.initRoot(),this.initUiEdtor(e),this.root.bcmpt=this,this.is_start=!1,this.component_list=[],this.is_destory=!1,this.isSetDestroy=!1,this.parent=null,this.pt_index=null,this.componment_change=!1,this.touch_list=[],this.module_name="",this.music_name=null,this.isOnShow=!0,this._destructed=!1,this._grabageCollectEnabled=!1,this._musicEnabled=!0,this._isScene=!1,this._forceUpdate=!1,this._enable_update=!1,this._effect_list=[],this._event_list=[],this.scheduleIds=[],this.registerHandler(),this.initComponentExtras()},isEnableUpdate:function(){return this._enable_update},registerUpdate:function(){this._enable_update||(this._enable_update=!0)},removeUpdate:function(){this.is_start&&!this._enable_update||(this._enable_update=!1,ed.updateScheduler.removeCmpt(this))},setMusic:function(e){this.music_name=e},setName:function(e){this.module_name=e},getName:function(){return this.module_name},setUiEditor:function(e){this.ui_editor&&(this.ui_editor.destroy(),this.ui_editor=null),this.ui_editor=e,this.root.addChild(this.ui_editor.node),this.root.setContentSize(this.ui_editor.node.getContentSize())},_start:function(){this.is_start||(""!==this.module_name&&(ed.viewController.enterModule(this.module_name),cc.onFlyResManager.onModuleEnter(this.module_name)),this.is_start=!0,this.start(),ed.uiAnimation.vx._onEnter(this))},_update:function(e){this.bfUpdate(e),this.onUpdate(e),this.afUpdate(e)},fixedUpdate:function(e){},_fixedUpdate:function(e){this.fixedUpdate(e),this._updateEffect(e)},UiUpdate:function(e){this._updateEffect(e)},_updateEffect:function(e){for(var t=[],i=this._effect_list.length;i>0;){var n=this._effect_list[--i];if(n.update&&n.update(e),n.isTerminated&&n.isTerminated())n.destroy&&n.destroy(),(n.node||n).removeFromParent(!0);else t.push(n)}this._effect_list=t},addEffect:function(e,t,i){e&&(t=t||this.getRoot(),i=i||0,this._effect_list.push(e),t.addChild(e.node||e,i))},removeEffect:function(e){var t=this._effect_list.indexOf(e);t>-1&&(this._effect_list.splice(t,1),e.destroy&&e.destroy(),(e.node||e).removeFromParent(!0))},removeAllEffect:function(){for(var e=0;e<this._effect_list.length;){var t=this._effect_list[e++];t.destroy&&t.destroy();var i=t.node||t;cc.sys.isObjectValid(i)&&i.getParent()&&i.removeFromParent()}this._effect_list=[]},runAction:function(e){this.root.runAction(e)},stopAllActions:function(){this.root.stopAllActions()},_destory:function(){this.destroySelf(),this.unscheduleAllCallbacks(),this.root.removeFromParent(!0)},destroySelf:function(){this.removeUpdate(),this.root.bcmpt=null,this.is_destory=!0,this.destory(),this.destroy(),this.ui_editor&&(this.ui_editor.destroy(),this.ui_editor=null),this.removeAllEffect(),this.removeAllEvent(),this.unregisterAllSchedule(),this.popMusic(),null!==this.audio&&void 0!==this.audio&&(ed.stopEffect(this.audio),this.audio=null),""!==this.module_name&&(ed.viewController.exitModule(this.module_name),cc.onFlyResManager.onModuleExit(this.module_name)),this.removeAllComponent(),this.destroyEnd(),this.removeResource()},destroyEnd:function(){},removeAllEvent:function(){for(var e=0;e<this._event_list.length;e++){var t=this._event_list[e];cc.eventManager.removeListener(t)}this._event_list=[]},popMusic:function(){ed&&ed.sound_manager&&this._musicEnabled&&ed.sound_manager.popMusic(this.music_name)},removeAllComponent:function(){this.remvoeAllComponents()},remvoeAllComponents:function(){for(var e=this.component_list.length-1;e>=0;e--){this.component_list[e]._destory()}this.component_list=[],this.componment_change=!0,this.recoverMusic()},removeEvent:function(e){cc.eventManager.removeListener(e);var t=this._event_list.indexOf(e);-1!==t&&this._event_list.splice(t,1)},removeEventByName:function(e){if(e)for(var t=0;t<this._event_list.length;t++){var i=this._event_list[t];(i.eventName&&i.eventName===e||i._getListenerID&&i._getListenerID()===e)&&(this.removeEvent(i),t--)}},addEvent:function(e,t,i){var n=cc.eventManager.addCustomListener(e,(function(e){var i=e.getUserData();t(i)}),i);return this._event_list.push(n),n},listenEvent:function(e,t,i){return this.addEvent(e,t,i)},fireEvent:function(e,t){cc.eventManager.dispatchCustomEvent(e,t)},playMusic:function(){var e=null;this.music_name&&(e=this);for(var t=0;t<this.component_list.length;){var i=this.component_list[t++];i.music_name&&(e=i)}e&&this.scheduleOnce((function(){ed&&ed.sound_manager&&ed.sound_manager.playMusic(e.music_name)}))},start:function(){},setContentSize:function(e){this.getRoot().setContentSize(e)},setVisible:function(e){this.getRoot().setVisible(e)},isVisible:function(e){return cc.sys.jsb&&e?this.getRoot().isJsVisible():this.getRoot().isVisible()},setDestroy:function(){this.isSetDestroy=!0,this.removeFromParent(!0)},destory:function(){},destroy:function(){},bfUpdate:function(e){},onUpdate:function(e){},afUpdate:function(e){},onBind:function(e){},ignoreOpenAction:function(e){this.ignoreAction=e},_onEnter:function(){this.ui_editor&&(this.ignoreAction||ed.gui.showOpenAction(this.ui_editor.node,this.ui_editor.uiName,this.actionCallBack),this.RTLChange()),this.hasPlayMusic||(this.hasPlayMusic=!0,this.playMusic()),this.onEnter()},onEnter:function(){},_onExit:function(){this.onExit(),this.unregisterAllSchedule()},onExit:function(){},getContentSize:function(){return this.root.getContentSize()},getRoot:function(){return this.root},setRoot:function(e){this.root=e},addComponent:function(e,t,i){var n=i||this.root;null!=t?n.addChild(e.getRoot(),t):n.addChild(e.getRoot()),ed.updateScheduler.appendCmpt(e),this.component_list.push(e),e.parent=this,this.componment_change=!0},insertComponent:function(e,t,i,n){var a=i||this.root;null!=t?a.addChild(e.getRoot(),t):a.addChild(e.getRoot()),ed.updateScheduler.appendCmpt(e),this.component_list.splice(n,0,e),e.parent=this,this.componment_change=!0},addChild:function(e,t,i){if(e.bcmpt)this.addComponent(e.bcmpt,t,i);else{var n=i||this.root;null!=t?n.addChild(e,t):n.addChild(e)}},getParent:function(){return this.parent},recoverMusic:function(){var e=this.component_list;if(e.length>0){var t=e[e.length-1];this.hasPlayMusic||t.playMusic()}},removeComponent:function(e){e._destory();var t=this.component_list,i=t.indexOf(e);i>-1&&t.splice(i,1),this.componment_change=!0,e.music_name&&this.recoverMusic()},removeChild:function(e,t){(t||this.root).removeChild(e)},removeFromParent:function(e){var t=this.parent;t&&((e=e||!1)?t.removeComponent(this):t.removeComponentWithNoClear(this)),this.parent=null},removeComponentWithNoClear:function(e){if(cc.sys.jsb)this.removeComponent(e);else{e.root.removeFromParent(!0);var t=this.component_list,i=t.indexOf(e);i>-1&&t.splice(i,1),this.componment_change=!0,this.recoverMusic()}},uninstallCmpt:function(e){e.root.retain(),e.root.removeFromParent(!0),e.removeUpdate();var t=this.component_list,i=t.indexOf(e);i>-1&&t.splice(i,1),this.componment_change=!0,this.recoverMusic()},uninstallFromParent:function(){var e=this.parent;e&&(e.uninstallCmpt(this),this.parent=null)},registerTouch:function(e){this.touch_list.push(e)},setPosition:function(e){this.root.setPosition(e)},setAnchorPoint:function(e){this.getRoot().setAnchorPoint(e)},getPosition:function(){return this.root.getPosition()},setScale:function(e){this.root.setScale(e)},getScale:function(){return this.root.getScale()},setScaleX:function(e){this.root.setScaleX(e)},getScaleX:function(){return this.root.getScaleX()},setScaleY:function(e){this.root.setScaleY(e)},getScaleY:function(){return this.root.getScaleY()},setRotation:function(e){this.root.setRotation(e)},getRotation:function(){return this.root.getRotation()},setLocalZOrder:function(e){this.root.setLocalZOrder(e)},getLocalZOrder:function(){return this.root.getLocalZOrder()},setActionCallback:function(e){this.actionCallBack=e},initComponentExtras:function(){var e=ed.viewManager.parseComponentExtras(this);this._isFullScreen=e.isFullScreen,this._isBackground=e.isBackground,this._viewZOrder=e.zOrder},isFullScreen:function(){return this._isFullScreen},setIsFullScreen:function(e){this._isFullScreen=e||!1},isForceShow:function(){return this._forceShow},setForceShow:function(e){this._forceShow=e||!1},isBackground:function(){return this._isBackground},setIsBackground:function(e){this._isBackground=e||0},getViewZOder:function(){return this._viewZOrder},setViewZOrder:function(e){this._viewZOrder=e||ed.ZORDER_TYPE.NORMAL_LAYER},show:function(e,t,i){void 0!==e&&this.setViewZOrder(e),void 0!==t&&this.setIsFullScreen(t),void 0!==i&&this.setForceShow(i),ed.viewManager.pushView(this)},close:function(){ed.uiAnimation.vx._onExit(this)||ed.viewManager.popView(this)},onShow:function(){this.isOnShow=!0;for(var e=this.component_list.length-1;e>=0;e--){this.component_list[e].onShow()}},isShow:function(e){return this.isOnShow},onHide:function(){this.isOnShow=!1;for(var e=this.component_list.length-1;e>=0;e--){this.component_list[e].onHide()}},scheduleOnce:function(e,t){var i=this,n=1e3*(t||0);this.setTimeout((function(){i.is_destory||e&&e()}),n)},unscheduleAllCallbacks:function(){this.root.unscheduleAllCallbacks()},onBackEvent:function(){this.close()},registerSchedule:function(e){e&&this.scheduleIds.push(e)},setTimeout:function(e,t){var i=ed.setTimeout((function(){e&&e()}),t);return this.registerSchedule(i),i},unregisterSchedule:function(e){if(e){var t=this.scheduleIds.indexOf(e);t>-1&&(ed.clearTimeout(e),this.scheduleIds.splice(t,1))}},unregisterAllSchedule:function(){for(var e=0;e<this.scheduleIds.length;e++){var t=this.scheduleIds[e];t&&ed.clearTimeout(t)}this.scheduleIds=[]},_onDestruct:function(){this._destructed=!0},isDestructed:function(){return this.root.registerDestructCallback?this._destructed:!cc.sys.isObjectValid(this.root)},isRunning:function(){return this.getRoot().isRunning()},retain:function(){this.getRoot().retain()},release:function(){this.getRoot().release()},setGarbageCollectEnabled:function(e){this._grabageCollectEnabled=e},registerHandler:function(e){var t=this,i=this.root;if(cc.sys.jsb2?(i.registerOnEnterCallback((function(e){t._onEnter()})),i.registerOnExitCallback((function(e){t._onExit()}))):(i.__onEnter=i.onEnter,i.onEnter=function(){t.root.__onEnter(),t._onEnter()},i.__onExit=i.onExit,i.onExit=function(){t.root.__onExit(),t._onExit()}),(cc.sys.jsb1||cc.sys.jsb3)&&i.registerDestructCallback){i.registerDestructCallback((function(){var e=t.getName(),i=t.ui_editor?t.ui_editor.uiName:"",n=e||i;n&&cc.log("[baseComponent] {0} has been destructed!{1}".format([n,t.is_destory])),t._onDestruct()}))}},RTLChange:function(){ed.language_mgr.isRTLLanguage()&&!this._isRTLChanged&&(ed.initRTLStyle(this.root),this._isRTLChanged=!0)},setIndependentNode:function(e){this.root._isCsb=e},removeResource:function(e){var t=this.module_name;t&&ed.cacheManger.free(t)},setCascadeOpacityEnabled:function(e){this.getRoot().setCascadeOpacityEnabled(e)},setOpacity:function(e){this.getRoot().setOpacity(e)},setRecursiveOpacity:function(e){var t=this.getRoot();this._setRecursiveOpacity(t,e)},_setRecursiveOpacity:function(e,t){if(e){e.setCascadeOpacityEnabled(t);for(var i=e.getChildren(),n=0;n<i.length;n++){var a=i[n];this._setRecursiveOpacity(a,t)}}},getMusic:function(e){return this.music_name},setMusicEnabled:function(e){this._musicEnabled=e},isParentVisible:function(e){for(var t=this.getParent(),i=!0;t;){if(!t.isVisible(e)){i=!1;break}t=t.getParent()}return i},isScene:function(e){return this._isScene},getParentScene:function(e){for(var t=this.getParent(),i=null;t;){if(t.isScene()){i=t;break}t=t.getParent()}return i},forceUpdate:function(e){this._forceUpdate=e},isForceUpdate:function(e){return this._forceUpdate},registerFrameActionCallback:function(e){this.ui_editor.frameActionCallback=function(t){e&&e(t)}},playTimelineAction:function(e,t,i,n,a){this.ui_editor&&this.ui_editor.playTimelineAction(e,t,i,n,a)},getTimelineActionFrameCount:function(e){var t=0;return this.ui_editor&&(t=this.ui_editor.getTimelineActionFrameCount(e)),t},playTimelineActionWithDuration:function(e,t,i){this.ui_editor&&this.ui_editor.playTimelineActionWithDuration(e,t,i)},gotoFrame:function(e){this.ui_editor&&this.ui_editor.gotoFrame(e)},gotoFrameAndPause:function(e){this.ui_editor&&this.ui_editor.gotoFrameAndPause(e)},playNodeTimelineAction:function(e,t,i,n,a){this.ui_editor&&this.ui_editor.playNodeTimelineAction(e,t,i,n,a)},gotoNodeFrame:function(e,t){this.ui_editor&&this.ui_editor.gotoNodeFrame(e,t)},registerButtonClick:function(e,t){if(this.ui_editor){e=e||[],t=t||"_click";for(var i=this.ui_editor.getComponentsByType(ccui.Button),n=this,a=0;a<i.length;a++){var s=i[a].getName();if(!(e.length>0&&e.indexOf(s)>=0)){var o=s.toLowerCase()+t;this.ui_editor.initButton(s,{funcName:o,zoom:-.1,callback:function(e,t){var i=t.funcName;n[i]&&n[i](e)}})}}}}}));}
function __nativeFactory65(){return (ed.baseComponent.extend({_dc_callback:null,_dc_closed:!1,_black_panel:null,_scale_node:null,_color_panel:null,_is_no_openAction:!1,closeAction:!1,canClickPanel:!0,_stop_close_action:!0,_is_play_sound:!0,_dissable:!0,_bgView:null,close_sound:"ClickClose",close_callback:null,ctor:function(e){this._super(e),this.registerUpdate(),this.initBg(e),this.registerTouchListener(),this.initLocalData()},initLocalData:function(){this._dc_closed=!0,this._isOpenAction=!0,this.closeAction=!1,this._is_play_sound=!0,this._stop_close_action=!0,this._dissable=!0,this.canClickPanel=!0,this.customClickPanel=!1,this.customClickPanel_used=!1,this._clickStop=!1,this._clickStopFlag=!1,this._customClickPanelCallback=null,this._task_update_enabled=!1,this.checkComponentExtras()},initUiEdtor:function(e){var t=new cc.Node;t.setPosition(ed.view.CC),this.root.addChild(t),this._scale_node=t,e&&(this.ui_editor=ed.uieditor.create(e),this.ui_editor.node.setPosition(-cc.winSize.width/2,-cc.winSize.height/2),t.addChild(this.ui_editor.node))},enableGaussianBlur:function(){this._enable_gaussian_blur=!0},checkGaussianBg:function(){var e,t;cc.sys.jsb||(e=this.ui_editor&&this.ui_editor.uiName)&&((t=ed.getDataTable("ParamPopMode")[e])&&t.GaussianBg||cc.warn("策划看这里！！！！ {0}界面未配置高斯模糊背景，如果需要该效果，需要在ParamPopMode添加配置".format(e)));return!!ed.mainScene&&(!!this._enable_gaussian_blur||(!ed.viewManager.getTopView()||"battle_prepare"!==ed.viewManager.getTopView().getName())&&(!!(e=this.ui_editor&&this.ui_editor.uiName)&&(!(!(t=ed.getDataTable("ParamPopMode")[e])||!t.GaussianBg)||!(!this.ui_editor||!this.ui_editor.getComponent("GaussianBlur")&&!this.ui_editor.getComponent("gaussianblur")))))},createGaussianBg:function(){var e=this,t=cc.Node.create(),i=cc.size(cc.winSize.width/ed.display.design_scale,ed.display.height),n=ed.display.width/ed.display.design_scale,a=ed.display.height,s=0,o=cc.IMAGE_FORMAT_PNG;cc.sys.jsb?(o=cc.Texture2D.PIXEL_FORMAT_RGB888,s=gl.DEPTH24_STENCIL8_OES):s=cc._renderContext.STENCIL_INDEX;var r,c=ed.renderNode(n,a,(function(){ed.getCurrentScene().ccScene().visit()}),o,s);return t.setContentSize(i),(r=c).retain(),ed.sprGaussianBlur(r,20,1.5,(function(a){a.setContentSize(i);var s=(n/ed.display.design_scale-n)/2;a.setPosition(cc.p(i.width/2+s,i.height/2)),a.setScale(1/ed.display.design_scale),t.addChild(a,2);var o=new cc.LayerColor(cc.color(0,0,0,160));o.setContentSize(i),t.addChild(o,3);var c=0,l=e.ui_editor&&e.ui_editor.uiName;if(l&&(c=ed.lookupDataTable("ParamPopMode","GaussianBgFadeInTime",l)||0),c>0){var d=cc.Sprite.create();d.initWithTexture(r.getTexture()),d.setFlippedY(!0),d.setContentSize(i),d.setPosition(cc.p(i.width/2,i.height/2)),t.addChild(d,1),a.setOpacity(127.5);var h=cc.fadeIn(c);a.runAction(h),o.setOpacity(80),o.runAction(cc.fadeTo(c,160))}e._maskLayer=o,r.release()})),cc.sys.jsb&&cc.director.forceRender&&cc.director.forceRender(),this.setIsFullScreen(!0),t},initBg:function(){var e=void 0!==this.bgOpacity?this.bgOpacity:160;this._ui_res&&e>1&&ed.fireEvent("GAUSSIAN_SHOW_HANDLE",!1);var t=cc.size(cc.winSize.width/ed.display.design_scale,ed.display.height);if("slg_scene"!=ed.getCurrentScene().identity&&this.checkGaussianBg()){var i=this.createGaussianBg();(n=new ccui.Widget).addChild(i),n.setAnchorPoint(.5,.5),n.setPosition(ed.view.CC),n.setContentSize(t),this.root.addChild(n),n.setLocalZOrder(-1),this._black_panel=n,this._color_panel=i}else{var n;(i=new ccui.ImageView("res/ui/panel/common/item_bg.png")).setScale9Enabled(!0),i.setCapInsets(cc.rect(20,20,20,20)),i.setContentSize(t),i.setOpacity(e),i.setName("item_bg"),(n=ed.changeToWidget(i)).setAnchorPoint(.5,.5),n.setPosition(ed.view.CC),n.setContentSize(t),this.root.addChild(n),n.setLocalZOrder(-1),this._black_panel=n,this._color_panel=i}},registerTouchListener:function(){this._black_panel.setTouchEnabled(!0);var e=this;this._black_panel.addClickEventListener((function(){if(e.customClickPanel)e._customClickPanelCallback&&e._customClickPanelCallback();else if(e.canClickPanel){if(e.isClickStopEnabled()&&!e._clickStopFlag)return e._clickStopFlag=!0,void(e._clickStopCallback&&e._clickStopCallback());e._dc_callback&&e._dc_callback(),e.canClickPanel=!1,e.onTouchClose()}})),this.addEvent("GAUSSIAN_SHOW_HANDLE",(function(t){if(e._maskLayer)if(cc.sys.jsb){if(!cc.sys.isObjectValid(e._maskLayer))return;e._maskLayer.setOpacity(t?160:50)}else e._maskLayer.setVisible(t)}))},onTouchClose:function(){this.close()},getBgPanel:function(){return this._black_panel},addComponent:function(e,t,i){var n=i||this.ui_editor.node;this._super(e,t,n),e.pt_index=this.component_list.length-1},setIsPlaySound:function(e){this._is_play_sound=e},setCloseSound:function(e){e&&""!==e&&(this.close_sound=e)},setCloseCallBack:function(e){this.close_callback=e},_runOpenAction:function(){var e=this,t=new cc.scaleTo(.1,1.01,1.01),i=new cc.scaleTo(.1,1,1),n=new cc.CallFunc((function(){e.openActionCallback&&e.openActionCallback()})),a=new cc.Sequence(t,i,n);this._scale_node.setScale(1),this._scale_node.runAction(a),this._is_play_sound&&ed.playEffect(ed.sound.click_pop)},setDestroy:function(){this._super()},_runCloseAction:function(){var e=new cc.delayTime(.1),t=this,i=new cc.CallFunc((function(){t.setDestroy(),t.close_callback&&t.close_callback(),t.isTaskUpdateEnabled()&&ed.fireEvent(ed.activityTaskMgr.EVENT_TASK_UPDATE)})),n=new cc.Sequence(e,i);this._scale_node.runAction(n)},runScaleCloseAction:function(){var e=new cc.scaleTo(.2,0);e=e.easing(cc.easeBackIn());var t=this,i=new cc.CallFunc((function(){t.setDestroy(),t.close_callback&&t.close_callback(),t.isTaskUpdateEnabled()&&ed.fireEvent(ed.activityTaskMgr.EVENT_TASK_UPDATE)})),n=new cc.Sequence(e,i);this._scale_node.setScale(1),this._scale_node.runAction(n)},setClickPanelCallback:function(e){this._dc_callback=e},setCanClickPanel:function(e){this.canClickPanel=e},setOpenCloseAction:function(e){this.closeAction=e},setOpenAction:function(e){this._isOpenAction=e},setCustomClickPanel:function(e){this.customClickPanel=e},setCustomClickPanelCallback:function(e){this._customClickPanelCallback=e},show:function(e,t,i){this._super(e,t,i),this._is_no_openAction||this._runOpenAction()},showOpenAction:function(e){this._is_no_openAction=!e},performClose:function(){this._is_play_sound&&ed.playEffect(this.close_sound),this._dissable&&(this._dc_closed?(this.setDestroy(),this.close_callback&&this.close_callback(),this.isTaskUpdateEnabled()&&ed.fireEvent(ed.activityTaskMgr.EVENT_TASK_UPDATE)):(this.closeAction?this.runScaleCloseAction():this._runCloseAction(),this._dc_closed=!0),this._ui_res&&ed.fireEvent("GAUSSIAN_SHOW_HANDLE",!0))},setDCClosedEnabled:function(e){this._dc_closed=e},checkComponentExtras:function(){this._viewZOrder===ed.ZORDER_TYPE.NORMAL_LAYER&&this.setViewZOrder(ed.ZORDER_TYPE.DIALOG_LAYER)},setClickStopEnabled:function(e){this._clickStop=e},isClickStopEnabled:function(){return this._clickStop},setClickStopCallback:function(e){this._clickStopCallback=e},forceClickStop:function(e){this._clickStopFlag=e},setTaskUpdateEnabled:function(e){this._task_update_enabled=e},isTaskUpdateEnabled:function(e){return this._task_update_enabled}}));}
function __nativeFactory66(){return ({getHeroEquipsByLevel:function(e,t,i){var n=ed.lookupDataTable("Unit","HeroJob",e);"soldier"===n?n="tank":"assassin"===n?n="archer":"supporter"===n&&(n="magician");var a=ed.getDataTable("Equip"),s=[];for(var o in a){var r=a[o],c=Number(o);if(r.Job===n&&r.Quality===t){var l={id:c,tid:c,amount:1,attrs:[],enhance_lv:i,enhance_exp:0},d={index:r.Position,equip:ed.equipData.create(l)};s.push(d)}}return s},getHeroTags:function(e){return["All","Human","Orc","Elf","Undead","Devil","God","Cross"][e]},getAttributes:function(e,t){e=e.toUpperCase();var i=ed.getDataTable("UnitGS")[e];return i&&!i.IsHide?!0===t?i.ShortName:i.DisplayName:null},sortHeroList:function(e,t){e.length<=0||e.sort((function(e,i){var n=ed.hero.isExpiredFreeHero(e)?1:2,a=ed.hero.isExpiredFreeHero(i)?1:2;if(n!==a)return n-a;if(t){var s=ed.hero.isValidTrialHeroForTower(e,t)?1:2,o=ed.hero.isValidTrialHeroForTower(i,t)?1:2;if(s!==o)return s-o}var r=Math.max(e.level,e.pentagram_lv),c=Math.max(i.level,i.pentagram_lv);return r!=c?c-r:i.quality!=e.quality?i.quality-e.quality:e.gs!=i.gs?i.gs-e.gs:i.tid-e.tid}))},sortHeroListByType:function(e,t,i){if(!(e.length<=0))switch(t){case ed.heroSortType.Gs:e.sort((function(e,t){var n=ed.playerHero.getInstance().getPentagramPartnerHids(),a=n[e.id]?1:2,s=n[t.id]?1:2;if(a!==s)return a-s;var o=ed.hero.isExpiredFreeHero(e)?1:2,r=ed.hero.isExpiredFreeHero(t)?1:2;if(o!==r)return o-r;if(i){var c=ed.hero.isValidTrialHeroForTower(e,i)?1:2,l=ed.hero.isValidTrialHeroForTower(t,i)?1:2;if(c!==l)return c-l}var d=Math.max(e.level,e.pentagram_lv),h=Math.max(t.level,t.pentagram_lv);return e.gs!=t.gs?t.gs-e.gs:e.quality!=t.quality?t.quality-e.quality:d!=h?h-d:t.tid!=e.tid?t.tid-e.tid:t.id-e.id}));break;case ed.heroSortType.Quality:e.sort((function(e,t){var n=ed.playerHero.getInstance().getPentagramPartnerHids(),a=n[e.id]?1:2,s=n[t.id]?1:2;if(a!==s)return a-s;var o=ed.hero.isExpiredFreeHero(e)?1:2,r=ed.hero.isExpiredFreeHero(t)?1:2;if(o!==r)return o-r;if(i){var c=ed.hero.isValidTrialHeroForTower(e,i)?1:2,l=ed.hero.isValidTrialHeroForTower(t,i)?1:2;if(c!==l)return c-l}return e.quality!=t.quality?t.quality-e.quality:e.gs!=t.gs?t.gs-e.gs:e.tid!=t.tid?t.tid-e.tid:t.id-e.id}));break;case ed.heroSortType.Equipment:e.sort((function(e,t){var n=ed.playerHero.getInstance().getPentagramPartnerHids(),a=n[e.id]?1:2,s=n[t.id]?1:2;if(a!==s)return a-s;var o=ed.hero.isExpiredFreeHero(e)?1:2,r=ed.hero.isExpiredFreeHero(t)?1:2;if(o!==r)return o-r;if(i){var c=ed.hero.isValidTrialHeroForTower(e,i)?1:2,l=ed.hero.isValidTrialHeroForTower(t,i)?1:2;if(c!==l)return c-l}return!e.sig&&t.sig?1:e.sig&&!t.sig?-1:e.sig&&t.sig&&(e.sig.lv||0===e.sig.lv)&&(t.sig.lv||0===t.sig.lv)&&e.sig.lv!=t.sig.lv?t.sig.lv-e.sig.lv:e.gs!=t.gs?t.gs-e.gs:t.tid!=e.tid?t.tid-e.tid:t.id-e.id}));break;default:this.sortHeroList(e,i)}},setHeroSortType:function(e){this.heroSortType=e;var t=ed.player.getUid();window.localStorage.setItem("hero_sort_type_{0}".format(t),this.heroSortType)},getHeroSortType:function(){var e=ed.player.getUid(),t=window.localStorage.getItem("hero_sort_type_{0}".format(e));return t||(this.heroSortType||ed.heroSortType.Quality)},caculateAttribByEntity:function(e,t,i){return ed.hero.caculateAttrib(e,t,i)},caculateAttrib:function(e,t,i){t=t||{};var n=ed.copyHeroConfig(e);return n.troops=[],i?ed.astrolabe_ignore||(n.astrolabe={lv:ed.AstrolabeManager.getTreeLevel(),tag_lvs:ed.AstrolabeManager.getAllTagsLevel()}):ed.astrolabe_ignore||(n.astrolabe=t.astrolabe),t.bag_hero_list&&(n.bag_hero_list=t.bag_hero_list),void 0!==t.gs_guild_tech_exp&&(n.gs_guild_tech_exp=t.gs_guild_tech_exp),ed.unitAttribsMgr.getAttribsByHeroData(e,n)},searchSubStr:function(e,t){for(var i=[],n=[],a=e.indexOf(t);a>-1;){i.push(a),a=e.indexOf(t,a+1);var s=e.indexOf(",",a+1);s>-1&&n.push(s)}if(i.length!==n.length)return e;new RegExp("")},caculateGs:function(e,t,i){return ed.heroGSTools.calculateHeroGSByParts(e,t,i)},getAllBagSkills:function(){for(var e=[],t=ed.playerhero.getAllHeros(!0)||[],i={},n=0;n<t.length;n++){var a=t[n];if(ed.BagSkillData.hasBagSkill(a)){var s=a.tid,o=i[s],r=!o||a.quality>o.quality;!r&&o&&a.quality===o.quality&&(r=Number(a.id)<Number(o.id)),r&&(i[s]=a)}}for(var c in i)e.push(ed.BagSkillData.create({hero:i[c]}));return e},getAllSupportBonusAttribs:function(e){for(var t=e||[],i={},n=0;n<t.length;n++){var a=t[n];if(a){for(var s=a.getAttribs(),o={},r=[],c=0;c<s.length;c++){var l=s[c],d=this._getSupportBonusDisplayAttribType(l.type);if(this._isSupportBonusDisplayAttribDefined(d)){var h=this._getSupportBonusAttribMergeKey(d);h&&(o[h]?this._isPreferSupportBonusDisplayAttribType(l.type,o[h].sourceType)&&(o[h].type=d,o[h].sourceType=l.type,o[h].value=l.value):(o[h]={type:d,sourceType:l.type,value:l.value},r.push(h)))}else cc.error("SupportBonus missing UnitGS display config",l.type,d)}for(var u=0;u<r.length;u++){var p=r[u],_=o[p];i[p]||(i[p]={type:_.type,value:0}),i[p].value=parseFloat((i[p].value+_.value).toFixed(4))}}}for(var f=[],g=(ed.attrib_percent_names||[]).concat(ed.attrib_names||[]),m={},v=0;v<g.length;v++){var b=g[v],y=this._getSupportBonusAttribMergeKey(b);y&&i[y]&&0!==i[y].value&&!m[y]&&(f.push(i[y]),m[y]=!0)}return f},_isSupportBonusDisplayAttribDefined:function(e){if(!e)return!1;var t=this._getSupportBonusBaseAttribType(e);return!!(ed.getDataTable("UnitGS")||{})[t]},getAllBagSkillAttribs:function(e){return this.getAllSupportBonusAttribs(e||this.getAllBagSkills())},_getSupportBonusAttribMergeKey:function(e){if(!e)return null;var t=this._getSupportBonusDisplayAttribType(e),i=!1;return-1!==t.indexOf(".PR")&&(i=!0,t=t.substr(0,t.indexOf(".PR"))),(this.getAttributes(t,!0)||t)+(i?".PR":"")},_getSupportBonusDisplayAttribType:function(e){if(!e)return e;var t=e,i=!1;return-1!==t.indexOf(".PR")&&(i=!0,t=t.substr(0,t.indexOf(".PR"))),"MR"===t&&(t="ARM"),t+(i?".PR":"")},_isPreferSupportBonusDisplayAttribType:function(e,t){return"ARM"===this._getSupportBonusBaseAttribType(e)&&"MR"===this._getSupportBonusBaseAttribType(t)},_getSupportBonusBaseAttribType:function(e){return e&&-1!==e.indexOf(".PR")?e.substr(0,e.indexOf(".PR")):e},caculatePanelAttrib:function(e,t,i){return t=t?cc.clone(t):{},i&&(void 0===t.bag_hero_list&&(t.bag_hero_list=ed.BagSkillData.getSelfEntries()),void 0===t.gs_guild_tech_exp&&(t.gs_guild_tech_exp=ed.GuildTurntableTechMgr.getTechExp())),this.cacluteBaseAttrib(e,t,i)},calcSignatureGS:function(e){return ed.heroGSTools.calcSignatureGS(e)},calculateBaseGs:function(e){return ed.heroGSTools.calculateBaseGs(e,!1)},calcEquipT3GS:function(e,t){var i=this.calculateBaseGs(e),n=t.tid||t.cfg_id,a=ed.getDataTable("Equip")[n],s=a.HeroBonusRate,o=a.GS;return ed.player.isHeroTagMatch(e,t)?Math.floor(i*s/100+o):o},cacluteBaseAttrib:function(e,t,i){var n=this.caculateAttribByEntity(e,t,i),a=n.HP,s=n.ATK,o=n.ARM;return{hp:Math.floor(a),atk:Math.floor(s),def:Math.floor(o),attribs:n}},calculateGsWithoutTroops:function(e,t,i){ed.troops_ignore=!0;var n=this.caculateGs(e,t,i);return ed.troops_ignore=!1,n},calculateBaseAttribWithoutTroops:function(e,t,i){ed.troops_ignore=!0;var n=this.cacluteBaseAttrib(e,t,i);return ed.troops_ignore=!1,n},getHeroTagRes:function(e){var t=ed.getDataTable("UnitTag");return t[e]?t[e].Sign:null},getHeroTagBigRes:function(e){var t=ed.getDataTable("UnitTag");return t[e]?t[e].BountySign:null},getHeroBannerRes:function(e){return this.isHyperHero(e)?ed.getDataTable("HyperHero")[e.tid].HeroUI:ed.lookupDataTable("UnitTag","BoardRes",e.getTagID())},getHeroBgRes:function(e){if(this.isHyperHero(e))return ed.getDataTable("HyperHero")[e.tid].HeroBG;if(this.isTranscendentHero(e)){var t=e.getTag();return ed.transcHeroTagBgRes[t]||ed.transcHeroTagBgRes.Human}t=e.getTag();return ed.heroTagBgRes[t]||ed.heroTagBgRes.Human},getHeroTagResByTagName:function(e){var t=ed.getDataTable("UnitTag"),i="";for(var n in t)if(t[n].Name==e){i=t[n].Sign;break}return i},createHeroTagIcon:function(e){var t=this.getHeroTagRes(e);return/res\//.test(t)||(t="res/"+t),ed.createSprite(t)},getHeroTagResFormTid:function(e){var t=ed.getDataTable("Unit");if(t[e]){var i=t[e].HeroTagID;return this.getHeroTagRes(i)}return null},getHeroTag:function(e){var t=ed.getDataTable("Unit");return t[e]?t[e].HeroTagID:null},getHeroName:function(e){return ed.getDataTable("Unit")[e].DisplayName},getHeroTagName:function(e){var t=this.getHeroTag(e);return ed.getDataTable("UnitTag")[t].DisplayName},getHeroQualityName:function(e){return ed.getDataTable("UnitQualityLevel")[e].Name},getHeroQualityStar:function(e){return ed.getDataTable("UnitQualityLevel")[e].Star},getHeroBigTagRes:function(e){return ed.getDataTable("UnitTag")[e].BigSign},createHeroTag:function(e){var t=this.getHeroTagRes(e);if(/res\//.test(t)||(t="res/"+t),ed.USETEXTURECACHE)return ed.createSprite(t);var i=cc.Node.create();return i.retain(),ed.createAtlasSpriteAsync(t,[t],(function(){return ed.createSprite(t)}),(function(e){i.addChild(e),i.release()})),i},getQualityRes:function(e){return e<0?"res/ui/panel/common/n_heroframe_bg0_1.png":ed.lookupDataTable("UnitQualityLevel","FrameResource",e)||"res/ui/panel/common/n_heroframe_bg2.png"},createQualityFrame:function(e){var t=null;t=e<0?"res/ui/panel/common/n_heroframe_bg0_1.png":(t=ed.lookupDataTable("UnitQualityLevel","FrameResource",e))||"res/ui/panel/common/n_heroframe_bg2.png";var i=ed.createSprite(t);i.getContentSize();return i.setCascadeOpacityEnabled(!0),i},getHeroIconResByHero:function(e){return e.skin?ed.lookupDataTable("Skin","HeroIcon",e.skin):ed.lookupDataTable("Unit","Portrait",e.tid)},createHeroIcon:function(e){var t=cc.size(100,100),i=cc.p(.5*t.width,.5*t.height),n=e.id,a=e.skin,s=e.flippedX,o=e.gray,r=e.unknown,c=e.newUnknown,l=e.quality,d=this.getHeroIconResByHero({tid:n,skin:a});d=r?"res/ui/panel/common/n_hero_unknown.jpg":d,c&&!d&&(d="res/ui/panel/common/n_hero_unknown.jpg"),e.unknownQualityBg&&(d=l<=1?"res/ui/panel/common_add/n_hero_unknown_green.png":l<=3?"res/ui/panel/common_add/n_hero_unknown_blue.png":l<=5?"res/ui/panel/common_add/n_hero_unknown_purple.png":l<=7?"res/ui/panel/common_add/n_hero_unknown_yellow.png":l<=9?"res/ui/panel/common_add/n_hero_unknown_red.png":"res/ui/panel/common_add/n_hero_unknown_white.png");var h=ed.createSprite(d);o&&h.setColor(cc.color(150,150,150,255)),s&&h.setFlippedX(s),h.setScale(.87),h.setPosition(cc.p(i));var u=new cc.BlendFunc(cc.DST_ALPHA,cc.ZERO);h.setBlendFunc(u);var p=ed.createSprite("res/ui/panel/common/n_heroframe_bg2.png");return u=new cc.blendFuncDisable,p.setBlendFunc(u),p.setPosition(i),ed.renderNode(t.width,t.height,(function(){p.visit(),h.visit()}))},getSkillDes:function(e,t){return ed.getDataTable("Skill")[t][e].Description},qualityFrameRes:{1:"res/ui/panel/common/n_hero_frame_green.png",2:"res/ui/panel/common/n_hero_frame_blue.png",3:"res/ui/panel/common/n_hero_frame_purple.png",4:"res/ui/panel/common/n_hero_frame_gold.png",5:"res/ui/panel/common/n_hero_frame_red.png"},enhancedQualityFrameRes:{2:"res/ui/panel/common/n_hero_frame_blue_1.png",3:"res/ui/panel/common/n_hero_frame_purple_1.png",4:"res/ui/panel/common/n_hero_frame_gold_1.png",5:"res/ui/panel/common/n_hero_frame_red_1.png"},qualityFrameBRes:{1:"res/ui/panel/common/n_hero_frame_green_bg.png",2:"res/ui/panel/common/n_hero_frame_blue_bg.png",3:"res/ui/panel/common/n_hero_frame_purple_bg.png",4:"res/ui/panel/common/n_hero_frame_gold_bg.png",5:"res/ui/panel/common/n_hero_frame_red_bg.png"},getBattleFrameRes:function(e){return ed.lookupDataTable("UnitQualityLevel","BattleFrame",e)||"res/ui/panel/common/n_hero_frame_green.png"},getBattleFrameBRes:function(e){return ed.lookupDataTable("UnitQualityLevel","BattleBg",e)||"res/ui/panel/common/n_hero_frame_green_bg.png"},getBattlePortraitRes:function(e){var t=e.tid;return e.skin?ed.lookupDataTable("Skin","BattlePortrait",e.skin):ed.lookupDataTable("Unit","BattlePortrait",t)},getBtLevelFrameRes:function(e){var t=ed.lookupDataTable("UnitQualityLevel","BattleLevelHalo",e);return t=t||"res/ui/panel/battle/n_halo_green.png"},getMainDutyDesc:function(e){var t=ed.lookupDataTable("UnitDuty","DisplayName",e);return T("hero_0_216414684_0","主要职责：{0}").format([t])},getSecondDutyDesc:function(e){var t=ed.lookupDataTable("UnitDuty","DisplayName",e);return T("hero_2_1375795480_0","次要职责：{0}").format([t])},isTrailHero:function(e){return!!e&&!(!e.source_type||"normal"==e.source_type||"sp_employ"==e.source_type)},isFreeHero:function(e){return!!e&&(!(!e.source_type||"backflow_free_hero"!==e.source_type)||void 0)},isExpiredFreeHero:function(e){return!!(this.isFreeHero(e)&&ed.getServerTime()>e.backflow_fh_expire_ts)},isCard_TB:function(e){return"Card"===ed.lookupDataTable("Unit","UnitRarity",e.tid)},isValidTrialHeroForTower:function(e,t){return!ed.towerUtil.isRaceTowerMode(t)||ed.towerMgr.instance.checkTrialHeroValid(e)},isSpecificRarityHero:function(e,t){var i=ed.lookupDataTable("Unit","UnitRarity",e),n=!1;return t.forEach((function(e){n=n||i==e})),n},checkHaveNpcById:function(e){var t=!1,i=ed.tavernData.tavern_npc;if(e&&i)for(var n=0;n<i.npcs.length;n++){var a=i.npcs[n];if(a.npc_id===e&&!ed.hero.isTrailHero(a)){t=!0;break}}return t},isSpHero:function(e){return"Golden"===ed.lookupDataTable("Unit","UnitRarity",e.tid)},isHyperHero:function(e){var t=ed.lookupDataTable("Unit","InitialQuality",e.tid);return t&&t>4},isTranscendentHero:function(e){return!!(e&&e.quality>=ed.heroQualityMgr.TransctMinQuality)},isHyperHeroSkillUnlock:function(e){var t=!1;if(this.isHyperHero(e)){var i=ed.getDataTable("Skill")[e.tid];for(var n in i)if(i[n].DisplayDetail&&"hyper"===i[n].SkillType){(e.rank>=i[n].UnlockRank||e.level>=i[n].UnlockLevel)&&(t=!0);break}}return t},getHyperHeroSkillData:function(e){var t,i=ed.getDataTable("Skill")[e.tid];for(var n in i)if(i[n].DisplayDetail&&"hyper"===i[n].SkillType){t=i[n];break}return t},isSameSeries:function(e,t){return ed.lookupDataTable("Unit","SeriesID",e)===ed.lookupDataTable("Unit","SeriesID",t)},getInitialQuality:function(e){return ed.lookupDataTable("Unit","InitialQuality",e.tid)},filterFreeHero:function(e){var t=[];e=e||[];for(var i=0;i<e.length;i++){var n=e[i];ed.hero.isFreeHero(n)||t.push(n)}return t},canWalk:function(e){return!cc.isNumber(e)||ed.lookupDataTable("Unit","WalkSpeed",e)>0},checkHeroIsInPentagram:function(e){var t=ed.pentagramModel.getPartnerHeroIds();return ed.player.getPentagramLevel()>0||t.length>=5&&!t.includes(e)}});}
function __nativeFactory67(){return ({SOURCE:{BASE_GROWTH:"基础与成长",HERO_QUALITY:"英雄品质",EQUIPMENT:"装备与套装",SIGNATURE:"专属装备",TRANSCT:"神威/冠阶",BAG_SUPPORT:"英雄后援",GUILD_SUPPORT:"公会后援",ASTROLABE:"生命之树",TEXAS:"德州阵型加成",SLG:"囚时之界",GVE:"众神猎场",INFINITE:"乱时之境",WAR:"远征",PET_QUALITY_BASE:"宠物品阶基础",PET_QUALITY_ADD:"宠物品阶加值",PET_TALENT:"宠物资质",PET_BOOK:"兽灵百科",TURN_BASED:"回合制替换公式"},BATTLE_MODIFY_TYPE:{PASSIVE_SKILL:"被动技能",ALLY_AURA:"己方光环",ENEMY_AURA:"敌方光环",BUFF_PERCENT:"百分比",BUFF_FIXED:"固定值"},TEXT:{NOT_PROVIDED:"未提供 {0}"},DETAIL_TEMPLATE:{BASE_CONFIG:{label:"英雄基础配置",reference:"HeroTid={tid} → {path} = {value}"},LEVEL_GROWTH:{label:"等级成长",reference:"等级基础：{levelField}={level} → {levelPath} = {base}\n英雄成长系数：HeroTid={tid} → {coefPath} = {coef}\n换算：{base} × {coef} = {value}"},RANK_GROWTH:{label:"Rank成长",reference:"HeroTid={tid}, rank={rank} → {path} = {value}"},LEVEL_EFFECTIVE:{label:"等级成长",reference:"等级基础：有效等级={level} → {levelPath} = {base}\n英雄成长系数：{coefPath}={coef}\n实际等级成长 = {value}"},LEVEL_BALANCED:{label:"等级成长",reference:"等级基础：有效等级={level} → {levelPath} = {base}\n英雄成长系数：{coefPath}={coef}\n玩法拉平：BalanceAttrLevel[{mode}][{level}].BaseRatio={ratio}\n实际等级成长 = {value}"},RANK_EFFECTIVE:{label:"Rank成长",reference:"进阶基础：HeroTid={tid}, rank={rank} → {path} = {base}\n实际Rank成长 = {value}"},RANK_BALANCED:{label:"Rank成长",reference:"进阶基础：HeroTid={tid}, rank={rank} → {path} = {base}\n玩法拉平：BalanceAttrRank[{mode}][{rank}].BaseRatio={ratio}\n实际Rank成长 = {value}"},EQUIP_SUIT:{label:"套装 #{id}",reference:"Equip.SuitID={id}, 件数={count} ≥ EquipSuit[{id}].BonusAmount{index}={required}\n属性：EquipSuit[{id}].BonusType{index}={attr}\n取值：EquipSuit[{id}].BonusValue{index} = {value}"}},systems:{"基础与成长":["Unit（本体）· UnitLevel（等级）· UnitRank（进阶）","getBaseAttribsByHero"],"英雄品质":["UnitQuality（品质属性）","getHeroQualityAttribsByHero"],"装备与套装":["Equip（装备）· EquipSuit（套装）","getAttribsByEquips"],"专属装备":["SignatureLevel（专属等级）","getAttribsBySignature"],"神威/冠阶":["TransctHeroAttrs（神威、冠阶与竞技属性）","getAttribsByTransct"],"英雄后援":["BagHeroSupportBonus（后援英雄属性）","getAttribsByBagSkills"],"公会后援":["GuildTurntableSupportBonus（秘藏科技属性）","getAttribsByGuildTurntableTech"],"生命之树":["Astrolabe（生命之树）· AstrolabeTag（艾雅美德）","getAttribsByAstrolabe"],"德州阵型加成":["UnitTexas（常规阵型）· WarBesiegeTexas（远征阵型）","getTexasAttribsByTexasObj"],"囚时之界":["SLGSystemPicLevel（圣物核心）· SLGSystemRelic（圣物）","getSlgAttribs"],"众神猎场":["GVESystemHeroesRankAttr（英雄品阶）· GVESystemEquip（猎品）","getGveAttribs"],"乱时之境":["InfiniteTeamAmulet（信物）· InfiniteInstLevel（命运清单）","getInfiniteAttribs"],"远征":["WarBesiegeMorale（士气）· WarBesiegeArmy（兵力）· WarEffect（科技效果）","getWarAttribs"],"宠物品阶基础":["PetQualityAttr（品阶本体倍率与加值）","getBaseAttribsByPetQuality"],"宠物品阶加值":["PetQualityAttr（品阶附加属性）","getAdditionalAttribsByPetQuality"],"宠物资质":["PetTalentLib（资质与伴生属性数值）","getHeroAttribsAddByPetTalent"],"兽灵百科":["PetBook（兽灵百科）","getPetBookAttribs"],"回合制替换公式":["ActMonsterEnemyLevel（卡牌等级）· ActMonsterEquip（卡牌装备）· ActMonsterGadget（小道具）","getActRaidMonsterHeroAttribs_TB"],"战斗配置倍率":["config.hp_mod（生命）· dps_mod（攻击）· def_mod（防御）","configAttribs"],"战斗 Buff":["SkillBuff（Buff 属性）","buffAttribs"],"被动技能":["Skill（被动属性）","passiveAttribs"],"光环":["Skill（光环属性）","auraAttribs"]},fieldPath:function(e,t){return e+(/^[A-Za-z_$][\w$]*$/.test(t)?"."+t:"["+JSON.stringify(t)+"]")},compareDetailReference:function(e,t){if(void 0===t||e===t)return[{text:e}];var i=this._referenceTokens(e),n=this._referenceTokens(t),a={};n.forEach((function(e){"key"===e.type&&(a["key:"+e.text]=!0)}));for(var s=[],o=[];i.length&&n.length&&i[0].text===n[0].text;)s.push(i.shift()),n.shift();for(;i.length&&n.length&&i[i.length-1].text===n[n.length-1].text;)o.unshift(i.pop()),n.pop();var r,c,l=[];for(r=0;r<=n.length;r++)for(l[r]=[r],c=1;c<=i.length;c++)l[r][c]=r?Math.min(l[r-1][c]+1,l[r][c-1]+1,l[r-1][c-1]+this._referenceReplaceCost(n[r-1],i[c-1])):c;var d=[];for(r=n.length,c=i.length;r||c;){var h=n[r-1],u=i[c-1];r&&c&&l[r][c]===l[r-1][c-1]+this._referenceReplaceCost(h,u)?(h.text!==u.text&&(u.changed=!0,u.before=h.text,"number"===h.type&&"number"===u.type&&(u.delta=Number(u.text)-Number(h.text))),d.unshift(u),r--,c--):c&&l[r][c]===l[r][c-1]+1?(u.changed="key"!==u.type||!a["key:"+u.text],d.unshift(u),c--):(h.changed=!0,h.removed=!0,d.unshift(h),r--)}return s.concat(d,o)},_referenceReplaceCost:function(e,t){return e.text===t.text?0:e.type===t.type&&"symbol"!==e.type&&"space"!==e.type?1:3},_referenceTokens:function(e){for(var t,i=/\[[^\]\r\n]*\]|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|-?\d+(?:\.\d+)?(?:e[+-]?\d+)?|[A-Za-z_$\u3400-\u9fff][\w$\u3400-\u9fff]*|[^\S\r\n]+|\r?\n|./gi,n=[];t=i.exec(e);){var a=t[0];if("["!==a.charAt(0)){var s=/^-?\d/.test(a),o=e.slice(0,t.index),r=s&&/\b(?:[\w$]*(?:id|tid)|index|slot(?:index)?)["']?\s*[:=]\s*$/i.test(o),c=/(?:^|[^=])=\s*$/.test(o)&&/^[A-Za-z_$\u3400-\u9fff"']/.test(a)&&!/^[.\[]/.test(e.slice(i.lastIndex)),l=s?r?"identity":"number":c?"value":/^\s+$/.test(a)?"space":/^[\w$\u3400-\u9fff"']/.test(a)?"word":"symbol";n.push({text:a,type:l,operand:s&&this._isReferenceOperand(e,t.index)})}else n.push({text:"[",type:"symbol"},{text:a.slice(1,-1),type:"key"},{text:"]",type:"symbol"})}return n},_isReferenceOperand:function(e,t){var i=e.lastIndexOf("\n",t-1)+1,n=e.indexOf("\n",t),a=e.slice(i,-1===n?e.length:n),s=a.lastIndexOf("=");return/[×÷]|\s[*/+-]\s/.test(a)&&(-1===s||t-i<s)||s>0&&/[+*]/.test(a.charAt(s-1))&&t-i>s},complete:function(e,t){var i={};e.inputs.forEach((function(e){if(e.source===t.index)for(var n in e.values)if(e.values[n]){var a=e.group+":"+n;i[a]||(i[a]={group:e.group,attr:n,value:0}),i[a].value+=e.values[n]}}));var n=this;Object.keys(i).forEach((function(a){var s=i[a];if(!t.parts.some((function(e){return e.group===s.group&&e.attr===s.attr}))){var o=n.resolve(t,e.context,s.group,s.attr);if(o.length){var r=o.reduce((function(e,t){return e+t.value}),0);Math.abs(r-s.value)>1e-10*Math.max(1,Math.abs(s.value))&&(o.push({label:"实际输入与配置解析的差值",value:s.value-r,warning:!0,reference:"当前配置明细合计 "+r+"，本次实际输入 "+s.value+"。检查缓存或计算上下文；差值不归因于配置字段。"}),e.warnings.push(t.label+" · "+s.attr+" 的当前配置解析与实际输入不一致"))}else{var c=n.systems[t.label];o.push({label:"实际属性输入",value:s.value,reference:(c?c[1]:t.label)+" → "+n.fieldPath(s.group,s.attr)+" = "+s.value+"\n输入参数："+JSON.stringify(t.reference)})}o.forEach((function(e){e.group=s.group,e.attr=s.attr,t.parts.push(e)}))}}))},treeBonusDetail:function(e,t,i,n,a,s,o){var r=this.row(t,i),c=r&&r[n];if(!c||!s)return null;var l=this.fieldPath(t+i.map((function(e){return"["+e+"]"})).join(""),n),d=c/100*s;return d?{label:e+" × 生命之树",value:d,reference:o+"\n"+e+"："+l+" = "+c+"\n生命之树："+this.fieldPath("astrolabeValue",a)+" = "+s+"\n换算："+c+" / 100 × "+s+" = "+d}:null},resolve:function(e,t,i,n){var a,s=this,o=t.tid,r=e.reference||{},c=this.row("Unit",[o])||{},l=[],d=-1!==i.indexOf("coefs"),h=n+(d?".PR":""),u=d?.01:1,p=function(e,t,i,n,a,o,r,c,d){var h=s.row(t,i);if(h&&h[n]&&!(c&&h[n]<=0)){var u=h[n],p=u*(void 0===o?1:o)+(r||0);if(p){var _=s.fieldPath(t+i.map((function(e){return"["+e+"]"})).join(""),n),f=String(u);void 0!==o&&1!==o&&(f+=.01===o?" / 100":" × "+o),r&&(f+=" - "+Math.abs(r)),l.push({label:e,value:p,reference:a+"\n取值："+_+" = "+u+(d?"\n系数："+d:"")+(f===String(u)?"":"\n换算："+f+" = "+p)})}}},_=function(e,t,i,n,a){p(e,t,i,h,n,u,0,a)},f=t.pvpEnabled&&t.pvpAttrs&&-1!==t.pvpAttrs.indexOf(n),g=t.pvpRule;switch(e.label){case"英雄品质":a=f&&this.row("BalanceAttrQuality",[g,r.quality]);var m="base_coefs"===i?n:"Add"+n,v=this.row("UnitQuality",[o,r.quality]);if("base_coefs"!==i||v&&1!==v[n]){var b=a&&a["base_coefs"===i?"CoefRatio":"BaseRatio"]||1,y=a?"BalanceAttrQuality["+g+"]["+r.quality+"]."+("base_coefs"===i?"CoefRatio":"BaseRatio")+"="+b:"";p("品质配置","UnitQuality",[o,r.quality],m,"HeroTid="+o+", quality="+r.quality,b,"base_coefs"===i?-1:0,!1,y)}break;case"专属装备":a=f&&this.row("BalanceAttrSig",[g,r.lv]);var S=d&&a&&a.CoefRatio||1,C=a&&d?"BalanceAttrSig["+g+"]["+r.lv+"].CoefRatio="+S:"";p("专属等级","SignatureLevel",[o,r.lv],h,"HeroTid="+o+", sig.lv="+r.lv,u*S,0,!1,C);break;case"神威/冠阶":var T=this.row("Transct",[r.quality]),w=T&&T.TransctLv,x=this.row("TransctHeroAttrs",[o,w]);["AttrList"].concat(r.transQuality&&t.pvpTotem?["PVP_AttrList"]:[]).forEach((function(e){for(var i=x&&x[e]&&x[e].split(";")||[],n=0;n<i.length;n+=2)i[n]===h&&Number(i[n+1])&&l.push({label:"AttrList"===e?"神威/冠阶属性":"冠阶竞技属性",distinct:"PVP_AttrList"===e,value:Number(i[n+1])*u,reference:("PVP_AttrList"===e?"trans_quality="+r.transQuality+"; battleEngine.isPVPTotemActive="+t.pvpTotem+"\n":"")+"quality="+r.quality+" → Transct["+r.quality+"].TransctLv="+w+" → TransctHeroAttrs["+o+"]["+w+"]."+e+"\n取值："+h+"="+i[n+1]+(d?"\n换算："+i[n+1]+" / 100 = "+Number(i[n+1])*u:"")})}));break;case"生命之树":_("生命之树","Astrolabe",[r.aLv],"astrolabe.lv="+r.aLv),r.tag&&_("艾雅美德","AstrolabeTag",[r.tag,r.tLv],"Unit["+o+"].AstrolabeTag="+r.tag+", tag_lvs["+r.tag+"]="+r.tLv);break;case"德州阵型加成":var E="War"===r.mode?"WarBesiegeTexas":"UnitTexas",A=r.formation?[r.formation]:[];if("War"!==r.mode)for(var P=1;P<=Math.min(r.devilCount||0,5);P++)A.push("Devil"+P);A.forEach((function(e){for(var t=s.row(E,[e]),i=1;t&&i<=3;i++)t["Attr"+i+"Name"]===n&&t["Attr"+i+"Type"]===(d?"multi":"add")&&p("阵型 "+e,E,[e],"Attr"+i+"Value","formation="+r.formation+", devilCount="+(r.devilCount||0)+" → "+E+"["+e+"].Attr"+i+"Name="+n+", Type="+t["Attr"+i+"Type"])}));break;case"囚时之界":var I=ed.battleEngine.config&&ed.battleEngine.config.season_id||ed.slgApplyData&&ed.slgApplyData.getSeasonId()||1,k=ed.getSlgMapTidBySeasonId(I)||1,L=r.core,D=L&&t.id&&L.hero_id==t.id&&L.relic_pic.hero_job===r.tag;(D?[L.relic_pic]:r.pics||[]).forEach((function(e){if(e.hero_job===r.tag){var t=(D?"relic_core":"relic_pics")+": season_id="+I+" → mapTid="+k+", hero_job="+e.hero_job+", lv="+e.lv;_("圣物核心","SLGSystemPicLevel",[k,e.hero_job,e.lv],t,!0),(e.relics||[]).forEach((function(e){_("圣物 "+e,"SLGSystemRelic",[k,e],t+", relics="+e,!0)}))}}));break;case"众神猎场":var R=(r.heroes||[]).filter((function(e){return e.hero_tid===o}))[0];if(!R)break;_("英雄品阶","GVESystemHeroesRankAttr",[r.tagId,r.tag,R.lv],"HeroTid="+o+"；匹配 gve_configs.hero_tid，lv="+R.lv+", tag_id="+r.tagId+", AstrolabeTag="+r.tag),Object.keys(R.equip_tids||{}).forEach((function(e){var t=R.equip_tids[e];_("猎品槽 "+e,"GVESystemEquip",[t],"gve_configs.equip_tids["+e+"]="+t)}));for(var N=R.lv-1;N>=1;N--){((this.row("GVESystemHeroesFormulas",[o,N])||{}).Slots||[]).forEach((function(e,t){_("已吞噬猎品 · "+N+"级槽"+(t+1),"GVESystemEquip",[e],"GVESystemHeroesFormulas["+o+"]["+N+"].Slots["+t+"]="+e)}))}break;case"乱时之境":(r.amulets||[]).forEach((function(e){_("信物 "+e.amulet_id,"InfiniteTeamAmulet",[e.amulet_id,e.lv],"self_infinite_amulets: amulet_id="+e.amulet_id+", lv="+e.lv,!0)})),Object.keys(r.instance||{}).forEach((function(e){var t=r.instance[e],i=s.row("InfiniteInstLevel",[e,t]);i&&"BattleJob"===i.EffectType&&(i.AstrolabeTags&&i.AstrolabeTags.length&&-1===i.AstrolabeTags.indexOf(c.AstrolabeTag)||i.HeroTagIDs&&i.HeroTagIDs.length&&-1===i.HeroTagIDs.indexOf(c.HeroTagID)||_("命运清单 "+e,"InfiniteInstLevel",[e,t],"infinite_inst["+e+"]="+t+"; 匹配职业="+c.AstrolabeTag+", 种族="+c.HeroTagID,!0))}));break;case"远征":"final_multiplier"===i?("number"==typeof r.morale&&p("士气","WarBesiegeMorale",[r.morale],n+"Ratio","morale="+r.morale,1,0,!0),"number"==typeof r.army&&p("兵力","WarBesiegeArmy",[r.army],n+"Ratio","army="+r.army,1,0,!0)):(r.effect||[]).forEach((function(e){var t=s.row("WarEffect",[e]);if(t){var i=t.Type;(d?-1!==i.indexOf("RaceExtraBaseAttr")&&parseInt(i.slice(17),10)===c.HeroTagID&&-1!==["ATK","HP","ARM"].indexOf(n):-1!==i.indexOf("AddAttr")&&i.slice(7).toUpperCase()===n)&&p("科技效果 "+e,"WarEffect",[e],"Value","war_effect="+e+" → WarEffect["+e+"].Type="+i+", HeroTagID="+c.HeroTagID,1,0,d)}}));break;case"宠物品阶基础":case"宠物品阶加值":p("宠物品阶","PetQualityAttr",[o,r.quality],"base_coefs"===i?n+"coef":"base_add"===i?n+"add":n,"petTid="+o+", quality="+r.quality);break;case"兽灵百科":if(_("百科等级","PetBook",[r.level||0],"pet_book_lv="+(r.level||0)),!d&&r.astrolabeValue){var F=this.treeBonusDetail("百科","PetBook",[r.level||0],n+".PR",n,r.astrolabeValue[n],"pet_book_lv="+(r.level||0));F&&l.push(F)}break;case"宠物资质":(r.talents||[]).forEach((function(e){var t=r.isPet?"Pet":c.HeroTag;if(t===e.tag||!r.isPet&&"Normal"===e.tag){var i=[e.id,e.quality],a="TalentId="+e.id+", Quality="+e.quality+", TalentTag="+e.tag+", 适用种族="+t;_("资质 "+e.id,"PetTalentLib",i,a,!0);var o=s.row("PetTalentLib",i),f=o&&s.row("PetTalentCatg",[o.AttrID]);if(f&&(f.RelatedAttr||[]).forEach((function(e){e===h&&p("资质伴生属性","PetTalentLib",i,f.AttrName,a+" → AttrID="+o.AttrID+" → PetTalentCatg["+o.AttrID+"].RelatedAttr="+e,u)})),!d&&r.astrolabeValue){var g=s.treeBonusDetail("资质","PetTalentLib",i,n+".PR",n,r.astrolabeValue[n],a);g&&l.push(g)}}}));break;case"回合制替换公式":if("fixed_attribs"===i){var B=this.row("ActMonsterEnemyLevel",[o,r.level]);B&&B[n]?p("卡牌等级","ActMonsterEnemyLevel",[o,r.level],n,"HeroTid="+o+", level="+r.level):p("英雄基础","Unit",[o],n,"HeroTid="+o);break}var M=function(e,t,i){_("卡牌加成 "+t,e,[t],i,!0);var a=s.row(e,[t]);!d&&("ActMonsterGadget"===e||a&&a.SpecialUnitID===o)&&p("卡牌专属加值 "+t,e,[t],"Extra"+n,i+", HeroTid="+o,1,0,!0)};(r.extras||[]).forEach((function(e){e.hero_id===o&&(e.monster_equips||[]).forEach((function(e){M("ActMonsterEquip",e,"hero_extras.hero_id="+o+", monster_equips="+e)}))})),(r.gadgets||[]).forEach((function(e){M("ActMonsterGadget",e,"param_list 小道具="+e)}))}return l},buff:function(e,t,i,n){var a,s="percent"===i.kind,o=this,r=function(t){return o.runtimeFields("SkillBuff",[e.info.ID],e.info,t,"buff.info")},c=[];if(s){var l="owner"===e.info.AddSource&&e.owner,d=l?"buff.owner.attribs":"buff.caster_attribs";c.push({label:"基数",value:i.basis,paths:["读取："+d+'["'+i.basisAttr+'"] = '+i.basis,l?"对象：受益者本次计算时的属性（不是最终采样值）":"对象：buff.caster_attribs 保存的施加者属性引用，展示本次实际读取值"].concat(r(["AddSource",ed.attrib_names_a[t]]))}),c.push({label:"系数",value:i.coefficient,paths:r([ed.attrib_names_x[t]])}),a=this.fieldPath("attribs",t)+" += "+i.basis+" × "+i.coefficient+" = "+n}else c.push({label:"加值",value:i.value,paths:r([t])}),a=this.fieldPath("attribs",t)+" += "+n,i.value!==n&&c.push({label:"HPR 狂暴修正",value:n,paths:["调用：buff.owner.rageObject.processHPR(buff.owner, "+i.value+", buff)","实际返回："+n+"；本项记录调用结果，未展开狂暴脚本内部计算。"]});return e.rank>1&&e.one_stack_info&&c[c.length-1].paths.push("层数由 upgrade 或定制脚本写入实例值；本次按实例值计算，不再额外乘 rank。"),{system:"战斗 Buff",rank:e.rank,method:s?"属性加值 = 基数 × 系数":"固定加值",calculation:a,sections:c,paths:c.reduce((function(e,t){return e.concat(t.label+"：",t.paths)}),[])}},skill:function(e,t,i){return{system:-1!==i.indexOf("光环")?"光环":"被动技能",method:i+"固定加值",calculation:'attribs["'+t+'"] += '+e.PasvNum,paths:this.runtimeFields("Skill",[e.CasterID,e.SkillID],e,["PasvAttr","PasvNum"],"skill_info")}},runtimeFields:function(e,t,i,n,a){var s=this,o=this.row(e,t),r=e+t.map((function(e){return"["+e+"]"})).join("");return n.map((function(e){var t=i[e],n=s.fieldPath(r,e)+" = "+(o?JSON.stringify(o[e]):"未找到配置行");return"实际读取："+(a+'["'+e+'"] = '+JSON.stringify(t))+"\n配置参考："+n+(o&&o[e]!==t?"\n实例已改写，计算采用实际读取值；仅凭这两个值不能反推改写过程。":o?"（与实例一致）":"")}))},row:function(e,t){for(var i=ed.getDataTable(e),n=0;i&&n<t.length;n++)i=i[t[n]];return i},petContext:function(e,t,i){return{isPet:t,astrolabeValue:i,talents:(e&&e[0]?e[0].getTalentArr():[]).map((function(e){return{id:e.getTalentId(),quality:e.getQuality(),tag:e.getTalentTag()}}))}}});}
function __nativeFactory68(){return ({EVENT_CHANGED:"ATTR_DEBUG_CHANGED",_enabled:!1,_records:[],_targets:[],_session:0,_serial:0,_mode:"panel",_modePreferences:{hero:"panel",battle:"battle"},_listeners:[],_followProbe:null,_lastFollowRefresh:0,isAllowed:function(){return!(!ed.bugReportLog||!ed.bugReportLog.isEnabled())},isEnabled:function(){return this._enabled&&this.isAllowed()},setEnabled:function(e){this._enabled=!!e&&this.isAllowed(),this._enabled||(this._records=[],this._engine=null,this._followProbe=null),this._notifyChanged()},open:function(){this.setEnabled(!0),this.refreshTargets();var e=this._targets.filter((function(e){return!!e.view}))[0];if(e&&this._target!==e)this.selectTarget(e.key);else if(!this._target&&this._targets.length){var t=this._targets.filter((function(e){return"hero"===e.kind}))[0];this.selectTarget((e||t||this._targets[0]).key)}else this.refresh()},close:function(){this._target=null,this._targets=[],this._current=null,this._savedA=null,this._savedB=null,this._panelView=null,this._heroRequest=null,this._session=0,this._serial=0,this._lastFollowRefresh=0,this._applyPreferredMode(),this.setEnabled(!1)},onBattleReset:function(e){this.isEnabled()&&e===ed.battleEngine&&(this._engine=e,this._records=[],this._followProbe=null,this._session++)},beginHeroStatic:function(e,t){return this.isEnabled()&&this._heroRequest&&this._heroRequest.hero===e?new ed.AttrDebugTraceData(this._makeContext(e,t,"普通属性")):null},finishHeroStatic:function(e,t){this._heroRequest.trace=e.snapshot(),this._heroRequest.result=ed.AttrDebugTraceData.copy(t)},beginUnitStatic:function(e){return this.isEnabled()&&"idle"!==ed.battleEngine.mode?(this._getRecord(e,!0),new ed.AttrDebugTraceData(this._makeContext(e.proto,e.config,"战斗静态属性"))):null},finishUnitStatic:function(e,t){var i=this._getRecord(e,!0);i.staticTrace=t.snapshot(),i.fixedResult=ed.AttrDebugTraceData.copy(t.staticResult),i.initial||(i.initial=t.snapshot(),i.initial.finalResult=ed.AttrDebugTraceData.copy(t.staticResult),i.initial.context.scope="初始属性 · 静态构建，未叠加被动、光环和 Buff")},beginDynamic:function(e){if(!this.isEnabled()||"idle"===ed.battleEngine.mode)return null;var t=this._getRecord(e,!0),i=new ed.AttrDebugTraceData(this._makeContext(e.proto,e.config,"战斗当前属性"));return i.initial=ed.AttrDebugTraceData.copy(e.attribs),t.active=i,i},getDynamic:function(e){if(!this.isEnabled())return null;var t=this._getRecord(e,!1);return t&&t.active},finishDynamic:function(e,t){var i=this._getRecord(e,!1);i&&i.active===t&&(i.dynamic={context:t.context,initial:t.initial,operations:this._closeOperations(t.initial,t.operations,e.attribs),result:ed.AttrDebugTraceData.copy(e.attribs)},i.active=null)},beginBuff:function(e,t,i){var n=this.getDynamic(e);if(!n)return null;var a={trace:n,previous:n.buffContext,kind:i,last:ed.AttrDebugTraceData.copy(e.attribs),buff:t};return n.buffContext=a,a},recordBuffValue:function(e,t,i,n,a,s,o,r){var c=e.buffContext,l="Buff #"+t.info.ID+(t.info.Name?" · "+t.info.Name:"");c&&c.last[i]!==n&&this._recordBuffCustom(e,t,i,c.last[i],n,"定制前置");var d=r?s>0?"未生效：noAttrUp":"未生效：noAttrDown":"生效";!r&&n===a&&s&&(d="数值未变化（检查浮点精度）"),!r&&"fixed"===o.kind&&o.value&&0===s&&(d="未生效：处理后加值为 0");var h=ed.AttrDebugSourceData.buff(t,i,o,s);h.caster=this.describeUnit(t.caster),this._recordOperation(e,l,i,n,a,h,d),c&&(c.last[i]=a)},finishBuff:function(e,t){for(var i in e.attribs)t.last[i]!==e.attribs[i]&&this._recordBuffCustom(t.trace,t.buff,i,t.last[i],e.attribs[i],"定制"+t.kind);t.trace.buffContext=t.previous},_recordBuffCustom:function(e,t,i,n,a,s){this._recordOperation(e,"Buff #"+t.info.ID+(t.info.Name?" · "+t.info.Name:""),i,n,a,{system:"战斗 Buff",caster:this.describeUnit(t.caster),rank:t.rank,method:s,calculation:"已记录实际前后值；定制脚本内部过程未采集，不据配置推算。",paths:["BuffID="+t.info.ID+" → SkillBuff["+t.info.ID+"]；本条变化来自定制脚本。"]},"未展开")},recordSkillValue:function(e,t,i,n,a,s,o){var r=ed.AttrDebugSourceData.skill(t,n,o);r.caster=this.describeUnit(i),this._recordOperation(e,o+(t.DisplayName?" · "+t.DisplayName:"")+" · Skill "+t.CasterID+"/"+t.SkillID,n,a,s,r)},_recordOperation:function(e,t,i,n,a,s,o){var r="施加者："+s.caster+"\n"+s.method+"\n"+s.calculation+"\n"+s.paths.join("\n");e.recordChange(t,i,n,a,r,o,s)},recordConfig:function(e,t,i,n){var a={HP:"hp_mod",ATK:"dps_mod",ARM:"def_mod",MR:"def_mod"};for(var s in a){var o=n[a[s]]||1,r="attribs."+s+" *= "+o,c=["读取：config."+a[s]+" = "+this.describeValue(n[a[s]])+"；计算倍率 = "+o+"（原入口缺省为 1）","由该场战斗或属性入口传入，不是独立成长系统。"];e.recordChange("战斗配置倍率 · "+a[s],s,t[s],i[s],r+"\n"+c.join("\n"),"生效",{system:"战斗配置倍率",method:"属性 × 配置倍率",calculation:r,paths:c})}},recordSupportDetail:function(e,t,i,n,a,s){var o,r,c,l=t.getConfig();t instanceof ed.GuildTurntableTechSupportBonusData?(c={kind:"guild",effectId:t.getEffectId(),bonusId:t.getSupportBonusId()},o=ed.GuildTurntableTechMgr.getTechEffectName(t.getEffectId()),r="EffectId="+t.getEffectId()+", 科技等级="+t.getTechLevel()+" → GuildTurntableEffect["+t.getEffectId()+"].EffectArg2 包含 "+t.getSupportBonusId()+" → "+this.fieldPath("GuildTurntableSupportBonus["+t.getSupportBonusId()+"]",s)):t instanceof ed.BagSkillData?(c={kind:"bag",heroTid:l.HeroTid},o=this._heroName(l.HeroTid),r="bag_hero_list: HeroTid="+l.HeroTid+", Quality="+l.Quality+" → "+this.fieldPath("BagHeroSupportBonus["+l.HeroTid+"]["+l.Quality+"]",s)):(o="其它后援来源",r=s);var d=void 0===l[s]?"inner_coefs"===i?100*a:a:l[s];r+=" = "+this.formatNumber(d,!0)+("inner_coefs"===i?"\n换算："+this.formatNumber(d,!0)+" / 100 = "+this.formatNumber(a,!0):""),e.addDetail(o,i,n,a,r,c)},describeUnit:function(e){if(!e)return"无施加者";var t=e.camp===ed.battle_camp.player?"己方":e.camp===ed.battle_camp.enemy?"敌方":"阵营未提供",i=e.config||{};return t+" · "+(i.isPet||e.proto&&e.proto.isPet?"宠物":i.is_summoned?"召唤物":i.slotIndex>0?i.slotIndex+"号位":"无固定站位")+" · "+this._heroName(e.tid)},refreshTargets:function(){for(var e=[],t=ed.getCurrentScene&&ed.getCurrentScene(),i=t&&t.getViewList?t.getViewList():[],n=ed.playerhero&&ed.playerhero.getHeroList?ed.playerhero.getHeroList():{},a=i.length-1;a>=0;a--){var s=i[a].view;if(ed.PetAttrView&&s instanceof ed.PetAttrView&&s.petData){e.push({key:"petPanel:"+s.petData.id,kind:"pet",hero:s.petData,view:s,isSelf:!!s.isSelf,label:"当前宠物 · "+this._heroName(s.petData.tid)});break}if(ed.heroAttributeNew&&s instanceof ed.heroAttributeNew&&s._hero){e.push({key:"panel:"+s._hero.id,kind:"hero",hero:s._hero,view:s,params:s._params,isSelf:!!s._isSelf,label:"当前属性面板 · "+this._heroName(s._hero.tid)});break}if(ed.otherHeroPanel&&s instanceof ed.otherHeroPanel&&s._hero){var o=!s.ignore_troops&&s.calculateGS;e.push({key:"otherPanel:"+s._hero.id,kind:"hero",hero:s._hero,view:s,params:o?s.data:s.params,isSelf:!o&&!!s.isSelf,useBaseEntry:!0,label:"当前面板 · "+this._heroName(s._hero.tid)+" · Lv."+(s._hero.pentagram_lv||s._hero.level)});break}if(ed.heroDetailsView&&s instanceof ed.heroDetailsView&&s._hero){e.push({key:"panel:"+s._hero.id,kind:"hero",hero:s._hero,view:s,isSelf:!0,label:"当前英雄 · "+this._heroName(s._hero.tid)});break}}this._syncEngine();for(var r=this._engine&&"idle"!==this._engine.mode?(this._engine.unit_list||[]).concat(this._engine.pet_list||[]):[],c=0;c<r.length;c++){var l=r[c];if(l&&l.proto){for(var d=null,h=0;h<this._targets.length;h++){var u=this._targets[h];if(u.session===this._session&&u.unit===l){d=u.key;break}}d=d||"battle:"+this._session+":"+ ++this._serial,e.push({key:d,session:this._session,kind:"battle",unit:l,label:this.describeUnit(l)+(l.isAlive()?"":"（已退场）")})}}var p=[];for(var _ in n){var f=n[_];p.push({key:"hero:"+_,kind:"hero",hero:f,isSelf:!0,label:"背包 · "+this._heroName(f.tid)+" · Lv."+(f.pentagram_lv||f.level)+" · ID "+_})}p.sort((function(e,t){return t.hero.level-e.hero.level||e.hero.id-t.hero.id}));var g=(ed.PetManager?ed.PetManager.getInstance().getAllPets():[]).map(function(e){return{key:"pet:"+e.id,kind:"pet",hero:e,isSelf:!0,label:this._heroName(e.tid)+" · 品阶 "+e.quality+" · ID "+e.id}}.bind(this));if(this._targets=e.concat(p,g),this._target){var m=e[0]&&e[0].view?e[0]:null,v=m&&(this._target.view===m.view||m.view!==this._panelView&&0===this._target.key.indexOf("hero:")&&this._target.hero.tid===m.hero.tid),b=this._target.key;this._target=v?m:null;for(var y=0;!this._target&&y<this._targets.length;y++)this._targets[y].key===b&&(this._target=this._targets[y])}return this._panelView=e[0]&&e[0].view,this._applyPreferredMode(),this._targets},getTargets:function(){return this._targets},getTarget:function(){return this._target},selectTarget:function(e){for(var t=0;t<this._targets.length;t++)if(this._targets[t].key===e)return this._target=this._targets[t],this._applyPreferredMode(),void this.refresh()},setMode:function(e){var t=this._target&&this._target.kind||"hero";"battle"!==t||"battle"!==e&&"initial"!==e?"hero"!==t||"panel"!==e&&"normal"!==e||(this._modePreferences.hero=e):this._modePreferences.battle=e,this._applyPreferredMode(),this.refresh()},setModePreferences:function(e){e=e||{},this._modePreferences={hero:"normal"===e.hero?"normal":"panel",battle:"initial"===e.battle?"initial":"battle"},this._applyPreferredMode()},getModePreferences:function(){return{hero:this._modePreferences.hero,battle:this._modePreferences.battle}},_applyPreferredMode:function(){var e=this._target&&this._target.kind||"hero";this._mode="pet"===e?"panel":this._modePreferences[e]},getMode:function(){return this._mode},refresh:function(e,t){if(this.isAllowed()){e||this.refreshTargets();var i=this._current;if(!this._target)return this._current=null,void(e&&!i||this._notifyChanged());try{if("battle"===this._target.kind){var n=this._target.unit,a=this._getRecord(n,!1);this._current="initial"===this._mode?this._buildInitialSnapshot(n,a):this._buildUnitSnapshot(n,a)}else{if(!this.isEnabled())return void ed.showToast("请先开启属性采集",{bindSystemFont:!0});this._current=this._captureHero(this._target)}}catch(e){this._current=null,ed.showToast("属性采集失败："+e.message,{bindSystemFont:!0}),cc.error("AttrDebug",e.stack||e)}e&&this.getSnapshotSignature(i,t)===this.getSnapshotSignature(this._current,t)||this._notifyChanged()}},followFrame:function(e,t){if(this.isEnabled())if(!(e-this._lastFollowRefresh>=1e3||this._engine!==ed.battleEngine||this._target&&"battle"===this._target.kind&&this._target.session!==this._session)||(this._lastFollowRefresh=e,this.refreshTargets(),this._target&&"battle"===this._target.kind)){if(this._target&&"battle"===this._target.kind){var i=this._target.unit,n=this._getRecord(i,!1),a=n&&("initial"===this._mode?n.initial:n.dynamic),s=n&&n.staticTrace,o=JSON.stringify(["initial"===this._mode?i.fixed_attribs:i.attribs,t?[i.hp,i.gs]:null]),r=this._followProbe;r&&r.unit===i&&r.mode===this._mode&&r.trace===a&&r.staticTrace===s&&r.values===o&&r.includeContext===t?"battle"===this._mode&&this._current&&this._current.context.tick!==this._engine.ticks&&(this._current.context.tick=this._engine.ticks,this._current.context.time=(new Date).toISOString()):(this._followProbe={unit:i,mode:this._mode,trace:a,staticTrace:s,values:o,includeContext:t},this.refresh(!0,t))}}else this.refresh(!0,t)},getSnapshotSignature:function(e,t){if(!e)return"";var i={};return Object.keys(e.context).forEach((function(n){-1!==["time","tick","calculationTick"].indexOf(n)||!1===t&&-1!==["hp","gs"].indexOf(n)||(i[n]=e.context[n])})),JSON.stringify([e.finalResult,e.formulas,e.inputs,e.operations,e.warnings,i,e.sources.map((function(e){return[e.label,e.reference,e.parts]}))])},getSnapshot:function(){return this._current},saveSnapshot:function(e){this._current&&(this["A"===e?"_savedA":"_savedB"]=ed.AttrDebugTraceData.copy(this._current),this._notifyChanged())},getBaseline:function(){return this._savedA},clearBaseline:function(){this._savedA=null,this._notifyChanged()},getComparison:function(e){var t=this._savedA,i=e?this._current:this._savedB;if(!t||!i)return null;for(var n=[],a={},s=this.getAttrNames(i,t),o=0;o<s.length;o++){var r=s[o],c=t.finalResult[r],l=i.finalResult[r],d=c!==l||this._attributeSignature(t,r)!==this._attributeSignature(i,r),h={attr:r,before:c,after:l,changed:d,delta:void 0!==c&&void 0!==l?l-c:null,rate:void 0!==c&&0!==c&&void 0!==l?(l-c)/Math.abs(c)*100:null};a[r]=h,d&&n.push(h)}return{a:t,b:i,rows:n,attributes:a,contextChanges:this.getContextChanges(t.context,i.context)}},getContextChanges:function(e,t){var i=[],n={},a={};this.getContextSections(e).forEach((function(e){e.rows.forEach((function(e){n[e.name]=e.value}))})),this.getContextSections(t).forEach((function(e){e.rows.forEach((function(e){a[e.name]=e.value}))}));var s=function(e,t,n){if(JSON.stringify(t)!==JSON.stringify(n))if(t&&n&&"object"==typeof t&&"object"==typeof n){var a=Object.keys(t).concat(Object.keys(n));a.filter((function(e,t){return a.indexOf(e)===t})).forEach(function(i){s(Array.isArray(n)?e+"["+i+"]":this.fieldPath(e,i),t[i],n[i])}.bind(this))}else i.push({name:e,before:t,after:n})}.bind(this),o=Object.keys(n).concat(Object.keys(a));return o.filter((function(e,t){return o.indexOf(e)===t&&-1===["time","tick","calculationTick"].indexOf(e)})).forEach((function(e){s(e,n[e],a[e])})),i},_attributeSignature:function(e,t,i,n){var a=e.inputs.filter((function(a){var s=void 0===t?Object.keys(a.values).some((function(e){return a.values[e]})):a.values[t];return a.active&&s&&(!i||-1!==i.indexOf(a.group))&&(!n||e.sources[a.source].label===n)})).map((function(i){var n=e.sources[i.source],a=(n.parts||[]).filter((function(e){return(void 0===t||e.attr===t)&&e.group===i.group}));return[n.label,i.group,void 0===t?i.values:i.values[t],a.length?a:n.reference]})),s=i?[]:this.getPostOperations(e,t).filter(function(e){return!n||this.getOperationSystem(e)===n}.bind(this)).map(this._operationSignature.bind(this));return JSON.stringify([a,s])},_operationSignature:function(e){return e?JSON.stringify([e.label,e.attr,e.delta,e.status,e.provenance||e.detail]):""},getAttrNames:function(e,t){if(!e)return[];var i=Object.keys(e.finalResult);t&&Object.keys(t.finalResult).forEach((function(e){-1===i.indexOf(e)&&i.push(e)}));var n=ed.getDataTable("UnitGS"),a=["HP","ATK","ARM","MR"];return i.sort((function(t,i){var s=Number(!!e.finalResult[i])-Number(!!e.finalResult[t]);if(s)return s;var o=a.indexOf(t),r=a.indexOf(i);return-1!==o||-1!==r?(-1===o?99:o)-(-1===r?99:r):(n[t]&&n[t].Order||999)-(n[i]&&n[i].Order||999)||t.localeCompare(i)})),i},getAttrLabel:function(e){var t=ed.getDataTable("UnitGS")[e.toUpperCase()],i=t&&(t.DisplayName||t.ShortName)||ed.attrib_names_hash&&ed.attrib_names_hash[e];return i||"IPOS"!==e||(i="正面效果持续时间"),(i||"未配置名称")+" · "+e},getFormulaNodes:function(e,t,i){var n=e&&e.formulas[t];if(!n)return{};var a=[["fixed","fixed_attr_value","基础固定值","fixed_attribs"],["baseCoef","base_coef_value","本体倍率","base_coefs"],["baseAdd","base_add_value","本体加值","base_add"],["innerCoef","inner_coef_value","成长线内乘区","inner_coefs"],["addition","addition_value","成长线加值","addition_attribs"],["outerCoef","outer_coef_value","外围乘区","outer_coefs"],["outerAdd","outer_add_value","外围加值","outer_adds"],["sysOuterCoef","sys_outer_coef_value","系统外乘区","sys_outer_coefs"],["sysOuterAdd","sys_outer_add_value","系统外加值","sys_outer_adds"],["finalMultiplier","final_multiplier_value","最终倍率","final_multiplier"]],s={};a.forEach((function(e){s[e[0]]={key:e[0],code:e[1],label:e[2],groups:[e[3]],value:n.operands[e[0]]}})),s.baseAttr={key:"baseAttr",code:"fixed * baseCoef + baseAdd",label:e.context.isPet?"宠物本体":"英雄本体",value:n.steps[0].value,groups:["fixed_attribs","base_coefs","base_add"]},s.result={key:"result",code:'result["'+t+'"]',label:"最终结果",value:e.finalResult[t],groups:a.map((function(e){return e[3]}))};var o=this.getPostOperations(e,t),r="战斗当前属性"===e.context.scope;if((r||o.length)&&(s.dynamic={key:"dynamic",name:r?"战斗动态修改":"计算后处理",code:'attribs["'+t+'"]',label:"被动 / 光环 / Buff / 配置及其它改写",value:e.finalResult[t],before:n.actual,groups:[],operations:o},s.result.operations=o,s.result.code=r?'unit.attribs["'+t+'"]':s.result.code),i&&i.formulas[t]){var c=this.getFormulaNodes(i,t);!s.dynamic&&c.dynamic&&(s.dynamic={key:"dynamic",name:"计算后处理",code:'attribs["'+t+'"]',label:"被动 / 光环 / Buff / 配置及其它改写",value:e.finalResult[t],before:n.actual,groups:[],operations:[]},s.result.operations=[]),Object.keys(s).forEach(function(n){var a=s[n],o=c[n];"finalMultiplier"===n&&(a.value=a.value||1,o.value=o.value||1),a.baselineValue=o&&o.value,a.delta=o?a.value-o.value:null;var r=a.groups.length>0&&this._attributeSignature(e,t,a.groups)!==this._attributeSignature(i,t,a.groups),l=!!a.operations&&this.getComparedOperations(e,t,i).some((function(e){return e.changed}));a.changed=!o||a.value!==o.value||r||l,a.operations&&(a.operations=this.getComparedOperations(e,t,i))}.bind(this))}return s},_pairEntries:function(e,t,i){var n={},a={},s=e.map((function(e){for(var s=i(e),o=-1,r=0;r<t.length;r++)if(!n[r]&&i(t[r])===s){o=r,n[r]=!0;break}return a[s]=(a[s]||0)+1,{current:e,baseline:t[o],key:s+":"+a[s]}}));return t.forEach((function(e,t){if(!n[t]){var o=i(e);a[o]=(a[o]||0)+1,s.push({baseline:e,key:o+":"+a[o]})}})),s},getComparedOperations:function(e,t,i){var n=this.getPostOperations(e,t);return!i||"战斗当前属性"===e.context.scope&&!e.dynamicContext||"战斗当前属性"===i.context.scope&&!i.dynamicContext?n:this._pairEntries(n,this.getPostOperations(i,t),(function(e){var t=e.provenance||{};return[e.label,t.caster,t.method].join("|")})).map(function(e){var t=ed.AttrDebugTraceData.copy(e.current||e.baseline);return t.comparisonKey=e.key,t.removed=!e.current,t.added=!e.baseline,t.baselineProvenance=e.baseline&&ed.AttrDebugTraceData.copy(e.baseline.provenance),t.baselineDetail=e.baseline&&e.baseline.detail,t.baselineStatus=e.baseline&&e.baseline.status,t.baselineDelta=e.baseline?e.baseline.delta:0,t.currentDelta=e.current?e.current.delta:0,t.comparisonDelta=t.currentDelta-t.baselineDelta,t.changed=this._operationSignature(e.current)!==this._operationSignature(e.baseline),t}.bind(this))},getComparisonLabel:function(e){return e.changed?e.removed?"相较基线移除":e.added?"相较基线新增":"相较基线有变化":""},getOperationEmptyText:function(e,t,i){return"战斗当前属性"!==e.context.scope||e.dynamicContext?i?"当前定位来源「"+this.getSystemLabel(i)+"」没有匹配的动态修改; 清空定位来源可查看该属性的全部操作。":"已采集动态过程, "+this.getAttrLabel(t)+" 没有有效动态修改 (×1、+0 等无效步骤已省略)。":"动态过程未采集, 无法判断该属性是否有 Buff 等修改。保持采集开启后等待下一次属性重算, 或进入下一场战斗。"},getSnapshotMoment:function(e){var t=e.context;if("战斗当前属性"!==t.scope&&0!==t.scope.indexOf("初始属性"))return"";var i=[void 0===t.tick?"Tick 未采集":"采样 Tick "+t.tick];return void 0!==t.calculationTick&&t.calculationTick!==t.tick&&i.push("计算 Tick "+t.calculationTick),void 0!==t.camp&&i.push(t.camp===ed.battle_camp.player?"己方":t.camp===ed.battle_camp.enemy?"敌方":"阵营 "+t.camp),t.isPet?i.push("宠物"):t.slotIndex>0&&i.push(t.slotIndex+"号位"),void 0!==t.session&&i.push("采集场次 #"+t.session),i.join(" · ")},getPostOperations:function(e,t){var i=e.operations.filter((function(e){return!(void 0!==t&&e.attr!==t||e.before===e.after&&"生效"===e.status)}));return(void 0===t?Object.keys(e.formulas):[t]).forEach((function(t){var n=e.formulas[t];n&&e.staticResult&&n.actual!==e.staticResult[t]&&i.unshift({label:"免伤高值修正",attr:t,before:n.actual,after:e.staticResult[t],delta:e.staticResult[t]-n.actual,detail:"unitAttribsMgr._finalCalculateAttribs",status:"生效"})})),i},getOperationSystem:function(e){return e.provenance?e.provenance.system:0===e.label.indexOf("Buff #")?"战斗 Buff":0===e.label.indexOf("被动")?"被动技能":-1!==e.label.indexOf("光环")?"光环":e.label},getSystemLabel:function(e){var t=ed.AttrDebugSourceData.systems[e];return t&&t[2]||e},getSystemOptions:function(e,t,i){if(!e)return[];var n=[],a={},s=function(e){if(!a[e]){var t=ed.AttrDebugSourceData&&ed.AttrDebugSourceData.systems[e];a[e]={label:e,keyword:t?t[0]:e,active:!1,available:!1,attributes:{},groups:[],values:{},dynamic:!1},n.push(a[e])}return a[e]};e.sources.forEach((function(i,n){var a=s(i.label);e.inputs.forEach((function(e){e.source===n&&e.active&&(Object.keys(e.values).forEach((function(t){e.values[t]&&(a.attributes[t]=!0)})),e.values[t]&&(a.active=!0,-1===a.groups.indexOf(e.group)&&a.groups.push(e.group),a.values[e.group]=(a.values[e.group]||0)+e.values[t]))}))}));var o=this;if(this.getPostOperations(e).forEach((function(e){var i=s(o.getOperationSystem(e));e.before!==e.after&&(i.attributes[e.attr]=!0,e.attr===t&&(i.active=!0,i.dynamic=!0))})),n.forEach((function(e){e.available=Object.keys(e.attributes).length>0})),i){var r=this.getSystemOptions(i,t);r.forEach((function(e){s(e.label)})),n.forEach(function(t){var n=r.filter((function(e){return e.label===t.label}))[0];t.currentAvailable=t.available,t.baselineValues=n?n.values:{},t.baselineOnly=!t.available&&!(!n||!n.available),n&&(t.available=t.available||n.available,t.active=t.active||n.active,t.dynamic=t.dynamic||n.dynamic,Object.keys(n.attributes).forEach((function(e){t.attributes[e]=!0})),n.groups.forEach((function(e){-1===t.groups.indexOf(e)&&t.groups.push(e)}))),t.changed=this._attributeSignature(e,void 0,null,t.label)!==this._attributeSignature(i,void 0,null,t.label)}.bind(this))}return n.sort((function(e,t){return Number(t.available)-Number(e.available)||Number(t.active)-Number(e.active)||o.getSystemLabel(e.label).localeCompare(o.getSystemLabel(t.label),"zh-CN")}))},getNodeContributions:function(e,t){return t&&t.active?e.groups.filter((function(e){return-1!==t.groups.indexOf(e)})).map((function(e){var i=t.values[e]||0,n=t.baselineValues&&(t.baselineValues[e]||0);return{group:e,value:i,delta:void 0===n?null:i-n}})):[]},getNodeSources:function(e,t,i,n){var a=this,s=i.groups.map((function(i){var n=[];return e.sources.forEach((function(a,s){var o=e.inputs.filter((function(e){return e.source===s&&e.group===i&&e.values[t]}));if(o.length){var r=o.some((function(e){return e.active})),c=o.reduce((function(e,i){return e+(r&&!i.active?0:i.values[t])}),0),l=(a.parts||[]).filter((function(e){return e.group===i&&e.attr===t}));if("装备与套装"===a.label&&Array.isArray(a.reference)){var d=a.reference.map((function(e){var n="装备槽 "+e.index;return l.filter((function(e){return e.label===n}))[0]||{label:n,group:i,attr:t,value:0,reference:e}}));l=d.concat(l.filter((function(e){return 0!==e.label.indexOf("装备槽 ")})))}l=l.map((function(e){var t=ed.AttrDebugTraceData.copy(e),i=e.identity&&"equip"===e.identity.kind?e.identity.slot:e.reference&&e.reference.index;return t.cache=(a.cache||[]).filter((function(e){return e.identity&&"equip"===e.identity.kind&&e.identity.slot===i})),t})),n.push({label:a.label,value:c,active:r,reference:a.reference,children:l,inline:1===l.length&&!l[0].warning&&!l[0].distinct&&-1!==["英雄品质","神威/冠阶","专属装备","宠物品阶基础","宠物品阶加值","兽灵百科"].indexOf(a.label),cache:(a.cache||[]).filter((function(e){return!e.identity||"equip"!==e.identity.kind})),group:i})}})),{group:i,label:a.getGroupLabel(i),rows:n,total:n.reduce((function(e,t){return e+(t.active?t.value:0)}),0)}}));if(n&&n.formulas[t]&&e.formulas[t]){var o=this.getNodeSources(n,t,i);s.forEach(function(e,t){var i=o[t];e.delta=e.total-i.total,e.rows=this._pairEntries(e.rows,i.rows,(function(e){return e.label})).map(function(e){return this._compareSourceRow(e)}.bind(this)),e.changed=e.rows.some((function(e){return e.changed}))}.bind(this))}return s},_compareSourceRow:function(e){var t=e.current,i=e.baseline,n=t||ed.AttrDebugTraceData.copy(i);return n.removed=!t,n.added=!i,n.baselineValue=i&&i.active?i.value:0,n.compareValue=t&&t.active?t.value:0,n.delta=n.compareValue-n.baselineValue,n.value=n.compareValue,n.baselineReference=i&&ed.AttrDebugTraceData.copy(i.reference),n.removed&&(n.value=0,n.active=!1,n.cache=[]),n.children=this._pairEntries(t?t.children:[],i?i.children:[],(function(e){return e.identity?JSON.stringify(e.identity):e.label})).map((function(e){var n=ed.AttrDebugTraceData.copy(e.current||e.baseline);return n.comparisonKey=e.key,n.removed=!e.current,n.added=!e.baseline,n.baselineReference=e.baseline&&ed.AttrDebugTraceData.copy(e.baseline.reference),n.baselineValue=i&&i.active&&e.baseline?e.baseline.value:0,n.value=t&&t.active&&e.current?e.current.value:0,n.delta=n.value-n.baselineValue,n.changed=0!==n.delta||JSON.stringify(e.current&&e.current.reference)!==JSON.stringify(e.baseline&&e.baseline.reference),n.removed&&(n.cache=[]),n})),n.inline=n.inline&&1===n.children.length,n.changed=0!==n.delta||n.children.some((function(e){return e.changed}))||!n.children.length&&JSON.stringify(t&&t.reference)!==JSON.stringify(i&&i.reference),n},recordEquipPart:function(e,t,i,n,a,s){var o="Equip",r=ed.unitAttribsMgr.getPvpEnvAttribsRuleMode(),c=ed.getDataTable("BalanceAttrEquip")[r],l=r&&c&&ed.unitAttribsMgr.getIsPvpEnvEnabledByTid(a),d=function(e){return ed.AttrDebugMgr.formatNumber(e,!0)};for(var h in i)for(var u in i[h]){var p=i[h][u]-(t[h]&&t[h][u]||0);if(p){var _=this.getEquipContext([n])[0],f=n.equip,g=ed.getDataTable(o)[f.cfg_id],m=f.attrs||[],v=[],b=m.filter((function(e){return"hero_tid"===e.type&&e.value===a})).length,y=0;if(b){var S=f.source_tid?"source_tid":f.resonate_tid?"resonate_tid":"cfg_id",C=f[S],T="Hero"+u+("inner_coefs"===h?".PR":""),w=ed.getDataTable(o)[C][T]||0;v.push("英雄专属条件：attrs.hero_tid="+a+" 与 HeroTid="+a+" 匹配"),v.push("英雄专属取值：equip."+S+"="+C+" → "+this.fieldPath(o+"["+C+"]",T)+"="+d(w));for(var x="inner_coefs"===h?w/100:w,E=0;E<b;E++)y+=x;"inner_coefs"===h&&v.push("专属换算："+d(w)+" / 100 = "+d(x)),b>1&&v.push("专属匹配条目="+b+" → "+d(x)+" × "+b+" = "+d(y))}else v.push("英雄专属条件：无匹配的 attrs.hero_tid（HeroTid="+a+"），专属贡献=0");var A=y;if("addition_attribs"===h){var P=g[u]||0;v.push("阵营基础：equip.cfg_id="+f.cfg_id+" → "+this.fieldPath(o+"["+f.cfg_id+"]",u)+"="+d(P));var I=m.some((function(e){return"hero_tag"===e.type&&ed.getDataTable("UnitTag")[e.value].Name===s})),k=I?g.TagBonusRate:1,L=P*k||0;v.push("阵营换算："+(I?"阵营匹配；Equip["+f.cfg_id+"].TagBonusRate="+d(k):"阵营未匹配；系数=1（默认）")+" → "+d(P)+" × "+d(k)+" = "+d(L));var D=g["Add"+u]||0,R=D?f.enhance_lv*D:0;if(v.push("强化加值：enhance_lv="+f.enhance_lv+"；"+this.fieldPath(o+"["+f.cfg_id+"]","Add"+u)+"="+d(D)+" → "+f.enhance_lv+" × "+d(D)+" = "+d(R)),A+=L,A+=R,v.push("合计（英雄专属 + 阵营基础 + 强化）："+d(y)+" + "+d(L)+" + "+d(R)+" = "+d(A)),l&&ed.unitAttribsMgr.getIsPvpEnvEnableAttrib(u)){var N=c[f.quality]&&c[f.quality].BaseRatio||1;v.push("玩法拉平：BalanceAttrEquip["+r+"]["+f.quality+"].BaseRatio="+d(N)+" → "+d(A)+" × "+d(N)+" = "+d(A*N)),A*=N}}Math.abs(A-p)>1e-10*Math.max(1,Math.abs(A),Math.abs(p))&&v.push("⚠ 配置推算="+d(A)+"；实际输入="+d(p)+"（以实际输入为准，请检查缓存或配置变化）"),v.push("计算入口："+(l?"getPvpEnvOneEquipAttr":"getOneEquipAttr")),_.paths=v,e.addDetail("装备槽 "+n.index,h,u,p,_,{kind:"equip",slot:n.index})}}},getSources:function(e,t,i){for(var n=[],a=0;a<e.sources.length;a++){for(var s=e.sources[a],o=[],r=0;r<e.inputs.length;r++){var c=e.inputs[r];c.source===a&&c.values[t]&&o.push({group:c.group,value:c.values[t],active:c.active,inputIndex:r})}var l=(s.parts||[]).filter((function(e){return e.attr===t&&e.value}));(o.length||l.length||i)&&n.push({index:a,key:"source-"+a,label:s.label,values:o,parts:l,reference:s.reference,cache:s.cache||[]})}return n},getGroupLabel:function(e){return{fixed_attribs:"基础固定值",base_coefs:"本体倍率",base_add:"本体加值",inner_coefs:"内乘区",addition_attribs:"内加值",outer_coefs:"外围乘区",outer_adds:"外围加值",sys_outer_coefs:"系统外乘区",sys_outer_adds:"系统外加值",final_multiplier:"最终倍率"}[e]||e},addListener:function(e){"function"==typeof e&&-1===this._listeners.indexOf(e)&&this._listeners.push(e)},removeListener:function(e){var t=this._listeners.indexOf(e);-1!==t&&this._listeners.splice(t,1)},_notifyChanged:function(){ed.fireEvent(this.EVENT_CHANGED);for(var e=this._listeners.slice(),t=0;t<e.length;t++)try{e[t]()}catch(e){cc.error("AttrDebug listener",e.stack||e)}},formatNumber:function(e,t){if(null==e)return"未提供";if("number"!=typeof e||t)return String(e);var i=Number(e.toFixed(6));return String(0!==e&&0===i?e:i)},formatGroupValue:function(e,t,i){return-1!==e.indexOf("coefs")?"{0}%".format([this.formatNumber(100*t,i)]):this.formatNumber(t,i)},formatDelta:function(e,t,i){if(null==e)return"不可计算";var n=Math.abs(e);return(e>0?"↑":e<0?"↓":"")+(i?this.formatGroupValue(i,n,t):this.formatNumber(n,t))},describeValue:function(e){return void 0===e?"未提供":"object"==typeof e?JSON.stringify(e):String(e)},fieldPath:function(e,t){return ed.AttrDebugSourceData.fieldPath(e,t)},formatReference:function(e,t){var i=this.describeValue(e);if(t)return i;var n=this;return i.replace(/(^|[\s=+×/,(：])(-?\d+\.\d+(?:e[+-]?\d+)?)(?=$|[\s,;；）)％%])/g,(function(e,t,i){return t+n.formatNumber(Number(i))}))},getDetailReferenceSegments:function(e,t){return ed.AttrDebugSourceData.compareDetailReference(this.describeValue(e),void 0===t?void 0:this.describeValue(t))},printReport:function(e){this.isAllowed()&&(this._current?(cc.log(this.exportReport(!1,e)),ed.showToast("当前属性报告已打印，可在控制台搜索 AttrDebug",{bindSystemFont:!0})):ed.showToast("请先选择对象并采集属性",{bindSystemFont:!0}))},exportReport:function(e,t){if(t=t||{},e)return JSON.stringify({selection:t,current:this._current,baseline:this._savedA},null,2);var i=this._current;if(!i)return"[AttrDebug] 暂无属性快照";var n=this.getBaseline(),a=t.attr||(void 0!==i.finalResult.ATK?"ATK":this.getAttrNames(i)[0]),s=void 0===t.raw||t.raw,o=function(e){return this.formatNumber(e,s)}.bind(this),r=function(e){return this.formatDelta(e,s)}.bind(this),c=function(e,t){return"number"==typeof e&&"number"==typeof t&&e!==t?" ("+r(e-t)+")":""},l=i.context,d=["[AttrDebug] "+this.getAttrLabel(a)+" · "+(l.name||"未命名对象"),"对象：id="+this.describeValue(l.id)+" / tid="+this.describeValue(l.tid)+" / "+l.scope,"采样："+(l.time||"未记录时间")+(void 0===l.tick?"":" / tick="+l.tick),"当前值："+o(i.finalResult[a])+"  [原始值 "+this.describeValue(i.finalResult[a])+"]"],h=this.getComparison(!0);if(h){var u=h.attributes[a];d.push("\n【基线对比】始终用当前快照和已设立的基线对比。"),[["基线",n],["当前",i]].forEach(function(e){var t=this.getSnapshotMoment(e[1]);d.push(e[0]+"："+(e[1].context.name||"未命名对象")+" / "+e[1].context.scope+" / "+(e[1].context.time||"未记录时间")+(t?" / "+t:""))}.bind(this)),d.push("基线值："+o(u.before)+" / 差值："+(null===u.delta?"数据不足":r(u.delta))+(null===u.rate?"":" / 幅度："+r(u.rate)+"%")),d.push("  属性变化 ("+h.rows.length+" 项, 不受定位来源筛选)："),h.rows.length||d.push("    属性数值与来源构成均与基线一致。"),h.rows.forEach(function(e){d.push("    "+this.getAttrLabel(e.attr)+(e.attr===a?" [当前查看]":"")+"："+o(e.before)+" → "+o(e.after)+" / "+(null===e.delta?"数据不足":0===e.delta?"来源构成变化":r(e.delta)))}.bind(this)),d.push("  上下文变化 ("+h.contextChanges.length+" 项)："),h.contextChanges.length||d.push("    对象与计算环境未变化。"),h.contextChanges.forEach(function(e){d.push("    "+e.name+"："+this.describeValue(e.before)+" → "+this.describeValue(e.after))}.bind(this)),d.push("  跨对象或环境的差异不能直接归因于单一系统。")}t.system&&d.push("定位来源："+this.getSystemLabel(t.system)+"；下面仅展开此系统，公式仍包含全部来源。"),d.push("\n【计算公式】");var p=this.getFormulaNodes(i,a,n);p.result?(d.push("static = sysOuterCoef * (sysOuterAdd + (baseAttr * innerCoef + addition) * outerCoef + outerAdd)","baseAttr = fixed * baseCoef + baseAdd"),i.formulas[a].operands.finalMultiplier&&d.push("static *= finalMultiplier"),d.push(p.dynamic?"static → "+p.dynamic.name+" → result":"result = static"),["fixed","baseCoef","baseAdd","baseAttr","innerCoef","addition","outerCoef","outerAdd","sysOuterCoef","sysOuterAdd","finalMultiplier","result"].forEach((function(e){var t=p[e];("finalMultiplier"!==e||i.formulas[a].operands.finalMultiplier)&&d.push("  "+e+" ("+t.label+") = "+o(t.value)+(t.changed?" / 较基线 "+(0===t.delta?"构成变化":r(t.delta)):""))})),d.push("\n【来源构成】百分比属于对应乘区，不是最终属性的独立涨幅。"),this.getNodeSources(i,a,p.result,n).forEach(function(e){var i=e.rows.filter((function(e){return!t.system||e.label===t.system}));i.length&&(d.push("\n"+e.group+" · "+e.label+" / 全部来源合计 "+this.formatGroupValue(e.group,e.total,s)),i.forEach(function(t){d.push("  "+this.getSystemLabel(t.label)+"："+this.formatGroupValue(e.group,t.value,s)+(t.changed?" (较基线 "+this.formatDelta(t.delta,s,e.group)+")":"")+(t.removed?" [已移除，以下为基线链路]":t.active?"":" [已被替换，不计入合计]")),(t.children.length?t.children:[t]).forEach(function(i){d.push("    "+i.label+" / "+this.fieldPath(e.group,a)+" += "+o(i.value)+(void 0!==i.delta&&i.changed?" (较基线 "+r(i.delta)+")":"")+(i.removed&&!t.removed?" [基线链路，当前已移除]":""));var n=i.reference;n&&n.paths&&d.push("      装备：id="+n.id+" / tid="+n.cfg_id+" / "+n.name+" / 强化="+n.enhance_lv),(n&&n.paths||[this.describeValue(n)]).forEach(function(e){d.push("      "+this.formatReference(e,s))}.bind(this))}.bind(this))}.bind(this)))}.bind(this))):d.push("未采集静态公式，仅能报告当前读值。");var _=this.getComparedOperations(i,a,n).filter(function(e){return!t.system||this.getOperationSystem(e)===t.system}.bind(this));(_.length||"战斗当前属性"===l.scope)&&(d.push("\n【"+("战斗当前属性"===l.scope?"战斗动态修改":"计算后处理")+"】按实际生效顺序记录；标记移除的条目仅保留基线过程。"),_.length||d.push("  "+this.getOperationEmptyText(i,a,t.system)),_.forEach(function(e){var t,i=this.getComparisonLabel(e);d.push("  "+e.label+(i?" ["+i+"]":"")+"："+o(e.before)+" → "+o(e.after)+" / "+(e.removed?"基线":"本次")+"加值 "+(((t=e.delta)>0?"+":"")+o(t))),!e.changed||e.added||e.removed||d.push("    加值相对基线变化："+r(e.comparisonDelta));var n=e.provenance,a=!e.added&&!e.removed&&e.baselineProvenance||{};n?(n.caster&&d.push("    施加者："+n.caster),void 0!==n.rank&&d.push("    叠层：rank="+n.rank+c(n.rank,a.rank)),d.push("    计算方式："+n.method,"    计算过程："+this.formatReference(n.calculation,s)),(n.sections||[{label:"取值链路",paths:n.paths}]).forEach(function(e){var t=(a.sections||[]).filter((function(t){return t.label===e.label}))[0];d.push("    "+e.label+(void 0===e.value?"":" = "+o(e.value)+c(e.value,t&&t.value))),e.paths.forEach(function(e){d.push("      "+this.formatReference(e,s))}.bind(this))}.bind(this))):d.push("    "+this.formatReference(e.detail,s)),"生效"!==e.status&&d.push("    ⚠ "+e.status)}.bind(this))),d.push("\n【计算上下文】"),this.getContextSections(l).forEach(function(e){e.rows.forEach(function(e){d.push("  "+e.name+" = "+this.describeValue(e.value))}.bind(this))}.bind(this));var f=i.warnings.slice();return!i.formulas[a]||i.formulas[a].matches&&i.formulas[a].inputsMatch||f.push("采集输入未能还原公式结果，请检查覆盖范围。"),f.length&&d.push("\n【采集限制】",f.map((function(e){return"  ⚠ "+e})).join("\n")),d.join("\n")},_syncEngine:function(){var e=ed.battleEngine;this._engine!==e&&(this._engine=e,this._records=[],this._session++)},_getRecord:function(e,t){this._syncEngine();for(var i=0;i<this._records.length;i++)if(this._records[i].unit===e)return this._records[i];if(!t)return null;var n={unit:e,serial:++this._serial};return this._records.length>=64&&this._records.shift(),this._records.push(n),n},_heroName:function(e){var t=ed.getDataTable("Unit")[e]||{},i=String(t.DisplayName||"").trim(),n=String(t.DisplayTitle||"").trim(),a=i||String(t.Name||"").trim(),s=n&&n!==a?n+(a?" - "+a:""):a;return i||(s+=(s?" · ":"")+"UnitID "+e),s},_makeContext:function(e,t,i){t=t||{};for(var n={},a=["equip_ignore","signature_ignore","transct_ignore","astrolabe_ignore","gveSystem_ignore"],s=0;s<a.length;s++)n[a[s]]=!!ed[a[s]];return ed.AttrDebugTraceData.copy({scope:i,id:e.id,tid:e.tid,name:this._heroName(e.tid),isPet:!!e.isPet,level:e.level,pentagram_lv:e.pentagram_lv,rank:e.rank,quality:e.quality,trans_quality:e.trans_quality,equips:this.getEquipContext(e.equips),sig:e.sig?{lv:e.sig.lv,isValid:e.sig.isValid}:null,gs_guild_tech_exp:void 0===t.gs_guild_tech_exp?"未提供":t.gs_guild_tech_exp,bag_hero_list:void 0===t.bag_hero_list?"未提供":t.bag_hero_list,astrolabe:t.astrolabe,mode:ed.battleEngine&&ed.battleEngine.mode,pvpRule:ed.unitAttribsMgr.getPvpEnvAttribsRuleMode()||"无",flags:n,pvpEnabled:ed.unitAttribsMgr.getIsPvpEnvEnabledByTid(e.tid),pvpAttrs:ed.attrib_names.filter((function(e){return ed.unitAttribsMgr.getIsPvpEnvEnableAttrib(e)})),pvpTotem:!(!ed.battleEngine||!ed.battleEngine.isPVPTotemActive),hp_mod:t.hp_mod,dps_mod:t.dps_mod,def_mod:t.def_mod,cacheEnabled:!!ed.useUnitAttribsCache,session:this._session,tick:ed.battleEngine&&ed.battleEngine.ticks,time:(new Date).toISOString()})},getContextSections:function(e){return[{title:"对象数据 · HeroData / proto",prefix:"proto.",keys:["id","tid","isPet","level","pentagram_lv","rank","quality","trans_quality","equips","sig"]},{title:"计算入参 · config",prefix:"config.",keys:["gs_guild_tech_exp","bag_hero_list","astrolabe","hp_mod","dps_mod","def_mod","slotIndex"]},{title:"战斗实例 · Unit",prefix:"unit.",keys:["camp","index_in_engine","hp","gs"]},{title:"调试采样环境",prefix:"",keys:["name","scope","isSelf","mode","pvpRule","pvpEnabled","pvpAttrs","pvpTotem","flags","cacheEnabled","session","tick","calculationTick","time"]}].map((function(t){return{title:t.title,rows:t.keys.filter((function(t){return void 0!==e[t]})).map((function(i){return{name:t.prefix+i,value:e[i]}}))}})).filter((function(e){return e.rows.length}))},getEquipContext:function(e){for(var t=[],i=0;e&&i<e.length;i++){var n=e[i].equip,a=n&&ed.getDataTable("Equip")[n.cfg_id];t.push(n?{index:e[i].index,id:n.id,cfg_id:n.cfg_id,name:a&&a.Name,enhance_lv:n.enhance_lv,quality:n.quality,attrs:ed.AttrDebugTraceData.copy(n.attrs),resonate_tid:n.resonate_tid,source_tid:n.source_tid}:{index:e[i].index})}return t},_captureHero:function(e){var t=ed.AttrDebugTraceData.copy(e.params||{});"normal"===this._mode&&(delete t.bag_hero_list,delete t.gs_guild_tech_exp);var i={hero:e.hero};this._heroRequest=i;try{"pet"===e.kind?ed.PetAttrDelegate.calculateBaseAttrib(e.hero,t,e.isSelf):"normal"===this._mode||e.useBaseEntry?ed.hero.cacluteBaseAttrib(e.hero,t,e.isSelf):ed.hero.caculatePanelAttrib(e.hero,t,e.isSelf)}finally{this._heroRequest=null}if(!i.trace)throw new Error("当前对象入口未经过通用属性计算");var n=i.trace;return n.finalResult=i.result,n.context.isSelf=e.isSelf,n.context.scope="pet"===e.kind?"宠物面板属性 · PetAttrDelegate，与正式宠物属性面板相同":"normal"===this._mode?"普通属性 · 不含后援":e.useBaseEntry?"面板属性 · 当前界面实际对象与入参，显示时向下取整":"面板属性 · 含后援，主界面攻防血显示时向下取整",n},_buildInitialSnapshot:function(e,t){return t&&t.initial?ed.AttrDebugTraceData.copy(t.initial):{context:this._makeContext(e.proto,e.config,"初始属性 · 静态构建"),finalResult:ed.AttrDebugTraceData.copy(e.fixed_attribs||{}),sources:[],inputs:[],formulas:{},operations:[],warnings:["本实例的初始构建过程未采集，当前只读 fixed_attribs；提前开启采集并进入下一场可查看完整公式。"]}},_buildUnitSnapshot:function(e,t){var i=t&&t.staticTrace?ed.AttrDebugTraceData.copy(t.staticTrace):{sources:[],inputs:[],formulas:{},operations:[],warnings:[]};i.staticContext=i.context,i.context=this._makeContext(e.proto,e.config,"战斗当前属性"),i.context.camp=e.camp,i.context.index_in_engine=e.index_in_engine,i.context.slotIndex=e.config&&e.config.slotIndex,i.context.hp=e.hp,i.context.gs=e.gs,i.finalResult=ed.AttrDebugTraceData.copy(e.attribs||{}),t&&t.staticTrace||i.warnings.push("静态过程未采集。请保持采集开启进入下一场战斗；本工具不会主动调用 Unit.rebuild。");var n=t&&t.dynamic;if(n){if(i.operations=ed.AttrDebugTraceData.copy(n.operations),i.context.calculationTick=n.context.tick,i.dynamicContext=ed.AttrDebugTraceData.copy(n.context),t.fixedResult){var a=this._closeOperations(t.fixedResult,[],n.initial);i.operations=a.concat(i.operations)}}else i.warnings.push("动态过程未采集，当前值为直接采样，不能据此推断没有 Buff 加成。");var s=n?n.result:t&&t.fixedResult;if(s)for(var o in i.finalResult)s[o]!==i.finalResult[o]&&i.operations.push({label:"采样时未追踪变化",attr:o,before:s[o],after:i.finalResult[o],delta:i.finalResult[o]-s[o],detail:"可能来自定制脚本或未覆盖的计算入口，不推断来源",status:"未展开"});return i},_closeOperations:function(e,t,i){for(var n=ed.AttrDebugTraceData.copy(e),a=[],s=function(e,t){n[e]!==t&&(a.push({label:"未追踪的中间变化",attr:e,before:n[e],after:t,delta:t-n[e],detail:"观测到定制或其它入口改写；不能推断内部来源",status:"未展开"}),n[e]=t)},o=0;o<t.length;o++){var r=t[o];s(r.attr,r.before),a.push(r),n[r.attr]=r.after}for(var c in i)s(c,i[c]);return a}});}
function __nativeFactory69(){return ({qualityToTransc:{},transcToQuality:{},maxKamuyLevel:5,initQualityTranscMap:function(){var e=ed.getDataTable("Transct");for(var t in e){var i=e[t];i.TransctLv>0&&(this.qualityToTransc[Number(t)]=i.TransctLv,this.transcToQuality[i.TransctLv]=Number(t))}},getQualityByTransct:function(e){return this.transctMapInit||(this.transctMapInit=!0,ed.HeroKamuyProxy.initQualityTranscMap()),this.transcToQuality[e]},getTransctByQuality:function(e){return this.transctMapInit||(this.transctMapInit=!0,ed.HeroKamuyProxy.initQualityTranscMap()),this.qualityToTransc[e]},isInKamuyLevel:function(e){return e&&e<=ed.HeroKamuyProxy.maxKamuyLevel},getHeroKamuyCfgArr:function(e){var t=ed.getDataTable("TransctHeroNode")[e],i=[];for(var a in t)Number(a)<=ed.HeroKamuyProxy.maxKamuyLevel&&i.push(t[a]);return i.sort((function(e,t){return e.TransctLv-t.TransctLv})),i},getHeroTransctCfg:function(e,t){var i=ed.getDataTable("TransctHeroNode")[e];return i&&i[t]},isTransctEnabled:function(e){var t=ed.getDataTable("TransctHero")[e];return t&&t.Enable},isKamuyOpen:function(e,t){return!!this.isTransctEnabled(e)&&!!this.getTransctByQuality(t)},isKamuyUnlock:function(e,t,i){return!!ed.HeroKamuyProxy.isKamuyOpen(e,i)&&i>=ed.HeroKamuyProxy.getQualityByTransct(t)},getAllTransctAttr:function(e,t,i){if(!t||t<=0)return{};var a=ed.getDataTable("TransctHeroAttrs")[e];if(!a)return{};var n=a[t]||{},s=n.AttrList,o={};return this.getSplitArrMap(s,o),i&&(s=n.PVP_AttrList,this.getSplitArrMap(s,o)),o},getSplitArrMap:function(e,t){if(e)for(var i=e.split(";"),a=0;a<i.length;a+=2){var n=i[a];t[n]?t[n]+=Number(i[a+1]):t[n]=Number(i[a+1])}},getTransctSingleAttrInfo:function(e,t,i){var a=this.getTransctByQuality(t),n=this.getHeroTransctCfg(e,a)[i?"PVP_AttrList":"AttrList"],s=[],o={};if(n)for(var r=n.split(";"),c=0;c<r.length;c+=2){var l=r[c];if(o[l])o[l]+=Number(r[c+1]);else{var d={attrName:l,attrValue:Number(r[c+1])};o[l]=d,s.push(d)}}return s},getAllTransctAttrInfoStr:function(e,t){for(var i=[],a=0;a<e.length;a++)i.push(this.getTransctAttrInfoStr(e[a],t));return t?i.join("<text|  |skill_desc_normal_18>"):i.join("  ")},getTransctAttrInfoStr:function(e,t){var i=e.attrName;if(i.endsWith(".PR")){i=i.split(".")[0];var a=ed.hero.getAttributes(i,!0);return(n=t?"<text|{0}|skill_desc_normal_18><text| +{1}%|skill_desc_green_18>":"{0} +{1}%").format(a,e.attrValue)}a=ed.hero.getAttributes(i,!0);var n="";return ed.attrib_names_hash[i]&&(n=t?"<text|{0}|skill_desc_normal_18><text| +{1}|skill_desc_green_18>":"{0} +{1}"),n.format(a,e.attrValue)},getKamuyDescBySkillId:function(e,t,i){var a=ed.skillDescReader.getUpgradeDescBySkillId(e,t,i);return a||(a=ed.skillDescReader.getDescBySkillId(e,t,i)),a},getKamuyShortDescBySkillId:function(e,t,i){var a=ed.skillDescReader.getShortUpgradeDescBySkillId(e,t,i);return a||(a=ed.skillDescReader.getShortDescBySkillId(e,t,i)),a},getTransctAttrByType:function(e,t,i){if(!t||t<=0)return{};var a=ed.getDataTable("TransctHeroAttrs")[e];if(!a)return{};var n=(a[t]||{})["pvp"===i?"PVP_AttrList":"AttrList"],s={};return n&&this.getSplitArrMap(n,s),s},checkHeroHasKamuyRedDot:function(e){if(10!==e.quality)return!1;var t=ed.player.getUid(),i="KAMUY_FIRST_QUALITY_WHITE_{0}_{1}".format(t,e.tid);return"true"===window.localStorage.getItem(i)},addKamuyRedDot:function(e){var t=ed.player.getUid(),i="KAMUY_FIRST_QUALITY_WHITE_{0}_{1}".format(t,e.tid);window.localStorage.setItem(i,"true")},removeKamuyRedDot:function(e){if(this.checkHeroHasKamuyRedDot(e)){var t=ed.player.getUid(),i="KAMUY_FIRST_QUALITY_WHITE_{0}_{1}".format(t,e.tid);window.localStorage.setItem(i,"false"),ed.fireEvent("KAMUY_FIRST_QUALITY_WHITE_REMOVE")}},addAllNewKamuyRedDot:function(){var e=ed.getDataTable("TransctHero"),t=this.getCurVersion();for(var i in e){var a=Number(i);if(this.checkHeroVersionValid(a,t)){var n=ed.playerhero.getMaxQualityHeroByTid(Number(i),!0);this.addNewKamuyRedDot(n)}}},addNewKamuyRedDot:function(e){if(e&&e.quality>=10&&this.checkHeroVersionValid(e.tid,this.getCurVersion())){var t=ed.player.getUid(),i="KAMUY_NEW_HERO_ONLINE_{0}_{1}".format(t,e.tid);"false"!==window.localStorage.getItem(i)&&window.localStorage.setItem(i,"true")}},checkNewHeroKamuyRedDot:function(e){if(e.quality<10)return!1;var t=ed.player.getUid(),i="KAMUY_NEW_HERO_ONLINE_{0}_{1}".format(t,e.tid);return"true"===window.localStorage.getItem(i)},getCurVersion:function(){var e=/v(\d+\.\d+)/.exec(cc.game.config.latestVersion);if(e)return e[1]},checkHeroVersionValid:function(e,t){if(!t)return!1;if(!this.isTransctEnabled(e))return!1;var i=ed.getDataTable("TransctHero")[e];if(!i||!i.OpenDev)return!1;var a=i.OpenDev;return!!a&&a===t},removeNewHeroKamuyRedDot:function(e){if(this.checkNewHeroKamuyRedDot(e)){var t=ed.player.getUid(),i="KAMUY_NEW_HERO_ONLINE_{0}_{1}".format(t,e.tid);window.localStorage.setItem(i,"false"),ed.fireEvent("KAMUY_NEW_HERO_ONLINE_REMOVE")}}});}
function __nativeFactory70(){return ([]);}
function __nativeFactory71(){return (function(e){if(e){var t=ed.getStageBattleTableInfo(e).BattleGroundID;return ed.getDataTable("BattleGround")[t]}});}
function __nativeFactory72(){return (function(e,t,i){if(!e||!e.level)return 0;if(!t||!t.level)return 0;var a=ed.lookupDataTable("UnitLevel","DisplayLevel",e.level)-ed.lookupDataTable("UnitLevel","DisplayLevel",t.level)-(i=i||0);return a<=0?0:ed.lookupDataTable("StageLevelSuppress","DmgAddRatio",a)||0});}
function __nativeFactory73(){return (function(e){return ed.lookupDataTable("Unit","HeroTagID",e)});}
function __nativeFactory74(){return (function(e,t,i){if(i&&ed.WarBattleMgr.getIsWarBattleMode(i))return ed.getWarTeamTexas(e);var a={formation:null,devilCount:0};if(e.length>=1){for(var n=[0,0,0,0,0,0,0,0],s=0,o=0,r=0,c=e.length;r<c;r++){var l=e[r];if(l>0){var d=ed.getTagIdByHeroId(l);"number"==typeof n[d]&&n[d]++,5===d?s++:6===d&&o++}}t||(n[5]=0,n[6]=0),n.sort((function(e,t){return t-e}));var h=n[0];if(t?s=0:h+=o,h>=3)if(5===h)a.formation="Flush";else if(4===h)a.formation="Four_A_Kind";else{var _=n[1];a.formation=_>=2?"Full_House":"Three_A_Kind"}}return a.devilCount=s,a});}
function __nativeFactory75(){return (function(e){var t=e.config;return t?cc.clone(t):{}});}
function __nativeFactory76(){return (function(e){if(!e)return null;var t=ed.lookupDataTable("StageBattleIdx","Type",e);if(!t)return cc.error("StageBattleIdx battleId not found: "+e),null;var i="StageBattle"+t;return ed.lookupDataTable(i,e)});}
function __nativeFactory77(){return (function(e,t){var i=null;"shootGame"!==t&&"shootGameInfinity"!=t&&(i=ed.getStageBattleTableInfo(e));var a=1;if(!i)switch(t){case"stage":default:var n;(n=ed.lookupDataTable("StageBattleIndex",e))&&(a=n.ChapterID),i=ed.lookupDataTable("StageBattleChap"+a,e);break;case"shootGame":i=ed.getDataTable("MiniGameStageStage")[e];break;case"shootGameInfinity":i=ed.getDataTable("MiniGameStageInfinityStage")[e]}return i||cc.error("Missing battleID in StageBattleTable or StageBattleChapXTable!"),i});}
function __nativeFactory78(){return (function(){var e=null;return ed.fullBtScene?e=ed.fullBtScene:ed.turnbasedBtScene?e=ed.turnbasedBtScene:ed.guildBtScene?e=ed.guildBtScene:ed.multiTeamBtScene?e=ed.multiTeamBtScene:ed.bossBtScene?e=ed.bossBtScene:ed.realtimeBattleScene?e=ed.realtimeBattleScene:ed.battleInfiniteScene?e=ed.battleInfiniteScene:ed.guildFeastBtScene?e=ed.guildFeastBtScene:ed.guildZooBtScene?e=ed.guildZooBtScene:ed.idlePvpScene?e=ed.idlePvpScene:ed.pipNodeBattle?e=ed.pipNodeBattle:ed.backgroundBattleView?e=ed.backgroundBattleView:ed.pipBtScene&&(e=ed.pipBtScene),e});}
function __nativeFactory79(){return (function(e,t,i){switch(e=Math.floor(1e4*e),t=Math.floor(1e4*t),i){case">":return e>t;case">=":return e>=t;case"<":return e<t;case"<=":return e<=t;case"==":return e==t;default:cc.error("unknow operator:"+i)}});}
function __nativeFactory80(){return (function(e){if(!e)return!1;var t,i=!1,a=!1,n=!1,s=ed.battleEngine.config&&ed.battleEngine.config.mode;if(s){var o=ed.getDataTable("Param").Stage.UseSkillCacheStageBattle.StrValue.split(";"),r=ed.parseUseSkillCacheStageBattle(o);for(var c in r)if(c==s){i=!0;for(var l=ed.battleEngine.getBattleId(),d=r[c],h=0;h<d.length;h++){var _=d[h];if(l>=_[0]&&l<=_[1]){a=!0;break}}if(a)break}}var u=e.info.ID,g=ed.getDataTable("Param").Stage.UseSkillCacheHeroList.StrValue.split(";");for(h=0;h<g.length;h++)if(g[h]==u){n=!0;break}return t=e.camp===ed.battle_camp.enemy,i&&a&&n&&t});}
function __nativeFactory81(){return (function(e){if(!e||!Array.isArray(e))return cc.warn("battleModeRangeParser parseConfigArray: invalid input array"),{};for(var t={},i=null,a=0;a<e.length;){var n=e[a];if(!isNaN(parseInt(n))&&isFinite(n)){if(!i){cc.warn("battleModeRangeParser parseConfigArray: found numeric value without battle mode at index",a),a++;continue}if(a+1>=e.length){cc.warn("battleModeRangeParser parseConfigArray: incomplete range data for mode",i,"at index",a);break}var s=parseInt(n),o=parseInt(e[a+1]);if(isNaN(s)||isNaN(o)){cc.warn("battleModeRangeParser parseConfigArray: invalid range values",n,e[a+1]),a+=2;continue}t[i]||(t[i]=[]),t[i].push([s,o]),a+=2}else i=n,a++}return t});}
function __nativeFactory82(){return ({skinRewardType:{MEDAL:"medal",DYN_AVATAR:"dyn_avatar"},skinLevel:{LEVEL_B:1,LEVEL_A:2,LEVEL_S:3,LEVEL_SPECIAL:999},setJumpSkinId:function(e){this.jump_skin_id=e},getJumpSkinId:function(){return this.jump_skin_id},getHeroCrtSkin:function(e){return e.skin?ed.lookupDataTable("Skin","Puppet",e.skin):null},getSkinById:function(e){return ed.getDataTable("Skin")[e]},getHeroAllSkin:function(e){for(var t=e.tid,i=-1,n=[],s=ed.getDataTable("Skin"),a=ed.platformMgr.getPlatformName();++i<10;){var o=s["{0}0{1}".format(t,i)];o&&(o.Plat.indexOf("all")>=0||o.Plat.indexOf(a)>=0)&&n.push(o)}return n},addSkin:function(e){ed.player.data.skins=ed.player.data.skins||[],ed.player.data.skins.push(e)},getAllSkin:function(){return ed.player.data.skins||[]},checkSkinActive:function(e){return(ed.player.data.skins||[]).indexOf(e)>-1},getSkinItem:function(){for(var e=ed.bagMgr.getItems(),t=-1,i=[];++t<e.length;){var n=e[t];"Skin"===n.cfg.Type&&i.push(n)}return i},waitWearSkinHeroes:function(){for(var e=[],t=this.getSkinItem(),i=-1,n=ed.skinMgr.getAllSkin();++i<t.length;){var s=t[i].cfg.TypeParameter,a=this.getSkinById(s);if(a&&n.indexOf(a.ID)<0){for(var o=a.HeroID,r=ed.playerhero.getHerosByTid(o),d=-1,c=!1;++d<r.length;)r[d].skin===a.ID&&(c=!0);c||(e=e.concat(r))}}return e},waitWearHeroesIds:function(){for(var e=this.waitWearSkinHeroes(),t={},i=-1;++i<e.length;)t[e[i].id]=!0;return t},unLockSkin:function(e){if(e){var t=""+e;if("0"!==t[t.length-1]){var i={unlock:e},n=this;this.reqSkin(i,(function(t){var i=t.unlock,s=i.result,a=i.cost;"success"===s&&(n.addSkin(e),n._shareSkinInfoToIm(e),ed.player.consumption(a),ed.fireEvent("skin_owner_new_fashion"))}))}}},checkSkinRewardById:function(e,t){for(var i=ed.player.data.skin_rewards||[],n=0;n<i.length;n++){var s=i[n];if(s.type===t&&(s.recvd_skin_tids&&!(s.recvd_skin_tids.length<=0)))for(var a=0;a<s.recvd_skin_tids.length;a++){if(s.recvd_skin_tids[a]===e)return!0}}return!1},_updateSkinRewardInfo:function(e,t){ed.player.data.skin_rewards||(ed.player.data.skin_rewards=[]);for(var i=ed.player.data.skin_rewards,n=0;n<i.length;n++)if(i[n].type===t)return void(i[n]=e);i.push(e)},checkIsSuperSkin:function(e){if(!e)return!1;var t=this.getSkinById(e);return!!t&&t.Level>=ed.skinMgr.skinLevel.LEVEL_S},getBestHeroBySkin:function(e){for(var t=this.getSkinById(e).HeroID,i=ed.playerhero.getHerosByTid(t),n=-1,s=null,a=0;++n<i.length;){var o=i[n];a<o.gs&&o.skin!=e&&(a=o.gs,s=o)}return s},autoChangeSkin:function(e){for(var t=this.getSkinById(e).HeroID,i=ed.playerhero.getHerosByTid(t),n=-1,s=-1,a=0;++n<i.length;){var o=i[n];a<o.gs&&o.skin!=e&&(a=o.gs,s=o.id)}var r={unlock_and_wear:{hero_id:s,skin:e}};this.reqSkin(r,(function(e){if("success"===e.unlock_and_wear.result){var t=e.unlock_and_wear.cost,i=e.unlock_and_wear.new_hero;ed.player.consumption(t),ed.playerhero.updateHeroes([i]),ed.fireEvent("hero_change_skin",i),ed.showToast(T("skin_mgr_0_1194508017_0","更换成功"))}}))},changeSkin:function(e,t){var i={wear:{hero_id:e,skin:t}};this.reqSkin(i,(function(e){var t=e.wear;ed.playerhero.updateHeroes([t]),ed.showToast(T("skin_mgr_2_510039634_0","更换成功")),ed.fireEvent("hero_change_skin",t)}))},openPanel:function(e,t){this.reqSkin({open_panel:{}},(function(e){e.open_panel&&t&&t(e.open_panel.charge_skins)}))},checkHeroSkinTagRedTip:function(e){if(this.waitWearHeroesIds()[e]>=0)return!0;for(var t=ed.playerhero.getMyHero(e),i=ed.skinMgr.getHeroAllSkin(t),n=0;n<i.length;n++){var s=i[n];if(ed.skinMgr.checkSkinActive(s.ID)||"default"===s.Type){var a=ed.skinMgr.getSkinById(s.ID);if(a.Level>ed.skinMgr.skinLevel.LEVEL_A&&a.Level!==ed.skinMgr.skinLevel.LEVEL_SPECIAL&&!this.checkSkinRewardById(s.ID,ed.skinMgr.skinRewardType.MEDAL))return!0;if(a.Level>ed.skinMgr.skinLevel.LEVEL_S&&!this.checkSkinRewardById(s.ID,ed.skinMgr.skinRewardType.DYN_AVATAR))return!0}}return!1},reqSkin:function(e,t){ed.rpc.send("req_skin",e,(function(e){t&&t(e.reply_skin)}))},reqSkinMedal:function(e,t){var i={recv_skin_reward:{skin_tid:e,type:ed.skinMgr.skinRewardType.MEDAL}},n=this;ed.rpc.send("req_skin",i,(function(i){var s=i.reply_skin.recv_skin_reward;if(s){n._updateSkinRewardInfo(s.skin_reward,ed.skinMgr.skinRewardType.MEDAL);var a=ed.skinMgr.getSkinById(e),o=ed.medalMgr.getInstance().getMedalDataByID(a.Medal[1]);o&&o.setEnableTimestamp(ed.getServerTime()),t&&t(),ed.fireEvent("hero_skin_red_refresh")}}))},reqSkinDynAvatar:function(e,t){var i={recv_skin_reward:{skin_tid:e,type:ed.skinMgr.skinRewardType.DYN_AVATAR}},n=this;ed.rpc.send("req_skin",i,(function(e){var i=e.reply_skin.recv_skin_reward;i&&(n._updateSkinRewardInfo(i.skin_reward,ed.skinMgr.skinRewardType.DYN_AVATAR),t&&t(),ed.fireEvent("hero_skin_red_refresh"))}))},jumpCode:{code_Anniversary:function(e){},code_raid_Trade:function(e){var t=e.ID;ed.activityMgr.showActivity(t)},code_raid_food:function(e){var t=e.Option||19,i=e.ID;ed.Anni2023Manager.openEntranceView(t,(function(){ed.activityMgr.showActivity(i)}),!0)},code_raid_mira:function(e){var t=e.Option||29,i=e.ID;if(!ed.openHelper.checkOpen("Raid",!0))return!1;ed.midWinter2024ViewMgr.openEntranceView(t,(function(){ed.activityMgr.showActivity(i)}),!0)},code_anniv2026_entrance:function(e){var t=e.Option||36;ed.anni2026ViewMgr.openEntranceView(t,null,!0)},code_raid_monster:function(e){var t=e.Option||31,i=e.ID;if(!ed.openHelper.checkOpen("Raid",!0))return!1;ed.anni2025ViewMgr.openEntranceView(t,(function(){ed.activityMgr.showActivity(i)}),!0)}},jumpToActivity:function(e){if(ed.viewManager.popToMain(),ed.fastEntry.battle(),e){var t=ed.activityModel.getActivityInfo(e);if(t){var i=t.Code;i?this.jumpCode[i]?this.jumpCode[i](t):ed.activityRegisterCodeTable[i](t.ID):ed.showToast(T("skin_select_0_893862845_0","活动已结束。"))}else ed.showToast(T("skin_select_0_893862845_0","活动已结束。"))}else ed.showToast(T("skin_select_0_893862845_0","活动已结束。"))},hasSkin:function(e){var t=""+e;if("0"===t[t.length-1])return!0;if(ed.skinMgr.getAllSkin().indexOf(e)>-1)return!0;for(var i=ed.skinMgr.getSkinItem(),n=0;n<i.length;n++){if(i[n].cfg.TypeParameter==e)return!0}return!1},_shareSkinInfoToIm:function(e){var t=this.getSkinById(e);if(!(t.Level<ed.skinMgr.skinLevel.LEVEL_S||t.Level===ed.skinMgr.skinLevel.LEVEL_SPECIAL)){var i={shareId:ed.imChatShareID.SKIN,skinId:e,uid:ed.player.getUid()},n=ed.imChatMgr.getChannelIdByBaseId(ed.imChatBaseIdMap.BASE_ID);n&&ed.imChatMgr.share(ed.imChatChannelType.CCH_GAME_ROOM,n,i);var s=ed.imChatMgr.getChannelIdByBaseId(ed.imChatBaseIdMap.GUILD);s&&ed.imChatMgr.share(ed.imChatChannelType.CCH_GAME_GROUP,s,i)}},getCrossPrivilegeSkin:function(e){for(var t=this.getHeroAllSkin({tid:e}),i=0;i<t.length;i++){var n=t[i];if(n.Level===ed.skinMgr.skinLevel.LEVEL_SPECIAL)return n}return null},checkHeroIsHaved:function(e){var t=this.getSkinById(e);if("default"===t.Type&&t.Level===ed.skinMgr.skinLevel.LEVEL_SPECIAL){var i=t.HeroID;return ed.playerhero.getHerosByTid(i).length>0}return!0}});}
function __nativeFactory83(){return ({IDLE:"Idle",DAILY_TASK:"DailyTask",WEEKLY_TASK:"WeeklyTask",GUILD_TURNTABLE:"GuildTurntable",GUILD_BOAT:"GuildBoat",GUILD_VEHICLE:"GuildVehicle",GUILD_ATTR:"GuildAttr"});}
function __nativeFactory84(){return ({MUL:"Mul",IDLE_TIME_ADD:"IdleTimeAdd",ADD:"Add",UNLOCK_MULTI_ROLL:"UnlockMultiRoll",REPLACE_BLOCK:"ReplaceBlock",ADD_TARGET_BLOCK_REWARD:"AddTargetBlockReward",ADD_BLOCK_TYPE_REWARD:"AddBlockTypeReward",QTE_PROBABILITY:"QteProbability",REPLACE_DAILY_REWARD:"ReplaceDailyReward",REDUCE_TIME:"ReduceTime",UNLOCK_SLOT:"UnlockSlot",ADD_ATTR:"AddAttr"});}
function __nativeFactory85(){return ({_techExp:0,_techLevel:0,_allTechConfigs:null,_effectUnlockLevelsMap:null,_getEffectUnlockLevelsMap:function(){if(this._effectUnlockLevelsMap)return this._effectUnlockLevelsMap;for(var e={},t=this.getAllTechConfigs(),i=0;i<t.length;i++){var n=t[i],s=n.EffectID,a=e[s];a||(a=[],e[s]=a),a.push(n.Level)}return this._effectUnlockLevelsMap=e,this._effectUnlockLevelsMap},getTechConfig:function(e){return ed.getDataTable("GuildTurntableTech")[e]},getTechEffectConfig:function(e){return ed.getDataTable("GuildTurntableEffect")[e]},getTechEffectName:function(e){var t=this.getTechEffectConfig(e);return t.EffectName.format([t.Level])},getSupportBonusConfig:function(e){return ed.getDataTable("GuildTurntableSupportBonus")[e]},getAllTechConfigs:function(){if(this._allTechConfigs)return this._allTechConfigs;var e=ed.getDataTable("GuildTurntableTech"),t=[];for(var i in e){var n=e[i];t.push(n)}return t.sort((function(e,t){return e.Level-t.Level})),this._allTechConfigs=t,this._allTechConfigs},getTechLevelByExp:function(e){for(var t=0,i=this.getAllTechConfigs(),n=0;n<i.length;n++){var s=i[n];if(!(s.Value<=e))break;t=s.Level}return t},getMaxTechLevel:function(){var e=this.getAllTechConfigs();return e.length>0?e[e.length-1].Level:0},getMaxTechLevelExp:function(){var e=this.getAllTechConfigs();return e.length>0?e[e.length-1].Value:0},getTechExp:function(){return this._techExp},getTechLevel:function(){return this._techLevel},getTechProgress:function(){var e=this.getTechExp(),t=this.getTechLevel(),i=this.getTechConfig(t),n=this.getTechConfig(t+1),s=i?i.Value:0,a=n?n.Value:s,o=Math.max(0,e-s),r=Math.max(0,a-s);return{level:t,techExp:e,startValue:s,targetValue:a,progressValue:o,targetProgress:r,percent:r>0?Math.min(o/r,1):1,isMaxLevel:!n}},updateTechExp:function(e){var t=e||0,i=this.getTechExp(),n=this.getTechLevel(),s=this.getTechLevelByExp(t);if(this._techExp=t,this._techLevel=s,ed.gManorMgr.updateSelfGuildTechExp(t),i!==t){var a={techExp:t,oldTechExp:i,techLevel:s,oldTechLevel:n};ed.fireEvent(ed.GuildTurntableTechEvent.GUILD_TURNTABLE_TECH_EXP_CHANGE_EVENT,a),s>n&&ed.fireEvent(ed.GuildTurntableTechEvent.GUILD_TURNTABLE_TECH_LEVEL_UP_EVENT,a)}},clearTechData:function(){var e=this.getTechExp(),t=this.getTechLevel();this._techExp=0,this._techLevel=0,(e||t)&&ed.fireEvent(ed.GuildTurntableTechEvent.GUILD_TURNTABLE_TECH_EXP_CHANGE_EVENT,{techExp:0,oldTechExp:e,techLevel:0,oldTechLevel:t})},getTechDisplayHistory:function(){var e=(ed.ukvMgr.getValue(ed.UkvType.GuildTurntableTech)||"").split(";");return{highestTechExp:parseInt(e[0],10)||0,lastTechExp:parseInt(e[1],10)||0}},setTechDisplayHistory:function(e,t,i){var n=this.getMaxTechLevelExp(),s=[Math.min(e,n),Math.min(t,n)].join(";");ed.ukvMgr.setValue(ed.UkvType.GuildTurntableTech,s,i)},checkTechLevelUnlocked:function(e){return this.getTechLevel()>=e},checkTechEffectUnlocked:function(e){var t=this._getEffectUnlockLevelsMap()[e];return!!t&&this.checkTechLevelUnlocked(t[0])},getUnlockedTechEffectIds:function(e){for(var t=[],i=void 0===e?this.getTechLevel():e,n=Math.min(i,this.getMaxTechLevel()),s=1;s<=n;s++)t.push(this.getTechConfig(s).EffectID);return t},getUnlockedTechEffectsByType:function(e,t,i){for(var n=this.getUnlockedTechEffectIds(i),s=[],a=0;a<n.length;a++){var o=n[a],r=this.getTechEffectConfig(o);r?r.EffectModule===e&&r.EffectArgType===t&&s.push({techLevel:a+1,effectId:o,effectConfig:r}):cc.error("GuildTurntable missing tech effect",o,a+1)}return s},getUnlockedTechEffectIdsByType:function(e,t,i){for(var n=this.getUnlockedTechEffectsByType(e,t,i),s=[],a=0;a<n.length;a++)s.push(n[a].effectId);return s},checkMultiRollUnlocked:function(e){var t=ed.GuildTurntableTechEffectModule.GUILD_TURNTABLE,i=ed.GuildTurntableTechEffectArgType.UNLOCK_MULTI_ROLL;return this.getUnlockedTechEffectIdsByType(t,i,e).length>0},getMultiRollUnlockTechName:function(){for(var e=ed.GuildTurntableTechEffectModule.GUILD_TURNTABLE,t=ed.GuildTurntableTechEffectArgType.UNLOCK_MULTI_ROLL,i=this.getAllTechConfigs(),n=0;n<i.length;n++){var s=i[n].EffectID,a=this.getTechEffectConfig(s);if(a.EffectModule===e&&a.EffectArgType===t)return this.getTechEffectName(s)}return cc.assert(!1,"[GuildTurntableTechMgr] missing UnlockMultiRoll tech effect"),""},getTechBlockReplacements:function(e){for(var t=ed.GuildTurntableTechEffectModule.GUILD_TURNTABLE,i=ed.GuildTurntableTechEffectArgType.REPLACE_BLOCK,n=this.getUnlockedTechEffectsByType(t,i,e),s={},a=0;a<n.length;a++){var o=n[a],r=o.effectConfig,d=r.ModuleArg,c=r.EffectArg2;if(d.length===c.length)for(var l=0;l<d.length;l++){var h=d[l],u=c[l];ed.GuildTurntableMgr.getBoardMapConfig(h)&&ed.GuildTurntableMgr.getBoardBlockConfig(u)?s[h]={blockIndex:h,blockId:u,effectId:r.ID,techLevel:o.techLevel}:cc.error("GuildTurntable invalid ReplaceBlock target",r.ID,h,u)}else cc.error("GuildTurntable ReplaceBlock args mismatch",r.ID,d,c)}var _=[];for(var g in s){var p=s[g];_.push(p)}return _.sort((function(e,t){return e.blockIndex-t.blockIndex})),_},getTechBlockReplacementMap:function(e){for(var t=this.getTechBlockReplacements(e),i={},n=0;n<t.length;n++)i[t[n].blockIndex]=t[n];return i},getBoardRewardBonuses:function(e){for(var t=this.getUnlockedTechEffectIds(e),i=[],n=[],s=0;s<t.length;s++){var a=this.getTechEffectConfig(t[s]);a?a.EffectModule===ed.GuildTurntableTechEffectModule.GUILD_TURNTABLE&&(a.EffectArgType===ed.GuildTurntableTechEffectArgType.ADD_TARGET_BLOCK_REWARD?i.push(a):a.EffectArgType===ed.GuildTurntableTechEffectArgType.ADD_BLOCK_TYPE_REWARD&&n.push(a)):cc.error("GuildTurntable missing tech effect",t[s],s+1)}var o=this.getTechBlockReplacementMap(e),r=ed.getDataTable("GuildTurntableMap"),d=[];for(var c in r){var l=r[c],h=l.ID,u=o[h],_=u?u.blockId:l.BlockID,g=ed.GuildTurntableMgr.getBoardBlockConfig(_);g?d.push({blockIndex:h,blockId:_,blockType:g.Type}):cc.error("GuildTurntable missing board block",_,h)}for(var p=[],f=0;f<d.length;f++){var m=d[f],v=[],b=[];this._collectBoardBonusRewards(i,"ModuleArg",m.blockIndex,v,b),this._collectBoardBonusRewards(n,"ModuleArg2",m.blockType,v,b),p.push({blockIndex:m.blockIndex,blockId:m.blockId,blockType:m.blockType,reward:this._mergeRewards(v),sourceEffectIds:b})}return p.sort((function(e,t){return e.blockIndex-t.blockIndex})),p},getDailyBoatRewardReplacement:function(){var e=ed.GuildTurntableTechEffectModule.GUILD_BOAT,t=ed.GuildTurntableTechEffectArgType.REPLACE_DAILY_REWARD,i=this.getUnlockedTechEffectsByType(e,t);if(i.length<=0)return null;var n=i[i.length-1];return{effectId:n.effectId,techLevel:n.techLevel,reward:this._parseEffectReward(n.effectConfig)}},getBoatTimeReducePercent:function(e){for(var t=ed.GuildTurntableTechEffectModule.GUILD_BOAT,i=ed.GuildTurntableTechEffectArgType.REDUCE_TIME,n=this.getUnlockedTechEffectsByType(t,i),s=0,a=0;a<n.length;a++)for(var o=n[a].effectConfig,r=o.ModuleArg,d=o.EffectArg2[0],c=0;c<r.length;c++)r[c]===e&&(s+=d);return s},getUnlockedBoatSlotIds:function(){for(var e=ed.GuildTurntableTechEffectModule.GUILD_BOAT,t=ed.GuildTurntableTechEffectArgType.UNLOCK_SLOT,i=this.getUnlockedTechEffectsByType(e,t),n=[],s=0;s<i.length;s++)for(var a=i[s].effectConfig.ModuleArg,o=0;o<a.length;o++)n.indexOf(a[o])<0&&n.push(a[o]);return n.sort((function(e,t){return e-t})),n},getIdleMulRewards:function(){return this._getMergedEffectRewards(ed.GuildTurntableTechEffectModule.IDLE,ed.GuildTurntableTechEffectArgType.MUL)},getIdleTimeAddRewards:function(){return this._getMergedEffectRewards(ed.GuildTurntableTechEffectModule.IDLE,ed.GuildTurntableTechEffectArgType.IDLE_TIME_ADD)},getTaskAddedRewards:function(e,t){var i;if("daily"===e)i=ed.GuildTurntableTechEffectModule.DAILY_TASK;else{if("weekly"!==e)return ed.readreward.createReward();i=ed.GuildTurntableTechEffectModule.WEEKLY_TASK}for(var n=this.getUnlockedTechEffectsByType(i,ed.GuildTurntableTechEffectArgType.ADD),s=[],a=0;a<n.length;a++){var o=n[a].effectConfig;o.ModuleArg.indexOf(t)>=0&&s.push(this._parseEffectReward(o))}return this._mergeRewards(s)},getDailyTaskAddedRewards:function(e){return this.getTaskAddedRewards("daily",e)},getGuildVehicleMulRewards:function(){return this._getMergedEffectRewards(ed.GuildTurntableTechEffectModule.GUILD_VEHICLE,ed.GuildTurntableTechEffectArgType.MUL)},getGuildSupportBonusList:function(e){for(var t=void 0===e?this.getTechExp():e,i=this.getTechLevelByExp(t),n=this.getUnlockedTechEffectsByType(ed.GuildTurntableTechEffectModule.GUILD_ATTR,ed.GuildTurntableTechEffectArgType.ADD_ATTR,i),s=[],a=0;a<n.length;a++)for(var o=this._getGuildSupportBonusDataListByEffect(n[a].effectConfig,n[a].techLevel),r=0;r<o.length;r++)s.push(o[r]);return s},getTechEffectRichText:function(e){var t=this.getTechEffectConfig(e);return t?this._formatEffectRichTexts(t).join("<changeLine>"):(cc.error("GuildTurntable missing tech effect",e),"")},getTechOverviewRows:function(e,t,i){for(var n=this.getUnlockedTechEffectIds(t),s=i||0,a={},o=[],r=[],d=0;d<n.length;d++){var c=d+1;if(!(c<=s))if(this.getTechConfig(c).IsCore===e){var l=this.getTechEffectConfig(n[d]);if(l)if(l.TipRule===ed.GuildTurntableTechTipRule.CFG)if(this._isGuildAttrEffect(l))for(var h=this._getGuildSupportBonusDataListByEffect(l,c),u=0;u<h.length;u++){var _=h[u],g=this._getSupportBonusDescriptionData(_);if(g){var p=["Cfg",l.EffectModule,l.EffectArgType,g.description].join("|");a[p]||(a[p]={entries:[]},o.push(a[p])),a[p].entries.push({techLevel:c,effectConfig:l,supportBonusData:_,descriptionData:g})}}else cc.error("GuildTurntable unsupported Cfg effect",c,l.ID,l.EffectModule,l.EffectArgType);else{var f=[l.EffectModule,l.EffectArgType,l.EffectTips].join("|");a[f]||(a[f]={entries:[]},o.push(a[f])),a[f].entries.push({techLevel:c,effectConfig:l})}else cc.error("GuildTurntable missing tech effect",n[d],c),r.push({techLevel:c,effectIds:[n[d]],richText:"",sortOrder:r.length})}}for(var m=0;m<o.length;m++)this._appendOverviewGroupRows(o[m],r);return r.sort((function(e,t){return e.techLevel!==t.techLevel?e.techLevel-t.techLevel:e.sortOrder-t.sortOrder})),r},_collectBoardBonusRewards:function(e,t,i,n,s){for(var a=0;a<e.length;a++){var o=e[a];o[t].indexOf(i)>=0&&(n.push(this._parseEffectReward(o)),s.push(o.ID))}},_getMergedEffectRewards:function(e,t){for(var i=this.getUnlockedTechEffectsByType(e,t),n=[],s=0;s<i.length;s++)n.push(this._parseEffectReward(i[s].effectConfig));return this._mergeRewards(n)},_parseEffectReward:function(e){return ed.readreward.splitRewards(e.EffectArg)},_mergeRewards:function(e){if(e.length<=0)return ed.readreward.createReward();for(var t=ed.readreward.mergerRewardFromCsv(e),i={assets:!0,equips:!0,heroes:!0,pets:!0,frames:!0,emblems:!0},n=0;n<e.length;n++){var s=e[n];for(var a in s)if(!i[a]&&s[a]instanceof Array){t[a]=t[a]||[];for(var o=0;o<s[a].length;o++)t[a].push(ed.copyObj(s[a][o]))}}return t.assets=ed.readreward.mergeAsset(t.assets||[]),t},_formatEffectRichTexts:function(e){var t=e.EffectTips,i=e.TipRule;return i===ed.GuildTurntableTechTipRule.PARAM?[t.format(e.TipParam)]:i===ed.GuildTurntableTechTipRule.ARG?[t.format(this._formatNumberArray(e.EffectArg2,e.EffectArgType))]:i===ed.GuildTurntableTechTipRule.ASR?this._formatAsrRichTexts(e,e.EffectArg):i===ed.GuildTurntableTechTipRule.CFG?this._isGuildAttrEffect(e)?this._formatGuildAttrRichTexts(e):(cc.error("GuildTurntable unsupported Cfg effect",e.ID,e.EffectModule,e.EffectArgType),[]):[t]},_isGuildAttrEffect:function(e){return e.EffectModule===ed.GuildTurntableTechEffectModule.GUILD_ATTR&&e.EffectArgType===ed.GuildTurntableTechEffectArgType.ADD_ATTR},_getGuildSupportBonusDataListByEffect:function(e,t){for(var i=e.ID,n=e.EffectArg2,s=[],a=0;a<n.length;a++){var o=n[a],r=this.getSupportBonusConfig(o);if(r){var d={config:r,techLevel:t,effectId:i},c=ed.GuildTurntableTechSupportBonusData.create(d);c&&c.isValid()&&s.push(c)}else cc.error("GuildTurntable missing support bonus",t,i,a,o)}return s},_formatGuildAttrRichTexts:function(e){for(var t=this._getEffectUnlockLevelsMap()[e.ID]||[],i=this._getGuildSupportBonusDataListByEffect(e,t[0]||0),n=[],s=0;s<i.length;s++){var a=this._getSupportBonusDescriptionData(i[s]);a&&n.push(this._formatSupportBonusDescription(a.description,a.values))}return n},_getSupportBonusDescriptionData:function(e){var t=e.getConfig(),i=e.getDescription(),n=e.getTechLevel(),s=e.getEffectId(),a=e.getSupportBonusId(),o={},r=!0;return i.replace(/\{([^{}]+)\}/g,(function(e,i){return Object.prototype.hasOwnProperty.call(t,i)?(o[i]=t[i],e):(cc.error("GuildTurntable missing support bonus description column",n,s,a,i),r=!1,e)})),r?{description:i,values:o}:null},_formatSupportBonusDescription:function(e,t){return e.replace(/\{([^{}]+)\}/g,(function(e,i){return Object.prototype.hasOwnProperty.call(t,i)?t[i]:e}))},_formatNumberArray:function(e,t){for(var i=[],n=0;n<e.length;n++)i.push(this._formatEffectValue(e[n],t));return i},_formatAsrRichTexts:function(e,t){var i=[];if(t.length%3!=0)return cc.error("GuildTurntable invalid ASR args",e.ID,t),[e.EffectTips];for(var n=0;n<t.length;n+=3){var s=this._getEffectAssetName(t[n],t[n+1]),a=Number(t[n+2]);isNaN(a)?(cc.error("GuildTurntable invalid ASR value",e.ID,t[n+2]),i.push(e.EffectTips)):i.push(e.EffectTips.format([s,this._formatEffectValue(a,e.EffectArgType)]))}return i},_getEffectAssetName:function(e,t){var i=e.toLowerCase(),n="";return"currency"===i?n=ed.lookupDataTable("Currency","DisplayName",t.toLowerCase()):"item"!==i&&"actitem"!==i||(n=ed.lookupDataTable("Item","Name",t)),n||t},_formatEffectValue:function(e,t){return t===ed.GuildTurntableTechEffectArgType.MUL?ed.language_mgr.formatPercent(e/100):ed.numberFormat(e)},_appendOverviewGroupRows:function(e,t){for(var i=e.entries,n=i[0].effectConfig,s=n.TipRule,a=1;a<i.length;a++)if(i[a].effectConfig.TipRule!==s)return cc.error("GuildTurntable overview TipRule mismatch",n.ID,i[a].effectConfig.ID),void this._appendRawOverviewRows(i,t);s===ed.GuildTurntableTechTipRule.CONST?this._appendRawOverviewRows(i,t):s===ed.GuildTurntableTechTipRule.ASR?this._appendAsrOverviewRows(i,t):s===ed.GuildTurntableTechTipRule.PARAM||s===ed.GuildTurntableTechTipRule.ARG?this._appendNumberOverviewRow(i,t,s):s===ed.GuildTurntableTechTipRule.CFG?this._appendCfgOverviewRow(i,t):this._appendRawOverviewRows(i,t)},_appendRawOverviewRows:function(e,t){for(var i=0;i<e.length;i++)t.push({techLevel:e[i].techLevel,effectIds:[e[i].effectConfig.ID],richText:this._formatEffectRichTexts(e[i].effectConfig).join("<changeLine>"),sortOrder:t.length})},_appendNumberOverviewRow:function(e,t,i){for(var n=[],s=[],a=e[0].techLevel,o=0;o<e.length;o++){for(var r=e[o].effectConfig,d=i===ed.GuildTurntableTechTipRule.PARAM?r.TipParam:r.EffectArg2,c=0;c<d.length;c++)n[c]=(n[c]||0)+d[c];s.push(r.ID)}var l=e[0].effectConfig.EffectArgType,h=i===ed.GuildTurntableTechTipRule.ARG?this._formatNumberArray(n,l):n;t.push({techLevel:a,effectIds:s,richText:e[0].effectConfig.EffectTips.format(h),sortOrder:t.length})},_appendAsrOverviewRows:function(e,t){for(var i={},n=[],s=0;s<e.length;s++){var a=e[s].effectConfig,o=a.EffectArg;if(o.length%3!=0)return cc.error("GuildTurntable overview invalid ASR args",a.ID,o),void this._appendRawOverviewRows(e,t);for(var r=0;r<o.length;r+=3){var d=Number(o[r+2]);if(isNaN(d))return cc.error("GuildTurntable overview invalid ASR value",a.ID,o[r+2]),void this._appendRawOverviewRows(e,t);var c=o[r].toLowerCase(),l=o[r+1],h=c+"|"+l;i[h]||(i[h]={assetType:c,assetId:l,value:0,techLevel:e[s].techLevel,effectIds:[]},n.push(i[h]));var u=i[h];u.value+=d;var _=a.ID;u.effectIds.indexOf(_)<0&&u.effectIds.push(_)}}for(var g=0;g<n.length;g++){var p=n[g],f=this._getEffectAssetName(p.assetType,p.assetId),m=this._formatEffectValue(p.value,e[0].effectConfig.EffectArgType);t.push({techLevel:p.techLevel,effectIds:p.effectIds,richText:e[0].effectConfig.EffectTips.format([f,m]),sortOrder:t.length})}},_appendCfgOverviewRow:function(e,t){for(var i={},n=[],s=0;s<e.length;s++){var a=e[s].descriptionData.values;for(var o in a)i[o]=parseFloat(((i[o]||0)+a[o]).toFixed(4));n.push(e[s].effectConfig.ID)}t.push({techLevel:e[0].techLevel,effectIds:n,richText:this._formatSupportBonusDescription(e[0].descriptionData.description,i),sortOrder:t.length})}});}
function __nativeFactory86(){return (cc.Class.extend({ctor:function(e){e&&(this.isPet=!0,this.id=e.id,this.tid=e.tid,this.level=e.level,this.pentagram_lv=e.level,this.rank=1,this.quality=0,this.gs=0,this.talentArr=[],this.initTableData(),this.updateServerData(e))},initTableData:function(){this.unitCsv=ed.getDataTable("Unit")[this.tid],this.petCsv=ed.getDataTable("Pet")[this.tid],this.unitCsv&&(this.rank=this.unitCsv.InitialRank)},updateServerData:function(e){if(e){for(var t in this.serverData||(this.serverData={}),e)this.serverData[t]=e[t];this.quality=e.quality||0,this.gs=e.gs||0,this.updateSkill(),e.talentArr?this.talentArr=e.talentArr:this.updateTalent(e.talents||[])}},updateSkill:function(){this.skillIdArr=[],this.unlockSkillIdMap={};var e=ed.getDataTable("Skill")[this.tid];for(var t in e){var i=Number(t),n=e[i],a=n.UnlockQuality,s=n.Slot;if(this.quality>=a)if(this.skillIdArr[s-1]){var o=e[this.skillIdArr[s-1]].SkillLevel;n.SkillLevel>o&&(this.skillIdArr[s-1]=i,this.unlockSkillIdMap[s]=i)}else this.skillIdArr[s-1]=i,this.unlockSkillIdMap[s]=i;else 1===n.SkillLevel&&(this.skillIdArr[s-1]=i)}},updateTalent:function(e){this.talentArr=[];for(var t=0;t<e.length;t++){var i=e[t],n=ed.PetTalent.create(i.tid,i.quality);this.talentArr.push(n)}},getTalentArr:function(){return this.talentArr},getTalentCountByQuality:function(){if(this.isSpPet()){var e=1e3*this.tid+ed.PetQualityType.SP_MAX,t=ed.getDataTable("PetCustom")[e];if(t)return t.Talents.length/2}return this.quality<=ed.PetQualityType.PURPLE?0:this.quality===ed.PetQualityType.GOLDEN?2:this.quality===ed.PetQualityType.RED?3:this.quality===ed.PetQualityType.WHITE?8:0},getTalentByTid:function(e){for(var t=0;t<this.talentArr.length;t++)if(e===this.talentArr[t].tid)return this.talentArr[t]},getName:function(){return this.unitCsv?this.unitCsv.DisplayName:6===this.quality?T("PetData_0_813_0","精英兽灵"):4===this.quality?T("PetData_2_369_0","稀有兽灵"):2===this.quality?T("PetData_3_592_0","普通兽灵"):10===this.quality?T("PetData_4_839_0","神话兽灵"):void 0},getJob:function(){return this.unitCsv.HeroJob},getSkillArr:function(){return this.skillIdArr},getUnlockSkillMap:function(){return this.unlockSkillIdMap},isSkillUnlock:function(e){var t=ed.getDataTable("Skill")[this.tid][e].UnlockQuality;return this.quality>=t},getTagID:function(){return this.unitCsv.HeroTagID},getTag:function(){return this.unitCsv.HeroTag},getPetGs:function(){return this.gs||(this.gs=ed.PetAttrDelegate.calculateGs(this,!0)),this.gs},getNextQuality:function(){return this.isSpEovConfig()?this.getSpPetQualityData().TargetQuality:ed.PetNextQualityType[this.quality]},checkQualityCanEvolve:function(){return this.quality<=ed.PetQualityType.RED||this.isSpEovConfig()},isSpPet:function(){return"SP"===this.petCsv.Type},isOneKeyEvolve:function(){return!this.isSpPet()||this.quality<8},isSpEovConfig:function(){var e=ed.getDataTable("PetQualityLevel")[this.quality];return this.petCsv&&"SP"===this.petCsv.Type&&e},getSpecialAction:function(){return this.petCsv.SpecialAction},getEvoConSumpCount:function(){var e=0;if(this.isSpEovConfig()){e=this.getSpPetQualityData().SelfCostNum+1}else{var t=ed.getDataTable("PetQualityUpCost")[this.quality],i=this.isSpPet()?"SP":"normal";for(var n in t){e=t[n][i].PetNum-1;break}}return e},checkHaveEnoughDogMaterial:function(){if(this.isSpEovConfig()){var e=this.getSpPetQualityData(),t=ed.PetManager.getInstance();if(t.petDogTidQualityMap&&t.petDogTidQualityMap[this.tid][e.SelfCostQuality]>=e.SelfCostNum){var i=t.petDogQualityTidap[e.NormalCostQuality],n=0;for(var a in i){parseInt(a)!==this.tid&&(n+=i[a])}if(n>=e.NormalCostNum)return!0}}return!1},getDogMaterialPetData:function(e){var t=this.getSpPetQualityData();if(this.isSpEovConfig()&&e>=this.getSpPetQualityData().SelfCostNum+1){var i={id:-1,tid:!1,level:0,quality:parseInt(t.NormalCostQuality),pentagram_lv:0};return ed.PetData.create(i)}var n=cc.clone(this);return t&&t.SelfCostQuality&&(n.quality=parseInt(t.SelfCostQuality)),n},getEvoMaterialPets:function(e){var t=this,i=ed.PetManager.getInstance().getAllPets();return this.isSpEovConfig()&&e===this.getSpPetQualityData().SelfCostNum+1?i.filter((function(i){return i.quality===t.getDogMaterialPetData(e).quality&&i.tid!==t.tid})):i.filter((function(i){return i.tid===t.tid&&i.quality===t.getDogMaterialPetData(e).quality}))},getSpPetQualityData:function(){var e={},t=ed.getDataTable("PetQualityLevel")[this.quality];t&&((e=t[Object.keys(t)[0]]).NormalCostQuality=parseInt(e.NormalCostQuality),e.SelfCostQuality=parseInt(e.SelfCostQuality));return e},getTalentValue:function(e){var t=e.getTalentId(),i=e.getQuality(),n=ed.getDataTable("PetTalentLib")[t][i||1],a=ed.getDataTable("PetTalentCatg")[n.AttrID],s=n[a.AttrName];return-1!==a.AttrName.indexOf(".PR")&&(s+="%"),s},checkNextNewTalents:function(){return this.isSpPet()?this.getNextUnlockTalents().length:this.quality!==ed.PetQualityType.PURPLE},getNextUnlockTalents:function(){var e=[];if(this.isSpPet){for(var t=1e3*this.tid+this.quality,i=t+1,n=ed.getDataTable("PetCustom")[t],a=ed.getDataTable("PetCustom")[i];!a&&i-t<15;)i++,a=ed.getDataTable("PetCustom")[i];if(a)for(var s in a.Talents)if(s%2==0&&!n.Talents[s]){var o=parseInt(s),r=ed.PetTalent.create(a.Talents[o],a.Talents[o+1]);e.push(r)}}return e},getMixTalentCount:function(){if(this.isSpEovConfig()){var e=1e3*this.tid+this.quality;return ed.getDataTable("PetCustom")[e].Talents.length/2}var t=this.petCsv.InitTalentPool;return ed.getDataTable("PetTalentPool")[t][this.quality].MixTalentCountMin},checkCanUpGrade:function(){for(var e=this.getTalentArr(),t=0;t<e.length;t++){var i=e[t].quality,n=ed.getDataTable("PetTalentUpgrade")[t+1];if(n){var a=n[i],s=this.getConfigCostArr(a);if(s)for(var o=1;o<3;o++){var r=s[o-1];if(ed.player.getItemOrCurrency(r.type,r.id)>=r.amount)return!0}}}return!1},getConfigCostArr:function(e){if(e){var t=e.Cost,i=e.Cost2;return[{id:t[1],amount:parseInt(t[2]),type:t[0]},{id:i[1],amount:parseInt(i[2]),type:i[0]},{id:t[4],amount:parseInt(t[5]),type:t[3]}]}},clone:function(){return cc.clone(this)}}));}
function __nativeFactory87(){return (cc.Class.extend({_className:"PetTalent",ctor:function(e,t){this.talentId=e,this.quality=t},getTalentId:function(){return this.talentId},getQuality:function(){return this.quality},getTalentTag:function(){return this.getTalentCfg().TalentTag},getTalentCfg:function(){return ed.getDataTable("PetTalentLib")[this.talentId][this.quality]}}));}
function __nativeFactory88(){return (function(e,t){return new ed.PetTalent(e,t)});}
function __nativeFactory89(){return ({practice:"act_pumpkin_brawl_stage_training",challenge:"act_pumpkin_brawl_stage"});}
function __nativeFactory90(){return ({cur_mode:"act_pumpkin_brawl_stage_training",all_heroes:{},all_hero_list:[],refreshAllHeroes:function(e){this.all_heroes={},this.all_hero_list=[];for(var t=ed.halloweenFunMgr.getStageConfig(e),i=ed.halloweenFunMgr.getStageHeroList(e),n=0;n<i.length;n++){var a=i[n];if(a>0){var s,o=t.Level,r=t.HeroQuality,d=ed.getDataTable("UnitLevel")[o].Rank;ed.lookupDataTable("Unit","InitialQuality",a)>=4&&t.SigLv>0&&(s={isValid:!0,lv:t.SigLv});var c={id:a,tid:a,level:o,quality:r,rank:d,sig:s},l=ed.heroData.create(c);l.equips=ed.getLineupHeroEquips(a,t.EquipQuality,t.EquipEnhanceLevel),l.gs=ed.hero.caculateGs(l),this.all_heroes[a]=l,this.all_hero_list.push(l)}}},getHero:function(e){return this.all_heroes[e]},getAllHeroes:function(){return this.all_hero_list},setCurMode:function(e){this.cur_mode=e},getCurMode:function(){return this.cur_mode},enterPrepare:function(e,t,i){this.setCurMode(e),this.refreshAllHeroes(t);var n=ed.halloweenFunMgr.getStageBattleId(t),a=ed.getBattleHeroes(n),s=this,o={self_lineup:ed.lineup.getLineupByType(e,t),self_pet_ids:[],oppo_heroes:a,battleID:n,type:e,mode:e,teamMax:ed.halloweenFunMgr.getStageChooseNum(t),stageId:t,enterCallback:i,handle_level:!0,callback:function(i){s.startBattle(i,e,t)}};ed.openHalloweenFunBattlePrepare(o)},startBattle:function(e,t,i){var n=e.lineup,a=this;ed.lineup.setLineupByType(this.cur_mode,n,i);var s={lineup:n,stage_tid:i,callback:function(e){a.doStartBattle(e,i)}};ed.halloweenFunNetMgr.reqStartBattle(s)},testStartBattle:function(e,t,i){var n=this,a={battle:{type:t,common:{rand_seed:parseInt(501*Math.random()+500,10),param:i},input:{self_teams:[{slot_heroes:this.getSlotHeroesByLineUp(e.lineup)}]}},callback:function(e){n.doEndBattle(e)}};ed.startOneBattle(a)},getSlotHeroesByLineUp:function(e){for(var t=e.hids,i=[],n=0;n<t.length;n++){var a=t[n],s=a.slot,o=a.hero_id,r=this.getHero(o)._data;r.config={slotIndex:s},i.push({hero:r,slot:s})}return i},doStartBattle:function(e,t){var i=e.battle,n=this,a={battle:i,callback:function(e){ed.halloweenFunNetMgr.reqEndBattle(e,t,(function(e){n.doEndBattle(e)}))}};ed.startOneBattle(a)},doEndBattle:function(e){var t={mode:this.cur_mode,result:e.result,extra:{stage:e.stage,params:e.params}};ed.finishOneBattle(t)},isHalloweenFunMode:function(e){return e===ed.halloweenFunModeEnum.practice||e===ed.halloweenFunModeEnum.challenge},resetSpecialTimeLimit:function(){for(var e=-1,t=ed.battleEngine.config&&ed.battleEngine.config.param,i=ed.halloweenFunMgr.getStageConfig(t).TaskIDs||[],n=0;n<i.length;n++){var a=i[n],s=ed.getDataTable("ActPumpkinBrawlBattleTask")[a];s&&s.TaskParam1>0&&(e<0||s.TaskParam1+.5>e)&&(e=s.TaskParam1+.5)}ed.battleEngine.special_time_limit=e>0?e:90},checkBattleEnd:function(){var e=ed.battleEngine.config.mode,t=this.getTaskIds(),i=ed.battleEngine.getHalloweenFunCompletedTaskIds(),n=ed.battleEngine.config&&ed.battleEngine.config.param,a=ed.halloweenFunMgr.isStageStarReverse(n);if(ed.battleEngine.ticks>1){if(a){if(i.length<=0)return void ed.battleEngine.onBattleEnd("defeat")}else if(i.length>=t.length)return void ed.battleEngine.onBattleEnd("victory");e===ed.halloweenFunModeEnum.practice?(ed.battleEngine.time_limit+ed.battleEngine.time_skill_add<=0||ed.battleEngine.getHalloweenFunEndFlag())&&(i.length>0?ed.battleEngine.onBattleEnd("victory"):ed.battleEngine.onBattleEnd("defeat")):(ed.battleEngine.special_time_limit<=0||ed.battleEngine.getHalloweenFunEndFlag())&&(i.length>0?ed.battleEngine.onBattleEnd("victory"):ed.battleEngine.onBattleEnd("defeat"))}},getTaskIds:function(){var e=ed.battleEngine.config&&ed.battleEngine.config.param;return ed.halloweenFunMgr.getStageTaskIds(e)},getStarNum:function(){return ed.battleEngine.getHalloweenFunCompletedTaskIds().length}});}
function __nativeFactory91(){return ({all_heroes:{},initBalanceHeroes:function(){this.all_heroes={};for(var e=ed.playerhero.getAllHeros(),t=0;t<e.length;t++){var i=ed.heroData.cloneFormObj(e[t]);i.__originQuality=i.quality,this.all_heroes[i.id]=i}},refreshBalanceHeroes:function(){for(var e in this.all_heroes){var t=this.all_heroes[e],i=t.id,a=this.getHeroLevelByHeroId(i),n=this.getHeroQualityByHeroId(t);t.level=a,t.quality=n,t.pentagram_lv=a,t.rank=ed.getDataTable("UnitLevel")[a].Rank;var r={astrolabe:{lv:ed.AstrolabeManager.getTreeLevel(),tag_lvs:ed.AstrolabeManager.getAllTagsLevel()}};t.gs=ed.hero.caculateGs(t,r,!0)}},getFreeTeamMaxLevel:function(){var e=ed.warMapData.getTeamMap(),t=ed.getDataTable("WarMapParam").BaseWarLv.Value,i=t;for(var a in e){var n=parseInt(a);if(!ed.warMapData.isPurchasedTroop(n)){var r="Troop_"+n+"_AddLv",s=t+ed.WarTechManager.getInstance().getTechEffectValueByType(r);s>i&&(i=s)}}return i},getHeroLevelByHeroId:function(e){var t,i=ed.getDataTable("WarMapParam").BaseWarLv.Value,a=0,n=ed.warMapData.getTeamMap();for(var r in n){t=parseInt(r);for(var s=n[r],o=s._lineup&&s._lineup.hids?s._lineup.hids:[],l=!1,d=0;d<o.length;d++)if(e===o[d].hero_id){l=!0;break}if(l){if(ed.warMapData.isPurchasedTroop(t))return this.getFreeTeamMaxLevel();var c="Troop_"+t+"_AddLv";a=ed.WarTechManager.getInstance().getTechEffectValueByType(c);break}}return i+a},getHeroQualityByHeroId:function(e){var t=ed.WarChargeManger.getInstance().getPaidTeamQuality(),i=ed.warMapData.getTeamMap();for(var a in i)for(var n=parseInt(a),r=i[a],s=r._lineup&&r._lineup.hids?r._lineup.hids:[],o=0;o<s.length;o++){if(e.id===s[o].hero_id)if(ed.warMapData.isPurchasedTroop(n))return this.getRaceRoundQuality(e,t)}return e.__originQuality||e.quality},getRaceRoundQuality:function(e,t){return ed.WarSeasonHeroModel.isSeasonHeroFuncCtrlOpen()&&ed.WarSeasonHeroModel.isSeasonHero(e.tid)?e.quality:Math.max(e.quality,t)},getHero:function(e){return this.all_heroes[e]},getAllHeroes:function(){var e=[];for(var t in this.all_heroes)e.push(this.all_heroes[t]);return e},getAllCloneHeroes:function(){var e=[];for(var t in this.all_heroes){var i=ed.heroData.cloneFormObj(this.all_heroes[t]);e.push(i)}return e},getIsWarBattleMode:function(e){return"besiege_pvp"===e||"war_map_farmland"===e||"war_map"===e||"war_arms_pvp"===e||"war_vanguard_pvp"===e||"war_duel_pvp"===e||"war_dungeon"===e}});}
function __nativeFactory92(){return (window.ed||{});}
function __nativeFactory93(){return (window.ed||{});}
function __nativeFactory94(){return (window.ed||{});}
function __nativeFactory95(){return (window.ed);}
function __nativeFactory96(){return (window.ed);}
function __nativeFactory97(){return (window.ed||{});}
function __nativeFactory98(){return (window.ed||{});}
function __nativeFactory99(){return (window.ed||{});}
function __nativeFactory100(){return (window.ed||{});}
function __nativeFactory101(){return (window.ed||{});}
function __nativeFactory102(){return (window.ed||{});}
function __nativeFactory103(){return (window.ed||{});}
function __nativeFactory104(){return (window.ed||{});}
function __nativeFactory105(){return (window.ed||{});}
function __nativeFactory106(){return (window.ed||{});}
function __nativeFactory107(){return (window.ed||{});}
function __nativeFactory108(){return (window.ed||{});}
function __nativeFactory109(){return (window.ed||{});}
function __nativeFactory110(){return (window.ed||{});}
function __nativeFactory111(){return (window.ed||{});}
function __nativeFactory112(){return (window.ed||{});}
function __nativeFactory113(){return (window.ed);}
function __nativeFactory114(){return (window.ed);}
function __nativeFactory115(){return (window.ed);}
function __nativeFactory116(){return (window.ed);}
function __nativeFactory117(){return (window.ed||{});}
function __nativeFactory118(){return (window.ed||{});}
function __nativeFactory119(){return (ed||{});}
function __nativeFactory120(){return (window.ed||{});}
function __nativeFactory121(){return (window.ed||{});}
function __nativeFactory122(){return (ed||{});}
function __nativeFactory123(){return ([]);}
function __nativeFactory124(){return (Object.create(Array.prototype));}
function __nativeFactory125(){return (["push","pop","shift","unshift","splice"]);}
var __nativeDefinitions,__nativeGlobals;
var __nativeDefinitionNames;
var __nativeGlobalNames;
var __nativeLoaded,__nativeActive;
function __nativeExpose(owner,prefix){
    var keys=Object.create(null);
    for(var i=0;i<__nativeDefinitionNames.length;i++){var full=__nativeDefinitionNames[i];if(full.indexOf(prefix+'.')===0)keys[full.slice(prefix.length+1).split('.')[0]]=true;}
    Object.keys(keys).forEach(function(key){var name=prefix+'.'+key;
      if(key in owner){var descriptor=Object.getOwnPropertyDescriptor(owner,key);if(descriptor&&'value'in descriptor&&descriptor.value&&(typeof descriptor.value==='object'||typeof descriptor.value==='function'))__nativeExpose(descriptor.value,name);return;}
      Object.defineProperty(owner,key,{configurable:true,enumerable:true,get:function(){
        if(__nativeActive[name])throw new Error('Source dependency cycle at '+name);
        var factories=__nativeDefinitions[name];if(!factories)throw new Error('Unsupported scoped source definition: '+name);
        __nativeActive[name]=true;var value;
        try{for(var j=0;j<factories.length;j++){Object.defineProperty(owner,key,{configurable:true,enumerable:true,writable:true,value:value});value=factories[j].call(__nativeGlobal);}
          Object.defineProperty(owner,key,{configurable:true,enumerable:true,writable:true,value:value});
          if(value&&(typeof value==='object'||typeof value==='function'))__nativeExpose(value,name);__nativeLoaded.push(name);return value;
        }finally{delete __nativeActive[name];}
      },set:function(value){Object.defineProperty(owner,key,{configurable:true,enumerable:true,writable:true,value:value});}});
    });
  }
function __nativeDecodeUTF8(bytes){
    var parts=[],units=[],i=0;
    while(i<bytes.length){var a=bytes[i++],code;
      if(a<128)code=a;
      else if(a>=194&&a<224){if(i>=bytes.length)throw new Error('Truncated UTF8');code=((a&31)<<6)|(bytes[i++]&63);}
      else if(a<240){if(i+1>=bytes.length)throw new Error('Truncated UTF8');code=((a&15)<<12)|((bytes[i++]&63)<<6)|(bytes[i++]&63);}
      else{if(i+2>=bytes.length)throw new Error('Truncated UTF8');code=((a&7)<<18)|((bytes[i++]&63)<<12)|((bytes[i++]&63)<<6)|(bytes[i++]&63);code-=65536;units.push(55296+(code>>10));code=56320+(code&1023);}
      units.push(code);if(units.length>=4096){parts.push(String.fromCharCode.apply(null,units));units=[];}
    }
    if(units.length)parts.push(String.fromCharCode.apply(null,units));return parts.join('');
  }
var __nativeTablePath;
var __nativeTableText;
var __nativeTableBoundary;
var __nativeWrappedTables;
var __nativeTables;
var i;
var name;
var GuildBoss;
var CommonWorldBoss;
var CommonSlgBoss;
var CommonGVEBoss;
var CurseLandBoss;
var ActDetectiveBoss;
var CommonRaceDreamBoss;
var CommonSingleDreamBoss;
var CommonSideBoss;
var CommonTeamChampionShipDreamBoss;
var CommonTeamChampionEndlessBoss;
var CommonGuildIceBreakBoss;
var CommonWarDungeonBoss;
var Bard;
var Priest;
var General;
var CW;
var DR;
var Yeanling;
var OakSage;
var LC;
var FieldMaze;
var FieldMaze2;
var FieldTutorial;
var FieldTutorialV2;
var FieldRichMan;
var FieldLegend;
var FieldIdle;
var FieldTest;
var FieldTrial;
var FieldCurseLand;
var FieldActDetective;
var FieldIdlePvp;
var FieldCampPvp;
var FieldSideStory;
var FieldCurseLandIdle;
var FieldRaceDreamIdle;
var FieldRaceDream;
var FieldSingleDream;
var FieldDeepStage;
var FieldDnf;
var FieldBattleGround;
var FieldGuildBoss;
var FieldGuildVehicleBoss;
var FieldTeamChampionDream;
var FieldTeamChampionEndless;
var FieldGuildIceBreak;
var FieldWar;
var FieldPumpkinFun;
var FieldPumpkinBoss;
var AccelerateField;
var NEC;
var POM;
var Musketeer;
var Tiny;
var BossDragonKnight;
var DevilWizard;
var UndeadTank;
var Goblin;
var SoulCalibur;
var BaseField;
var DevilImp;
var ElfLancer;
var OrcBatmaster;
var OrcJackalTank;
var LionJugg;
var Spider;
var Lina;
var UDTank;
var CatAssassin;
var SilverAssassin;
var HumanPriest;
var Treant;
var UDSword;
var HumanTrident;
var Huskar;
var nFlood;
var DK;
var Troll;
var nDP;
var Puck;
var SNK;
var Wizard;
var nBH;
var Mouse;
var WD;
var DevilHunter;
var Mag;
var HammerDemon;
var BowDemon;
var Catapult;
var DarkYeanling;
var BossOakSage;
var BoneArcher;
var TD;
var Bear;
var OK;
var SwordMaster;
var TH;
var GhostSaber;
var GodA;
var Bane;
var Pudge;
var NOD;
var ElfSaber;
var DwarfE;
var DwarfS;
var GK;
var Revenger;
var Turtle;
var LUST;
var Valkyrie;
var Merchant;
var TwinsR;
var TwinsB;
var Maid;
var Longbow;
var FoxMagician;
var BunnyMaster;
var DT;
var TimeG;
var Wino;
var NunAssassin;
var Mystic;
var NT;
var SciMonster;
var Arthur;
var Phoenix;
var Lizard;
var Wolf;
var Wildkin;
var MK;
var Fat;
var UKYO;
var BossDQ;
var WBossDarkYeanling;
var WBossDQ;
var WBossDK;
var WBossYM;
var WBossOakSage;
var IceD;
var BossYM;
var BossCthulhu;
var BossDM;
var HouseKeeper;
var UDD;
var Bones;
var OrcLeader;
var Nakoruru;
var Spring;
var BossMystic;
var WBossMystic;
var DKid;
var Phantom;
var OA;
var Ezio;
var SSR;
var THW;
var POP;
var Thor;
var Yalbed;
var Anz;
var GD;
var QN;
var JK;
var WinterL;
var TechMouse;
var WindMan;
var Clergy;
var TricRacoon;
var Princess;
var AstroM;
var Siren;
var Gunner;
var GentryD;
var Merlin;
var CrazyFox;
var Golem;
var Captain;
var DevilMage;
var LazyD;
var Stone;
var LDV;
var BDruid;
var Artisan;
var CKnight;
var SnakeMan;
var SPhoenix;
var FP;
var FlameE;
var BM;
var Babayaga;
var Gaoler;
var SBane;
var AstroR;
var Scout;
var DruidMaster;
var WindSM;
var Hidan;
var Sonia;
var OrcMaster;
var Karen;
var SLK;
var JOA;
var Alen;
var Patronus;
var WNT;
var Yeti;
var SwordL;
var ShieldL;
var Efreet;
var GLion;
var PLion;
var PDeer;
var TimeOwl;
var Auspi;
var BFY;
var Sala;
var Otter;
var ScarletFox;
var DSpider;
var GreenBall;
var WhiteBall;
var BlackBall;
var AccelerateBossCthulhu;
var BossXmas_nDP;
var BossXmas_DKid;
var BossXmas_NEC;
var BossBane;
var MBossBane;
var MBossWorm;
var MBossDragonB;
var MBossCrab;
var Priest_Texas;
var GOR;
var YNF;
var Chimera;
var Flora;
var SBD;
var CurseCarrier;
var Bishop;
var HML;
var HFP;
var DOA;
var TSL;
var Adwin;
var BSparrow;
var Slacker;
var EMT;
var RM;
var HammerMan;
var DivineBlade;
var Liberta;
var Lucilla;
var Summer;
var SO;
var SQ;
var SWQ;
var BC;
var AstroPOM;
var Admiral;
var Calypso;
var Robin;
var OK_Texas;
var LC_Texas;
var Longbow_Texas;
var Turtle_Texas;
var Yeanling_Texas;
var BunnyMaster_Texas;
var POM_Texas;
var NOD_Texas;
var Bear_Texas;
var WD_Texas;
var OA_Texas;
var BoneArcher_Texas;
var nDP_Texas;
var Pudge_Texas;
var Bones_Texas;
var UDD_Texas;
var TD_Texas;
var Maid_Texas;
var OrcLeader_Texas;
var SNK_Texas;
var GK_Texas;
var General_Texas;
var NunAssassin_Texas;
var Lina_Texas;
var nBH_Texas;
var LionJugg_Texas;
var Huskar_Texas;
var TH_Texas;
var Lizard_Texas;
var Troll_Texas;
var Spider_Texas;
var Wildkin_Texas;
var ElfSaber_Texas;
var Puck_Texas;
var NEC_Texas;
var Mystic_Texas;
var NT_Texas;
var SciMonster_Texas;
var Revenger_Texas;
var BossHGMN;
var BossHGM;
var GVE_BOSS_HMN;
var GVE_BOSS_HM;
var BossBA;
var BossROG;
var BossPreyS;
var BossPreyB;
var BossWorm;
var GoblinFeast;
var Mars;
var BloodS;
var Gtornado;
var Treant_Card;
var DevilImp_Card;
var DevilWizard_Card;
var OrcBatmaster_Card;
var OrcJackalTank_Card;
var UDSword_Card;
var HammerDemon_Card;
var UDTank_Card;
var Bane_Card;
var Fat_Card;
var BassD_Card;
var FP_Card;
var DT_Card;
var GentryD_Card;
var IceD_Card;
var Huskar_Card;
var HumanPriest_Card;
var newSpider_Card;
var ElfLancer_Card;
var nFlood_Card;
var newCW_Card;
var newNEC_Card;
var BassD;
var WinterGoblin;
var ActDetectiveSwordMaster;
var ActDetectiveGK;
var ActDetectiveUhlan;
var ActDetectiveGunner;
var BossDragonS;
var BossDragonB;
var BossLionAct;
var WBossLionAct;
var BossSBDAct;
var SpBossBoss;
var HeirloomBoss;
var SummerCaptain;
var SummerBones;
var SummerPudge;
var SummerSiren;
var ActNewYearBoss;
var BossFireWorks;
var BossMStoneLion;
var BossFStoneLion;
var DarkCrow;
var RogTD;
var RogWizard;
var RogWino;
var RogNOD;
var BossCrab;
var RBossDarkYeanling;
var RBossDQ;
var RBossDK;
var RBossYM;
var RBossMystic;
var RBossLionAct;
var RBossMD;
var RBossIronMaiden;
var BossBride;
var BossNightmare;
var BossDevilDog;
var RBossDoll;
var BossMirror;
var BossCannon;
var RBossOakSage;
var AvengerSBane;
var ActContraBossSBane;
var FieldCosplay;
var SLGPhantom;
var SLGFP;
var SLGBM;
var SLGChimera;
var SLGOrcMaster;
var SLGRinger;
var SLGIceD;
var MBossYM;
var MBossOakSage;
var SLGThor;
var SLGWindMan;
var SLGWildkin;
var ActCookSnakeMan;
var ActCookCKnight;
var ActCookSonia;
var ActCookFat;
var ActCookBoss;
var BossMoonkin;
var SLGBossDevilDog;
var BossSC;
var BossSC_shadow;
var ActClashCommonMonster;
var ActClashCommonBoss;
var ActClashSO;
var ActClashCurseCarrier;
var ActClashBossNightmare;
var FieldActClash;
var FieldActPumpkin;
var PumpkinBrawlCommonBoss;
var Vegelf;
var Ringer;
var HumanOwl;
var HumanBall;
var ElfBall;
var OrcBall;
var UndeadBall;
var UndeadPLion;
var ElfDeer;
var GDJellyfish;
var OrcSwordL;
var OrcEfreet;
var UndeadSpider;
var ElfIbis;
var HyperCutyDragon;
var Grimhoof;
var CarrotRabbit;
var LadyDracula;
var AxeBoar;
var BaldAxe;
var Crossbow;
var MagicMouse;
var CloakFrog;
var GreenEye;
var Moth;
var ClawWolf;
var Daughter;
var Marcille;
var Laios;
var Laios_Treant;
var Laios_DevilImp;
var Laios_Slime;
var ActMira2024Boss;
var ActMira2024NunAssassin;
var ActMira2024DevilMage;
var ActMira2024Clergy;
var ActCelebrateBoss;
var Lighthunter;
var Darklord;
var PumpkinA;
var PumpkinB;
var Athena;
var Selene;
var Opman;
var ActSummer2025Boss;
var ActSummer2025Wolf;
var ActSummer2025OK;
var ActSummer2025BM;
var ActSummer2025Valkyrie;
var ActSummer2026Boss;
var ActSummer2026LUST;
var ActSummer2026nBH;
var ActSummer2026BM;
var ActSummer2026Valkyrie;
var LunarAries;
var Puppeteer;
var OrcAngler;
var Medusa;
var ActCrossStoryDQ;
var ActCrossStoryMystic;
var ActCrossStoryNightmare;
var ActCrossStoryYM;
var TBEQ_Treant;
var TBEQ_DevilImp;
var TBEQ_DevilWizard;
var TBEQ_OrcBatmaster;
var TBEQ_OrcJackalTank;
var TBEQ_UDSword;
var TBEQ_UDTank;
var TBEQ_HammerDemon;
var TB_Heirloom_attrA;
var TB_Heirloom_attrB;
var TB_Heirloom_attrC;
var TB_Heirloom_Crit;
var TB_Heirloom_Dodge;
var TB_Heirloom_Heal;
var TB_Heirloom_invOnce;
var testArt;
var Torque1;
var Horn1;
var Gems1;
var Mantle;
var DivineSword;
var Grail;
var FocusRing;
var Warrior_Moon;
var Warrior_Fever;
var Warrior_Grand_Moon;
var Warrior_BloodForBlood;
var Tank_Stone;
var Tank_Guardian;
var test;
var Tank_Hammer;
var Ranger_TrueDmg;
var Ranger_HpShield;
var Ranger_Dagger;
var Mag_Energy;
var Mag_ExtraDmg;
var Mag_Trick;
var Support_MpShield;
var Support_WaterFlow;
var Support_MusicalNote;
var FieldAstro;
var soldier_lfs;
var soldier_shield;
var soldier_break;
var soldier_break_new;
var tank_aoe;
var tank_hpr;
var tank_heal;
var ranger_hast;
var ranger_slash;
var ranger_dodge;
var mage_mp;
var mage_power;
var mage_charge;
var sup_charge;
var sup_heal;
var sup_shield;
var GVEattackUp;
var GVEbasicAttackDmgUp;
var GVEbCritClimax;
var GVEcastUltDispel;
var GVEdeadUnitInherit;
var GVEdeathBomb;
var GVEDmgDown;
var GVEdmgSourceAtkDown;
var GVEenemyZoneDmgDown;
var GVEenterMutekiMp;
var GVEfirstLowLifeKnockBack;
var GvefullHpFirstLowLife;
var GVEgainCritCastUlt;
var GVEkillGainMspd;
var GVElowLifeHighAtkDodge;
var GVElowLifeHighHealratio;
var GVEmotionlessCastUlt;
var GVEmutekiBeforeDie;
var GVEregionAddAtkDodge;
var GVEShield;
var GVEsymmetricalDmg;
var GVEultDmgUp;
var GVEultMutekiFinishDmg;
var FieldSLG;
var debuff_exceptTag;
var mage_atkBurnTarget;
var mage_ChargeEnergyOnStart;
var mage_Tough;
var mage_absorb;
var mage_recall;
var ranger_atkDmgUp;
var ranger_atkSpeedUp;
var ranger_DmgUpByTime;
var soldier_DEFDownRegion;
var soldier_HighDamagedCoef;
var soldier_LFSWhenLowHP;
var sup_DmgDownFromBack;
var sup_Insight;
var sup_UpTeammateBuff;
var tank_CritDefence;
var tank_HealCoef;
var tank_ShieldOnStart;
var tank_battleStartRes;
var tank_immuField;
var tank_debuffToSource;
var SLGfieldBuff_basicAtkBoost;
var SLGfieldBuff_critBoost;
var SLGfieldBuff_mpBoost;
var SLGfieldBuff_newbieBoost;
var SLGfieldBuff_darkness;
var SLGfieldArtifact_swamp;
var SLGfieldArtifact_tjaele;
var SLGfieldArtifact_volcano;
var SLGfieldBuff_swamp;
var SLGfieldBuff_tjaele;
var SLGfieldBuff_volcano;
var SLGfieldBuff_lowOxygen;
var SLGfieldBuff_gorge;
var SLGfieldBuff_cold;
var SLGfieldBuff_bossNerf;
var SLGfieldBuff_BossSc;
var E_hpAndDefByHeirloom;
var fieldSkillTest;
var atkAndCrit;
var DefDown;
var FieldActClash_sideBuff;
var FieldActClash_miniDragon1;
var FieldActClash_miniDragon2;
var FieldActClash_bossDragon;
var BattleWinDebuff;
var EnemyMpMode;
var GodAndDemon;
var BattleEndMpLost;
var defAndHpr;
var atkAndLfs;
var IMU;
var CRIT;
var CRITRatio;
var LFS;
var DODG;
var battleEndHeal;
var OddExtraDamage;
var randomThunder;
var dyingProtect;
var BattleStartMpHpAccel;
var Explosion;
var ArrowRain;
var TagCounter;
var weakAtkUp;
var extraDamageByTargetHp;
var OrcAtkAndLfs;
var ElfCritAndSpd;
var HumanDefAndEnergy;
var UDHastAndMp;
var HealWhenKill;
var HastAndMspd;
var VictimHEAL;
var DelayHealWeakest;
var HPR;
var BattleStartShield;
var TagFormation;
var BattleStartSpider;
var dyingHeal;
var dyingSlash;
var BasicAtkExtraPoison;
var dyingRebound;
var PowerupUseUlt;
var PowerupTeammateDie;
var HitAndCrit;
var VictimEnergy;
var ForwardDefAndEnergy;
var GuardAtkAndCrit;
var BattleStartReduceHp;
var BattleStartDamageLink;
var AutoRecoverHp;
var AutoRecoverMp;
var BattleWinBuff;
var TagCounterRaid;
var atkAndDefByHeirloom;
var PowerupKill;
var MakeDamageReduceDef;
var MakeDamageReduceAtk;
var Pendulum;
var DeadPoisonBoom;
var EnengyUpWhenKill;
var RecoverMpFirstUlt;
var AddDmgByQuality;
var ReduceDmgByQuality;
var HardModeBuff;
var DebuffResist;
var BasicAtkRemoveBuff;
var ShieldEnemyUlt;
var BattleStartEnchanted;
var BackwardGuard;
var ChipCountBuff;
var BombUseNUlt;
var HitWhenStun;
var HealByTime;
var UseTearBuff;
var HastWhenNeat;
var LFSWhenRush;
var Infection;
var Stronger;
var AccelerateMagicDown;
var AcceleratePhysicsDown;
var AccelerateForbidUlt;
var AccelerateSkillDmgDown;
var SoldierFearEnemy;
var RangerCampDiffer;
var TankUltShield;
var MageMpUpDamage;
var SupportHealUp;
var GodThunder;
var GodUncontrollable;
var DevilOtherDeathRecover;
var DevilStealShield;
var HyperRaidRevenge;
var HyperRaidRaceTag;
var HyperRaidSPhoenix;
var ActDetectiveHuman;
var ActDetectiveUndead;
var ActDetectiveCombo;
var ActDetectiveUntargetable;
var ActDetectiveRes;
var ActDetectiveDisplace;
var ActDetectiveReflect;
var ActDetectiveMpCost;
var ActDetectiveCooldown;
var ActDetectiveLeftHalfCourt;
var ActDetectiveRightHalfCourt;
var ActDetectiveAttrStack;
var ActDetectiveBasicAttack;
var ActDetectiveCritHit;
var ActDetectiveDefUnderControl;
var ActDetectiveDefWeakest;
var ActDetectiveMpRatio;
var ActDetectiveMpr;
var ActDetectiveHeal;
var ActDetectiveShield;
var ActDetectiveFrontline;
var ActDetectiveBackline;
var SummerEncourageNoUlt;
var SummerCounterShield;
var SummerDifferSkillAtkUp;
var SummerLostHpDmgUp;
var SummerPeriodicCrit;
var SummerAttrStack;
var SummerRightHalfCourt;
var SummerLeftHalfCourt;
var SummerUltDmgUp;
var SummerCritHit;
var SummerMpRatio;
var SummerMpr;
var SummerLowHpIntensify;
var SummerShieldAtkUp;
var SummerBackward;
var SummerForward;
var ActCookTrueDamage;
var ActCookMeleeBonus;
var ActCookHealBonus;
var ActCookDefUnderControl;
var ActCookBasicAttackBonus;
var ActCookAllyDamageIncrease;
var FieldGuildBoss_uTagAllyMakeDmgUp;
var FieldGuildVehicleBoss_uTagAllyMakeDmgUp;
var FieldGuildVehicleBoss_VehicleLevelMakeDmgUp;
var FieldDeepStage_TEST;
var FieldBattleGround_dodgeUp;
var FieldBattleGround_boostSlot;
var FieldBattleGround_noMove;
var FieldBattleGround_banMPGain;
var FieldBattleGround_halfHP;
var FieldBattleGround_moreUnitTagFix;
var FieldBattleGround_selectedUnitAttrFix;
var FieldGuildIceBreak_AssistWeaken;
var ActMira2024DODG;
var ActMira2024NoUlt;
var ActMira2024Shield;
var ActMira2024MPGloves;
var ActMira2024BalanceTag;
var ActRaidCarePet2026Boss;
var ActGuildContraBoss;
var ActRaidCarePetDevilMage;
var ActRaidCarePetTH;
var ActRaidCarePetSiren;
var ActRaidCarePetThor;
var CandleDog;
var MonsterE;
var Kikoru;
var FieldCurseLand_atkNerf;
var FieldCurseLand_banAttribsApply;
var FieldCurseLand_controlledDmgUp;
var FieldCurseLand_dmgDownExceptUlt;
var FieldCurseLand_dodgeUp;
var FieldCurseLand_noUltCast;
var FieldCurseLand_nohealAndShieldBoost;
var FieldCurseLand_nearHit;
var FieldSingleDream_warPrivilegeDmgUp;
var IdlePvpAllDmgUpWhenStart;
var IdlePvpFrequencyBoost;
var IdlePvpRankAttrBoost;
var IdlePvpNerfMP;
var FieldCampPvp_adDown;
var FieldCampPvp_apDown;
var FieldCampPvp_campADown;
var FieldCampPvp_campAUp;
var FieldCampPvp_campBDown;
var FieldCampPvp_campBUp;
var FieldCampPvp_campCDown;
var FieldCampPvp_campCUp;
var FieldCampPvp_campDDown;
var FieldCampPvp_campDUp;
var FieldCampPvp_dmimuUp;
var FieldCampPvp_dpimuUp;
var FieldCampPvp_ilhUp;
var FieldCampPvp_lostAndSpecialDown;
var FieldCampPvp_ultForceCd;
var FieldCampPvp_humanMp;
var FieldCampPvp_orcLowHp;
var FieldCampPvp_elfHeal;
var FieldCampPvp_undeadBoom;
var FieldRaceDream_tagBoost;
var PumpkinFun_aoeClear;
var PumpkinFun_calmdown;
var PumpkinFun_combo;
var PumpkinFun_conquer;
var PumpkinFun_kick;
var PumpkinFun_protect;
var PumpkinFun_realorfake;
var PumpkinFun_stop;
var FieldPumpkinBoss_energy;
var FieldPumpkinBoss_vulnerable;
var FieldPumpkinBoss_lostHP;
var FieldDnf_AreaDamage;
var FieldDnf_BackStab;
var FieldDnf_CtrlShieldDown;
var FieldDnf_ElfGain;
var FieldDnf_ElfLoss;
var FieldDnf_FaceToFace;
var FieldDnf_InTheFace;
var FieldDnf_KeepDistance;
var FieldDnf_LeaveMeAlone;
var FieldDnf_PaperTiger;
var FieldDnf_RuneAtk;
var FieldDnf_RuneHast;
var FieldDnf_RuneHp;
var FieldDnf_RuneMpRatio;
var FieldDnf_ShieldUp;
var FieldDnf_WaterElf;
var ActDnfBossWorm;
var ActDnfCommonBoss;
var B_Hast;
var B_AllNoHeal;
var B_ATK;
var B_BackMoveToFront;
var B_BackwardGuard;
var B_BasicSkillStunWhenRush;
var B_battleEndHeal;
var B_BattleEndHpMpLost;
var B_BattleStartImmune;
var B_BattleStartMpHpAccel;
var B_BattleStartSleep;
var B_BoomEnemyDeath;
var B_Crit;
var B_CritD;
var B_CritP;
var B_debuff_Tag;
var B_Def;
var B_DmgDownAgi;
var B_DmgDownInt;
var B_DmgDownStr;
var B_DmgDownMelee;
var B_DmgDownRanged;
var B_DODG;
var B_dyingProtect_CD;
var B_dyingSlash;
var B_EnemyDealExtraDmgEachEnemyDie;
var B_EnemyTakeLessDmgEachEnemyDie;
var B_EnemyGrowUp;
var B_EnemyMpr;
var B_EnemyMpUp;
var B_Slow;
var B_EnemyTakeLessDmg;
var B_EnemyDealExtraDmg;
var B_EnemyDef;
var B_EnemyHpr;
var B_EnemyInsight;
var B_EnemyMpMode;
var B_HeartStopper;
var B_HostDown;
var B_HP;
var B_FearFront;
var B_FrontMoveToBackPeriodically;
var B_HurtCrit;
var B_HuskarLike_Atk;
var B_HuskarLike_Hast;
var B_HuskarLike_Uncontrollable;
var B_HuskarLike_Uncontrollable_InverseVersion;
var B_IMU;
var B_ImuCertainTimes;
var B_ImuHum;
var B_ImuOrc;
var B_ImuElf;
var B_ImuUd;
var B_LimitedUltTimes;
var B_LoseHpWhenStunned;
var B_LoseMpWhenStunned;
var B_LowestDmgSlayed;
var B_MoveSpeedDecrease;
var B_MoveOrCurse;
var B_UnhealFog;
var B_PlayerUltTakeDmg;
var B_EnemyDeathFear;
var B_AliveMoreDmgMore;
var B_EnemyShield;
var B_PlayerDealLessDmg;
var B_PlayerTakeMoreDmg;
var B_PoisonSpray;
var B_PowerDownTeammateDie;
var B_PowerUpDevilAfterTime;
var B_PowerUpGodAfterTime;
var B_randomThunderExtraDmgToSeperatedEnemy;
var B_ShieldEasyToBreak;
var B_TagCounter;
var B_Thorns;
var B_TimeTrap;
var B_VictimHEAL;
var B_WeakerWhenWeak;
var G_ArrowRain_DR;
var G_ArrowRain_Longbow;
var G_ATK;
var G_AutoRecoverHp;
var G_AutoRecoverMp;
var G_BackDmgAndGainMp;
var G_BacklineStrongWhenSafe;
var G_BasicAtkRemoveBuff;
var G_BattleStartUltBanned;
var G_CentaurLike;
var G_Crit;
var G_CritP;
var G_CritStunEnemy;
var G_DebuffResist;
var G_EnemyBuffShorter;
var G_EnemyResistDown;
var G_ExtraDmgOnHealthy;
var G_ExtraDmgOnLowMana;
var G_FirstUltSleepEnemy;
var G_FrontDmgAndVictimMp;
var G_GetStunnedBeforeFullMana;
var G_HealRatio;
var G_HighestAtkMoreAtk;
var G_HolyHealAll;
var G_HuskarLike_Atk;
var G_HuskarLike_Hast;
var G_LateGameStronger;
var G_LFS;
var G_MyZoneIsMine;
var G_PowerUpKillExceptKiller;
var G_ShieldCastingUlt;
var G_StrongerWhenRush;
var G_SuperCrit;
var G_SuperCritP;
var G_ThirdFloorAtk;
var G_ThirdFloorImu;
var G_TogetherWeStand;
var M_AllTimeUncontrollable;
var M_ArmorEnemyUlt;
var M_BattleStartBanish;
var M_BattleStartShieldDispellable;
var M_BearLike_Hp;
var M_BearLike_Mp;
var M_BossMode_Dmg;
var M_BossMode_Unctrl;
var M_BossMode_Mp;
var M_CritDownByAttribute;
var M_EarlyGameAtk;
var M_EarlyGameHast;
var M_EnemyMprUntilDie;
var M_EnemyStrongerUntilDie;
var M_EnemyUnctrlWhenAlone;
var M_Explosion;
var M_FastOrBleed;
var M_FastOrLose;
var M_FirstUltSleepPlayer;
var M_HolyHealAllByTime;
var M_ImuUnlessRush;
var M_KillerGetCursed;
var M_MidGameUnctrl;
var M_PhantomLike;
var M_PlayerDealLessDmgUnlessCrit;
var M_StunOrImuMpr;
var M_SurviveToOutlast;
var M_SurviveToWin;
var M_SwordMasterLike;
var M_SwordMasterLikeUpgraded;
var M_TideHunterLike;
var M_BasicAttackBetter;
var M_BattleStartEnemyTakeLessDmg;
var M_SlowButAtkHast;
var M_HeartStopperPlusBasicAttackLFS;
var M_UltsBetter;
var M_SlowButAllMpRatio;
var M_AtkDownUntilFirstUlt;
var M_hot_hero;
var B_randomThunder;
var B_weakAtkUp;
var B_DmgDownBack;
var B_DmgDownCross;
var B_PowerUpHum;
var B_PowerUpOrc;
var B_PowerUpElf;
var B_PowerUpUd;
var B_PowerUpGod;
var B_PowerUpDevil;
var B_TakeMoreDmgFront;
var B_TakeMoreDmgNoSig;
var B_TakeMoreDmgNoFur;
var B_PowerUpEnemySoldier;
var B_PowerUpEnemyTank;
var B_PowerUpEnemyRanger;
var B_PowerUpEnemyMage;
var B_PowerUpEnemySupport;
var B_GodOnlyHurtByDevil;
var B_DevilOnlyHurtByGod;
var B_TakeMoreDmgCertainTimes;
var B_CentaurLike;
var B_EnemyHealEachEnemyDie;
var B_TroopsReTexas;
var B_TroopsAddShield;
var B_TroopsDmgDown;
var B_TroopsTakeMoreDmg;
var B_TroopsAddAttribs;
var B_TroopsMPAccel;
var G_FuckUndeadHeroes;
var G_BattleStartSleepForHuman;
var G_FrontHeroUncontrollable;
var G_LimitedUltTimesForUndead;
var G_FuckHeroesCross;
var G_FuckHeroesDevil;
var G_VictimHEAL;
var G_HitUp;
var G_MultiDmgDown;
var G_KillFirstChargeHero;
var G_TakeMoreDmgTank;
var G_DmgDownMaster;
var G_ImuEnemyGod;
var G_ImuEnemyUndead;
var G_TakeMoreDmgBack;
var G_TakeMoreDmgFront;
var G_ShieldForMaxHP;
var G_EnemyBasicSkillDealNoDmg;
var G_AllTimeUncontrollable;
var CField_JobBuff;
var CField_GSBuff;
var CField_HealCtrlBuff;
var CField_HealShieldBuff;
var CField_CritAdvBuff;
var CField_attribsShieldBuff;
var B_targetThunder;
var B_EnemyBasicSkillDealNoDmg;
var G_AppointHeroMprForAstroM;
var G_AppointHeroHprForAstroM;
var G_AppointHeroATKForAstroM;
var G_AppointHeroCanTakeHurtForAstroM;
var B_TimeForBleach;
var B_EpforTh;
var B_LeftFieldWeek;
var B_Poisoning;
var B_CharmFront;
var G_DmgUpAgi;
var G_DmgUpStr;
var G_DmgUpInt;
var G_DmgUpHumanAndOrc;
var G_DmgUpGodDevilAndCross;
var G_DmgUpElfAndUndead;
var B_CircusShopUntargetable;
var B_CircusShopFireBallRain;
var B_CircusShopHitMore;
var B_CircusShopStandAtkUp;
var B_CircusShopMaxHp;
var B_CircusShopEveryEDoDmg;
var B_CircusShopInvulnerable;
var B_CircusShopShieldDmg;
var B_CircusShopSNKUltDmg;
var B_CircusShopDefUp;
var B_CircusShopOnDmgDown;
var B_CircusShopSpOnDmgDown;
var B_CircusShopStun;
var FieldSideStory_MDodge;
var FieldSideStory_RightSideMkDmgRdc;
var FieldWar_TeamBuffHuman;
var FieldWar_TeamBuffOrc;
var FieldWar_TeamBuffElf;
var FieldWar_TeamBuffUndead;
var FieldWar_TeamBuffCross;
var FieldWar_WarArmsDebuff;
var FieldWar_VanguardSelfBuff;
var FieldWar_WarArmsBuff;
var FieldWar_AssistWeaken;
var FieldWar_SeasonHeroBuff;
var FieldWar_Season1Buff;
var FieldWar_Season2Buff;
var FieldWar_Season5Buff;
var FieldWar_Season6Buff;
var FieldWar_Season7Buff;
var FieldWar_Season8Buff;
var FieldWar_Season9Buff;
var FieldWar_Season10Buff;
var FieldWar_Season11Buff;
var FieldWar_Season12Buff;
var FieldWar_NoArmyDuelDebuff;
var FieldTexas;
var human;
var elf;
var orc;
var undead;
var soldier;
var tank;
var ranger;
var mage;
var support;
var nerf_mpr_quality;
var nerf_human_undead;
var nerf_elf_orc;
var nerf_forward;
var nerf_backward;
var nerf_VictimHeal;
var buff_enemyZone;
var buff_atkHpDef_quality;
var buff_sameTag;
var buff_variousTag;
var banishHighestQuality;
var set_makeDmg;
var set_takeDmg;
var texas_BackwardGuard;
var texas_BattleStartShield;
var heirloom_soldier;
var heirloom_tank;
var heirloom_ranger;
var heirloom_mage;
var heirloom_support;
var GVEfieldBuff_BasicDmgDown;
var GVEfieldBuff_randomThunder;
var GVEfieldBuff_lostHpAoe;
var GVEfieldBuff_frontDmgUp;
var GVEfieldBuff_BossExtraDodge;
var GVEfieldBuff_BanRecoverMp;
var GVEfieldBuff_FinalBOSS_dmgDown;
var GVEfieldBuff_FinalBOSS_elfUp;
var GVEfieldBuff_FinalBOSS_humanUp;
var GVEfieldBuff_FinalBOSS_mixUp;
var GVEfieldBuff_FinalBOSS_orcUp;
var GVEfieldBuff_FinalBOSS_undeadUp;
var GVEfieldBuff_Label_dmgDown;
var GVEfieldBuff_Label_elf;
var GVEfieldBuff_Label_mix;
var GVEfieldBuff_Label_human;
var GVEfieldBuff_Label_orc;
var GVEfieldBuff_Label_undead;
var GVEfieldBuff_NTweatherChange;
var GVEfieldBuff_WindManKnockUp;
var GVEfieldBuff_WizardKillBonus;
var GVEfieldBuff_nDpUltBanRecover;
var GVEfieldBuff_NecUnhealFog;
var GVEfieldBuff_DKidUltFrozen;
var GVEfieldBuff_BoneArcherFear;
var GVEfieldBuff_SciMonsterPoison;
var GVEfieldBuff_BonesUltAoe;
var GVEfieldBuff_DKidUltMpClear;
var GVEfieldBuff_NecBanMpAfterUlt;
var GVEfieldBuff_nDpDmgUp;
var GVEfieldBuff_NearDmgUp;
var GVEfieldBuff_BossUltDestroyMp;
var GVEfieldBuff_BossCaptainStun;
var GVEfieldBuff_BossUltBleeding;
var glocalIndx;
var AllHastOrSlow;
var AoeArrowRain;
var AoeIceFrozen;
var AoeNoHeal;
var AoeSilence;
var ArrowRainPosition;
var AttrBuffOrNerf;
var DmgHealCoef;
var DragAll;
var FieldRTPvp;
var HotOrDot;
var NoCastRtSkill;
var RecoverNerf;
var RTPvpAddCrystal;
var RTPvpAtkDefDown;
var RTPvpAtkUp;
var RTPvpBanish;
var RTPvpDispel;
var RTPvpDispelWithDMG;
var RTPvpDmg;
var RTPvpDyingSlash;
var RTPvpFieldMPR;
var RTPvpGainMP;
var RTPvpGoldStatue;
var RTPvpHeal;
var RTPvpImmune;
var RTPvpInstantDmg;
var RTPvpInterrupt;
var RTPvpRandomTP;
var RTPvpRevive;
var RTPvpShield;
var RTPvpSnow;
var RTPvpSuperPower;
var RTPvpTaunt;
var RTPvpThunder;
var RTPvpUncontroll;
var RTPvpDispelSummoned;
var RTPvpDmgWithCompare;
var RTPvpOrigins;
var RTPvpHpTradeCrystal;
var RTPvpWeakAtkDown;
var RTPvpNoHeal;
var RTPvpNoCrystal;
var RTPvpDmgCounterShield;
var RManTest;
var RManBloodStele;
var RManSlowStele;
var RManCurseStele;
var RManMagicTower;
var RManCrystalTower;
var RManBeliefTower;
var RManAtkFlower;
var RManDefFlower;
var RManMpFlower;
var RManMagicTowerUpdate;
var RManCrystalTowerUpdate;
var RManBeliefTowerUpdate;
var RManAttOnDmgUp;
var RManDefHpUp;
var RManAttLostHp;
var LArenaTest;
var LArenaFatigue;
var FieldROG;
var ROG_BossMode;
var ROGAmulet_testSkill;
var ROGInst_testSkill;
var ROG_amulet_nearAtkUp;
var ROG_amulet_nearDmgDown;
var ROG_amulet_nearExAoe;
var ROG_amulet_rangeAtkHast;
var ROG_amulet_rangeCrit;
var ROG_amulet_healCounter;
var ROG_amulet_healCritDodg;
var ROG_amulet_healExMp;
var ROG_amulet_healAtkUp;
var ROG_amulet_shieldInsightHit;
var ROG_amulet_shieldHeal;
var ROG_amulet_shieldAtkHast;
var ROG_amulet_shieldAoe;
var ROG_amulet_shieldTranDmg;
var ROG_amulet_aoeDmgUp;
var ROG_amulet_aoeDefUp;
var ROG_amulet_bigDmgDown;
var ROG_amulet_bigDmgAtkDown;
var ROG_amulet_bigDmgFever;
var ROG_amulet_atkStealMp;
var ROG_amulet_atkCritRank;
var ROG_amulet_ultLessMp;
var ROG_amulet_ultTeamBuff;
var ROG_amulet_frontMpUp;
var ROG_amulet_noOtherMpUp;
var ROG_amulet_firstDieMpUp;
var ROG_amulet_mpPerCrit;
var ROG_amulet_D_ifKillHero;
var ROG_amulet_D_summonExist;
var ROG_amulet_D_underCtrl;
var ROG_amulet_D_castUlt;
var ROG_amulet_D_taunt;
var ROG_amulet_D_alive;
var ROG_amulet_D_curse;
var ROG_amulet_D_mpPer;
var ROG_amulet_D_tagCounter;
var ROG_amulet_D_hpBet;
var ROG_amulet_roundShield;
var ROG_amulet_healthUpAtk;
var ROG_amulet_basicAtkUpAtk;
var ROG_amulet_healthUpDmgDown;
var ROG_amulet_DmgReByKill;
var ROG_amulet_healthUpHeal;
var ROG_amulet_EnemyZoneDmgDown;
var ROG_amulet_UtlUpTeamCrit;
var ROG_amulet_CritExtarDmgUpMSPD;
var ROG_amulet_UtlReCD;
var ROG_amulet_CtrolLoseHPMP;
var ROG_amulet_StunDownINSRES;
var ROG_amulet_CtrolHealUp;
var ROG_amulet_CtrolDownDmg;
var ROG_amulet_killUpCrit;
var ROG_amulet_killUpDmg;
var ROG_amulet_sumExplode;
var ROG_amulet_sumDieUpATK;
var ROG_amulet_summonUpRES;
var ROG_amulet_killUpDodge;
var ROG_amulet_GetCritCounter;
var ROG_amulet_nearShieldLegends;
var ROG_amulet_rangeStealLegends;
var ROG_amulet_rangeCritLegends;
var ROG_amulet_utlMPLegends;
var ROG_amulet_healShieldLegends;
var ROG_amulet_shieldINSCritLegends;
var ROG_amulet_shieldFearLegends;
var ROG_amulet_dmgDownAtkLegends;
var ROG_amulet_powerSummonLegends;
var ROG_amulet_stunLegends;
var ROG_amulet_B_basicAtkExtraAtk;
var ROG_amulet_B_healShieldUpAtkHast;
var ROG_amulet_B_skillExtraAtk;
var ROG_amulet_B_friendBuffExtraAtk;
var ROG_amulet_B_nearDmgUp;
var ROG_amulet_B_shieldEnemyDmgUp;
var ROG_amulet_B_summonExtraEffect;
var ROG_amulet_B_summonDmgSummoner;
var ROG_amulet_B_healUpMpRatio;
var ROG_amulet_B_shieldUpMpRatio;
var FieldROG_inst_hpHeal;
var FieldROG_inst_ctrlLostMp;
var FieldROG_inst_tagCounter;
var FieldROG_inst_amuletAtk;
var FieldROG_inst_humanOrc;
var FieldROG_inst_elfUndead;
var FieldROG_inst_godDevil;
var FieldROG_inst_cross;
var ROG_field_critDown;
var ROG_field_noSup;
var ROG_field_slowCD;
var ROG_FieldBuff_LevelFix;
var ROG_miniBoss;
var ROG_TeamAmulet_Thunder_Keystone;
var ROG_TeamAmulet_Aerolite_Keystone;
var ROG_TeamAmulet_Stone_Keystone;
var ROG_TeamAmulet_Backstab_Keystone;
var ROG_TeamAmulet_Wave_Keystone;
var ROG_TeamAmulet_Rush_Keystone;
var ROG_TeamAmulet_Freeze_Keystone;
var ROG_TeamAmulet_Dominate_Keystone;
var ROG_TeamGeneral_UltStealMp;
var ROG_TeamGeneral_UltStackAtk;
var ROG_TeamGeneral_TakeHeal;
var ROG_TeamGeneral_StartUltDmgUp;
var ROG_TeamGeneral_Solo;
var ROG_TeamGeneral_ShieldHeal;
var ROG_TeamGeneral_ShareSuffering;
var ROG_TeamGeneral_RecvCtrlDmgRdc;
var ROG_TeamGeneral_NotToday;
var ROG_TeamGeneral_NormalAtkUp;
var ROG_TeamGeneral_KillingThrill;
var ROG_TeamGeneral_IronJaw;
var ROG_TeamGeneral_InitiateBoost;
var ROG_TeamGeneral_GiftBomb;
var ROG_TeamGeneral_FullofEnergy;
var ROG_TeamGeneral_DmgRdc;
var ROG_TeamGeneral_CtrlHealDown;
var ROG_TeamGeneral_CounterShield;
var ROG_TeamGeneral_BattleStartSpider;
var ROG_TeamGeneral_BattleStartShield;
var ROG_TeamGeneral_Apparition;
var ROG_FieldBuff_BackDmgRdc;
var ROG_FieldBuff_NoKnockBack;
var ROG_FieldBuff_NormalAtkNerf;
var ROG_FieldBuff_ShieldRdc;
var ROG_FieldBuff_StartDmgRdc;
var ROG_FieldBuff_SummoningNerf;
var ROG_FieldBuff_TkUltDmgRdc;
var ROG_FieldBuff_Unctrl;
var ROG_TwinsBuff_Tag;
var ROG_SoldierFearEnemy;
var __nativeSourceSnapshot;
var __nativeSnapshots;
var __nativeScene;
function __nativeDrain(){ed.clientCallCount=ed.clientCall_list.length;for(var t=ed.clientCall_list;t.length>0;){var i=t.shift();this.snapshot(),i(),this.snapshot(i)}}
var __nativeCallbacks;
var __nativeRuntime;
var __nativeRealmCopy;
function importBootstrapValue(_context,value){return __nativeRealmCopy(value);}
function instantiateScenario(runtime,input){
  const {ed}=runtime;
  const clone=value=>importBootstrapValue(runtime.context,value);
  const materialize=wire=>{
    const proto=clone(wire);
    proto.equips=proto.equips.map(slot=>({index:slot.index,equip:ed.equipData.create(slot.equip)}));
    proto.sig=ed.signatureData.create(proto.sig);
    return proto;
  };
  const config=clone(input.config);
  config.pets.self_pets=config.pets.self_pets.map(wire=>new ed.PetData(wire));
  config.pets.oppo_pets=config.pets.oppo_pets.map(wire=>new ed.PetData(wire));
  return{players:input.players.map(materialize),enemies:input.enemies.map(materialize),config,battleSeed:input.battleSeed,inputSha256:input.inputSha256};
}
function __nativeBits(value){
  var data=new DataView(new ArrayBuffer(8));data.setFloat64(0,value,false);var result='';
  for(var i=0;i<8;i++){var part=data.getUint8(i).toString(16);result+=(part.length===1?'0':'')+part;}
  return result;
}
function __nativePrimitiveState(object){
  var out={},keys=Object.keys(object).sort();
  for(var i=0;i<keys.length;i++){
    var key=keys[i],descriptor=Object.getOwnPropertyDescriptor(object,key);
    if(!descriptor||!('value'in descriptor))continue;
    var value=descriptor.value;
    if(typeof value==='number')out[key]={bits:__nativeBits(value)};
    else if(typeof value==='undefined')out[key]={kind:'undefined'};
    else if(typeof value==='boolean'||typeof value==='string'||value===null)out[key]=value;
    else if(Array.isArray(value)&&value.every(function(x){return typeof x==='number';}))out[key]=value.map(function(x){return{bits:__nativeBits(x)};});
  }
  return out;
}
function __nativeUnitState(unit){
  return{fields:__nativePrimitiveState(unit),attributes:__nativePrimitiveState(unit.attribs||{}),buffEffects:__nativePrimitiveState(unit.buff_effects||{}),
    skills:(unit.skill_list||[]).map(function(skill){return{name:skill.info&&skill.info.SkillName,fields:__nativePrimitiveState(skill)};}),
    buffs:(unit.buff_list||[]).map(function(buff){return{fields:__nativePrimitiveState(buff)};})};
}
function __nativeRun(runtime,wire,battles,warmup,wallNow,captureMode){
  var results=[],ed=runtime.ed,start=0,checksum=2166136261,totalCallbacks=0,lastEngine=null,lastEventStart=0;
  function mix(text){for(var i=0;i<text.length;i++){checksum^=text.charCodeAt(i);checksum=Math.imul(checksum,16777619)>>>0;}}
  function fullCapture(engine,eventStart){return{serialized:engine.toString(),
    stateBits:{engine:__nativePrimitiveState(engine),units:engine.unit_list.map(__nativeUnitState),deadUnits:engine.dead_unit_list.map(__nativeUnitState),pets:engine.pet_list.map(__nativeUnitState)},
    hostEvents:runtime.host.events.slice(eventStart),audioState:JSON.parse(JSON.stringify(runtime.host.audioState()))};}
  for(var battleIndex=-warmup;battleIndex<battles;battleIndex++){
    if(battleIndex===0)start=wallNow();
    var materialized=instantiateScenario(runtime,wire),engine=new ed.BattleEngine();ed.battleEngine=engine;
    ed.srand(materialized.battleSeed);
    engine.enterBattle(materialized.players,materialized.enemies,materialized.config);
    if(runtime.nativeTrace)runtime.nativeTrace.record('battle:entered',{});
    var frames=0,callbackCount=0,queued=0,eventStart=runtime.host.events.length;
    while(engine.running){
      if(runtime.nativeTrace)runtime.nativeTrace.beginFrame();
      var phase=runtime.callbacks.updateFrame(0.125);
      if(runtime.nativeTrace)runtime.nativeTrace.endFrame();
      frames++;callbackCount+=phase.executed;queued+=phase.queued;
    }
    if(battleIndex>=0){
      var result={result:engine.result,ticks:engine.ticks,frames:frames,callbacks:callbackCount,queuedCallbacks:queued,rngBits:__nativeBits(runtime.context.random_seed)};
      mix(JSON.stringify(result));totalCallbacks+=callbackCount;
      if(captureMode==='all'){var capture=fullCapture(engine,eventStart);for(var key in capture)result[key]=capture[key];}
      results.push(result);lastEngine=engine;lastEventStart=eventStart;
    }
  }
  var elapsedMs=wallNow()-start;
  var report={completed:results.length,elapsedMs:elapsedMs,battlesPerSecond:elapsedMs>0?results.length*1000/elapsedMs:null,capture:captureMode,checksum:checksum,totalCallbacks:totalCallbacks,results:results};
  if(captureMode==='final')report.finalCapture=fullCapture(lastEngine,lastEventStart);
  if(runtime.classManagerObserver){runtime.classManagerObserver.assertIntact();report.classManagerCounters=runtime.classManagerObserver.snapshot();}
  if(runtime.tableBoundary){runtime.tableBoundary.assertClean();report.tableBoundary=runtime.tableBoundary.stats();}
  if(runtime.nativeTrace)report.trace=runtime.nativeTrace.stop({status:'completed',running:lastEngine.running,ticks:lastEngine.ticks,result:lastEngine.result});
  return report;
}
var __nativeWire;
var __nativeResult;
