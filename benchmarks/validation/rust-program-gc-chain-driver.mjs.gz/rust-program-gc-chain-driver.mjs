import {readFile,writeFile,open,readdir,readlink} from 'node:fs/promises';
import {resolve} from 'node:path';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';

const root='/workspace/afkarena-simx',directory=resolve(root,'work/rust-battle-full');
const stateFile=resolve(directory,'gc-validation-chain.json');
const state={startedAt:new Date().toISOString(),stage:'waiting-build',events:[],nativeMonitor:{maxRssKiB:14*1024*1024,peakRssKiB:0,peakHwmKiB:0,termination:null}};
const save=async()=>writeFile(stateFile,JSON.stringify(state,null,2)+'\n');
async function event(kind,data={}){state.events.push({at:new Date().toISOString(),kind,...data});console.log(JSON.stringify({kind,...data}));await save();}
async function children(pid){const result=new Set();try{for(const task of await readdir(`/proc/${pid}/task`)){try{const text=await readFile(`/proc/${pid}/task/${task}/children`,'utf8');for(const id of text.trim().split(/\s+/))if(id)result.add(Number(id));}catch{}}}catch{}return [...result];}
async function run(command,label,monitorNative=false){
 const outFile=resolve(directory,label+'.stdout'),errFile=resolve(directory,label+'.stderr'),out=await open(outFile,'w'),err=await open(errFile,'w');
 try{return await new Promise(accept=>{
  const child=spawn(command[0],command.slice(1),{cwd:root,env:{...process.env,RUST_PORT_TRACE:'0'},stdio:['ignore',out.fd,err.fd]});
  let error=null,timer=null,busy=false,lastSaved=0,forceKill=null;
  async function sample(){if(busy||!child.pid)return;busy=true;try{for(const pid of await children(child.pid)){
   let executable='';try{executable=await readlink(`/proc/${pid}/exe`);}catch{continue;}
   if(!executable.endsWith('/rust-battle-program'))continue;
   const text=await readFile(`/proc/${pid}/status`,'utf8'),rss=Number(/^VmRSS:\s+(\d+)/m.exec(text)?.[1]??0),hwm=Number(/^VmHWM:\s+(\d+)/m.exec(text)?.[1]??0);
   state.nativeMonitor.pid=pid;state.nativeMonitor.peakRssKiB=Math.max(state.nativeMonitor.peakRssKiB,rss);state.nativeMonitor.peakHwmKiB=Math.max(state.nativeMonitor.peakHwmKiB,hwm);
   if(rss>state.nativeMonitor.maxRssKiB&&!state.nativeMonitor.termination){state.nativeMonitor.termination={at:new Date().toISOString(),pid,observedRssKiB:rss,signal:'SIGTERM',reason:'Native batch exceeded14GiB observed RSS; stop before workspace OOM'};process.kill(pid,'SIGTERM');forceKill=setTimeout(()=>{try{process.kill(pid,'SIGKILL');}catch{}},2000);await event('native-rss-stop',state.nativeMonitor.termination);}
  }if(Date.now()-lastSaved>3000){lastSaved=Date.now();await save();}}catch(error){if(error.code!=='ENOENT'&&error.code!=='ESRCH')state.nativeMonitor.lastError=String(error);}finally{busy=false;}}
  if(monitorNative)timer=setInterval(sample,100);
  child.on('error',value=>error=value.message);
  child.on('close',(status,signal)=>{clearInterval(timer);clearTimeout(forceKill);accept({command,pid:child.pid??null,status,signal,error,stdoutFile:outFile,stderrFile:errFile});});
 });}finally{await out.close();await err.close();}
}
try{
 await event('chain-waiting-build',{pid:process.pid,proof:'benchmarks/validation/rust-program-gc-build.json'});
 let build;
 for(;;){try{build=JSON.parse(await readFile(resolve(root,'benchmarks/validation/rust-program-gc-build.json'),'utf8'));if(build.completed===true)break;}catch{}await new Promise(accept=>setTimeout(accept,3000));}
 await event('first-build-finished',{status:build.process?.status,passed:build.passed,changedInputs:build.changedInputs});
 if(build.process?.status!==0)throw Error('Main release build failed before provenance resume');
 state.stage='resume-proof';await save();
 state.resume=await run([process.execPath,resolve(root,'tools/rust-port/build-program.mjs'),'--profile','release','--jobs','4','--output','benchmarks/validation/rust-program-gc-resume-build.json'],'gc-resume-build');
 const resume=JSON.parse(await readFile(resolve(root,'benchmarks/validation/rust-program-gc-resume-build.json'),'utf8'));
 await event('resume-build-finished',{status:state.resume.status,passed:resume.passed});if(state.resume.status!==0||resume.passed!==true)throw Error('Cached build provenance resume did not pass');
 state.stage='one-battle';await save();state.one=await run([process.execPath,resolve(root,'tools/rust-port/check-one-battle.mjs')],'gc-one-check');
 const lines=(await readFile(state.one.stdoutFile,'utf8')).trim().split('\n'),summary=JSON.parse(lines.at(-1));state.oneSummary=summary;
 await event('one-battle-finished',summary);if(state.one.status!==0||summary.passed!==true)throw Error('Single-battle check did not pass');
 state.stage='full-batch';await save();state.full=await run([process.execPath,resolve(root,'tools/rust-port/check-program.mjs'),'--profile','release','--binary','work/rust-port-shared-target/release/rust-battle-program','--build-proof','benchmarks/validation/rust-program-gc-resume-build.json','--output','benchmarks/validation/rust-full-program-gc.json'],'gc-full-check',true);
 const fullFile=resolve(root,'benchmarks/validation/rust-full-program-gc.json'),full=JSON.parse(await readFile(fullFile,'utf8'));
 full.externalNativeResourceMonitor={...state.nativeMonitor,scope:'Observed process RSS/HWM sampled externally every100ms; source oracle is a separate prior child.'};
 if(state.nativeMonitor.termination)full.termination=state.nativeMonitor.termination;
 await writeFile(fullFile,JSON.stringify(full,null,2)+'\n');state.fullSummary={file:fullFile,passed:full.passed,completed:full.completed,battlesPerSecond:full.battlesPerSecond,native:full.native,firstDifference:full.firstDifference,hostDifference:full.hostDifference};await event('full-batch-finished',state.fullSummary);
 if(state.full.status!==0||full.passed!==true)throw Error('Full batch did not pass');
 state.stage='passed';
}catch(error){state.error=String(error.stack??error);state.stage='failed';await event('chain-failed',{error:state.error});process.exitCode=1;}
state.finishedAt=new Date().toISOString();await save();
const source=await readFile(import.meta.filename),artifact=resolve(root,'benchmarks/validation/rust-program-gc-chain-driver.mjs.gz');await writeFile(artifact,gzipSync(source));state.driver={file:import.meta.filename,sha256:createHash('sha256').update(source).digest('hex'),artifact};
await writeFile(resolve(root,'benchmarks/validation/rust-program-gc-chain.json'),JSON.stringify(state,null,2)+'\n');await save();
